//
// boost/join/executor.hpp
//
// Copyright (c) 2007, 2008  Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_JOIN_EXECUTOR_HPP
#define BOOST_JOIN_EXECUTOR_HPP

#include <iostream>
#include <map>
#include <boost/thread.hpp>
#include <boost/join/join.hpp>

namespace boost {
  namespace join {

    template <size_t sz=32>
    class executor_n : public actor_n<async<void(typename actor_base::callable)>, sz> {
    public:
      typedef actor_n<async<void(typename actor_base::callable)>, sz> actor_type;
      typedef typename actor_type::callable task;
      typedef std::map<size_t, boost::shared_ptr<async<void(task)> > >  que_map_type;

      //static api: one default task queue
      async<void(task)> execute;
      synch<void(void)> shutdown;

      //dynamic api: dynamically added task queues
      async<void(task)> *task_queue(size_t i=0) {
	//since executor itself uses async/synch_f<> methods, we can have task
	//queues [1-(sz-5)]
	if (i>(sz-5)) i = i%(sz-5); 
	if(i==0) return &execute;
	//if(this->dispatcher_ != actor_type::fire_by_round_robin) {
	if(this->my_dispatcher() != actor_type::fire_by_round_robin) {
	  /*
	  this->log.msg(" throw executor_missing_rr_exception ......");
	  throw executor_missing_rr_exception();
	  */
	  return &execute;
	}
	typename que_map_type::iterator iter;
	if ((iter=que_map_.find(i)) != que_map_.end())
	  return iter->second.get();
	else {
	  this->log.msg(" creating task_queue ......");
	  boost::shared_ptr<async<void(task)> > nq(new async<void(task)>());
	  chord(run, *nq, &executor_n::exec_cb);
	  que_map_[i] = nq;
	  return nq.get();	  
	}
      }

      executor_n(int num, 
		 typename actor_type::dispatch_policy disp = actor_type::fire_as_soon_as_possible,
		 const char *name = NULL) : 
	actor_type(NULL, 0, disp, name) {
	chord(run, execute, &executor_n::exec_cb);
	chord(run, stopped, &executor_n::stop_cb, 1);
	chord(shutdown, started, &executor_n::shutdown_cb, 1);
	chord(shutdown, stopped, &executor_n::stopped_cb, 1);
	for(int i=0; i<num; i++)
	  threads_.create_thread(boost::bind(&executor_n::main_loop, this));
	started(); //init state
      }
      ~executor_n() {
	shutdown();
      }

    private:
      synch<bool(void)> run;
      //executor states
      async<void(void)> started;
      async<void(void)> stopped;
      boost::thread_group threads_;
      //dynamic api: dynamically added task queues
      que_map_type que_map_;

      void main_loop(void) {
	this->log.msg("a thread starts...");
	while(run()) {}
	this->log.msg("a thread exits...");
      }
      bool exec_cb(synch_o<bool(void)> run, async_o<void(task)> exec) {
	this->log.msg("start one task...");
	try {
	  (exec.arg1)();
	}
	catch (join_exception &je) {
	  this->log.msg(je.what());
	}
	catch (...) {
	  this->log.msg("UNKNOWN exceptions happen inside a executor thread, ignore.");
	}
	this->log.msg("finish one task...");
	return true; //worker thread continue
      }
      bool stop_cb(synch_o<bool(void)> run, async_o<void(void)> stopd) {
	stopped(); 
	return false; //worker thread exit
      }
      void shutdown_cb(synch_o<void(void)> shdn, async_o<void(void)> started) {
	this->log.msg("shutdown...");
	stopped();
	//waiting for the threads to exit
	this->log.msg("wait...");
	threads_.join_all();	
	this->log.msg("all threads exit, done...");
      }
      void stopped_cb(synch_o<void(void)> shdn, async_o<void(void)> stopd) {
	this->log.msg("stopped...");
	stopped();
      }
    };

    //define a default executor_n taking 32 async / synch methods or at most 27 task queues
    class executor : public executor_n<> {
    public:
      executor(int num, 
	       executor_n<>::actor_type::dispatch_policy disp = executor_n<>::actor_type::fire_as_soon_as_possible,
	       const char *name = NULL) : 
	executor_n<>(num, disp, name)
      {
      }
    };

  }
}

#endif
