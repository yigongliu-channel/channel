//
// guard.cpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/join/join.hpp>
#include <string>
#include <iostream>
#include <sstream>

using namespace boost::join;
using namespace std;

logger log1("log");

//a service taking requests consisting of a sequence number (int) and content(string)
class server: public actor<> {
public:
  async<void(int, string)> request; 
  server(executor *e) : actor<>(e) {
    chord(request, &server::req_proc_odd, 0, &server::is_odd);
    chord(request, &server::req_proc_even, 0, &server::is_even);
  }
  void req_proc_odd(async_o<void(int, string)> req) {
    log1.stream() << "process a odd request: seq#[" << req.arg1 
		  << "], req [" << req.arg2 << "]" << logger::endl;
  }
  void req_proc_even(async_o<void(int, string)> req) {
    log1.stream() << "------------- process a even request: seq#[" << req.arg1 
		  << "], req [" << req.arg2 << "]" << logger::endl;
  }
  bool is_odd(async_o<void(int, string)> req) {
    return req.arg1 % 2 != 0;
  }
  bool is_even(async_o<void(int, string)> req) {
    return (req.arg1 % 2) == 0;
  }
};

int main(int argc, char **argv) {
  executor exec(2);  //spawn 2 threads for executor thread pool
  server srv(&exec.execute);
  for(int i=0; i<100; i++) 
    srv.request(i, (i%2)?"odd request":"even request");
  exec.shutdown();
  return 0;
}
