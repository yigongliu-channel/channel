//
// rendezvous.cpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#include <boost/join/join.hpp>
#include <iostream>

using namespace boost::join;

logger log1("log");

class rendezvous : public actor<> {
public:
  synch<int(int)> f;
  synch<int(int)> g;
  synch<int(int)> h;
  rendezvous() : actor<>() {
    chord(f,g,h,&rendezvous::chord_cb);
  }
  void chord_cb(synch_o<int(int)> f, synch_o<int(int)> g, synch_o<int(int)> h) {
    f.reply(f-g);
    g.reply(h-g);
    h.reply(f+g);
  }
};

void thread_sleep(int sec) {
    boost::xtime xt;
    boost::xtime_get(&xt, boost::TIME_UTC);
    xt.sec += sec;
    boost::thread::sleep(xt);
}

class Demo : public actor<> {
public:
  rendezvous rend_;
  async<void()> f_calls;
  async<void()> g_calls;
  async<void()> h_calls;

  Demo(executor *e) : actor<>(e) {
    chord(f_calls, &Demo::f_call);
    chord(g_calls, &Demo::g_call);
    chord(h_calls, &Demo::h_call);
  }
  void f_call(async_o<void()> p) {
    int ret;
    for(int i=0; i<5; i++) {
      log1.stream() << "f sends [" << i << "] and wait..." << logger::endl;
      ret = rend_.f(i);
      log1.stream() << "f recvs [" << ret << "]..." << logger::endl;
    }
  }
  void g_call(async_o<void()> p) {
    int ret;
    for(int i=5; i<10; i++) {
      log1.stream() << "g sends [" << i << "] and wait..." << logger::endl;
      ret = rend_.g(i);
      log1.stream() << "g recvs [" << ret << "]..." << logger::endl;
    }
  }
  void h_call(async_o<void()> p) {
    int ret;
    for(int i=10; i<15; i++) {
      log1.stream() << "h sends [" << i << "]..." << logger::endl;
      ret = rend_.h(i);
      log1.stream() << "h recvs [" << ret << "]..." << logger::endl;
      thread_sleep(3);
    }
  }
};

int main(int argc, char **argv) {
  executor exec(3);  //spawn 3 threads for executor thread pool
  Demo demo(&exec.execute);
  demo.f_calls();
  demo.g_calls();
  demo.h_calls();
  exec.shutdown();
  return 0;
}
