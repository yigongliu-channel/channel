//
// boost/join/executor.hpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_JOIN_EXECUTOR_HPP
#define BOOST_JOIN_EXECUTOR_HPP

#include <iostream>
#include <map>
#include <boost/thread.hpp>
#include <boost/join/join.hpp>

namespace boost {
  namespace join {

    template <size_t sz=32>
    class Executor : public actor<async_f<typename actor_base::callable>, sz> {
    public:
      typedef actor<async_f<typename actor_base::callable>, sz> actor_type;
      typedef typename actor_type::callable task;
      typedef std::map<size_t, boost::shared_ptr<async<void(task)> > >  que_map_type;

      //static api: one default task queue
      async<void(task)> execute;
      synch<void(void)> shutdown;

      //dynamic api: dynamically added task queues
      async<void(task)> *task_queue(size_t i=0) {
	//since executor itself uses async/synch_f<> methods, we can have task
	//queues [1-(sz-5)]
	if (i>(sz-5)) i = i%(sz-5); 
	if(i==0) return &execute;
	//if(this->dispatcher_ != actor_type::fire_by_round_robin) {
	if(this->my_dispatcher() != actor_type::fire_by_round_robin) {
	  /*
	  this->log.msg(" throw executor_missing_rr_exception ......");
	  throw executor_missing_rr_exception();
	  */
	  return &execute;
	}
	typename que_map_type::iterator iter;
	if ((iter=que_map_.find(i)) != que_map_.end())
	  return iter->second.get();
	else {
	  this->log.msg(" creating task_queue ......");
	  boost::shared_ptr<async<void(task)> > nq(new async<void(task)>());
	  chord(run, *nq, &Executor::exec_cb);
	  que_map_[i] = nq;
	  return nq.get();	  
	}
      }

      Executor(int num, const char *name = NULL, 
	       typename actor_type::dispatch_policy disp = actor_type::fire_as_soon_as_possible) : 
	actor_type(NULL, name, disp) {
	chord(run, execute, &Executor::exec_cb);
	chord(run, stopped, &Executor::stop_cb, 1);
	chord(shutdown, started, &Executor::shutdown_cb, 1);
	chord(shutdown, stopped, &Executor::stopped_cb, 1);
	for(int i=0; i<num; i++)
	  threads_.create_thread(boost::bind(&Executor::main_loop, this));
	started(); //init state
      }
      ~Executor() {
	shutdown();
      }

    private:
      synch<bool(void)> run;
      //executor states
      async<void(void)> started;
      async<void(void)> stopped;
      boost::thread_group threads_;
      //dynamic api: dynamically added task queues
      que_map_type que_map_;

      void main_loop(void) {
	this->log.msg("a thread starts...");
	while(run()) {}
	this->log.msg("a thread exits...");
      }
      bool exec_cb(synch_o<bool(void)> run, async_o<void(task)> exec) {
	this->log.msg("start one task...");
	try {
	  (exec.arg1)();
	}
	catch (join_exception &je) {
	  this->log.msg(je.what());
	}
	catch (...) {
	  this->log.msg("UNKNOWN exceptions happen inside a executor thread, ignore.");
	}
	this->log.msg("finish one task...");
	return true; //worker thread continue
      }
      bool stop_cb(synch_o<bool(void)> run, async_o<void(void)> stopd) {
	stopped(); 
	return false; //worker thread exit
      }
      void shutdown_cb(synch_o<void(void)> shdn, async_o<void(void)> started) {
	this->log.msg("shutdown...");
	stopped();
	//waiting for the threads to exit
	this->log.msg("wait...");
	threads_.join_all();	
	this->log.msg("all threads exit, done...");
      }
      void stopped_cb(synch_o<void(void)> shdn, async_o<void(void)> stopd) {
	this->log.msg("stopped...");
	stopped();
      }
    };

    //define a default Executor taking 32 async / synch methods or at most 27 task queues
    class executor : public Executor<> {
    public:
      executor(int num, const char *name = NULL, 
	       Executor<>::actor_type::dispatch_policy disp = Executor<>::actor_type::fire_as_soon_as_possible) : 
	Executor<>(num, name, disp)
      {
      }
    };

  }
}

#endif
