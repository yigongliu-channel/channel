//
// boost/join/actor.hpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_JOIN_ACTOR_HPP
#define BOOST_JOIN_ACTOR_HPP

#include <vector>
#include <bitset>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/bind.hpp>
#include <boost/join/base/join_base.hpp>
#include <boost/join/base/exceptions.hpp>

namespace boost {
  namespace join {

    template <bool flag, typename T, typename U>
    struct select { typedef T result; };
    template <typename T, typename U>
    struct select<false, T, U> { typedef U result; };

    template <size_t size>
    struct bitmap {
      enum {
	max_size = size
      };
      typedef typename select<(size<=32), unsigned int, std::bitset<size> >::result bitset_type;
      bitset_type bitmap_;
      bitmap(unsigned int val=0) : bitmap_(val) {}
      void set(bitmap &t) { bitmap_ |= t.bitmap_; }
      void clear(bitmap &t) { bitmap_ &= ~t.bitmap_; }
      bool test(bitmap &t) { return (bitmap_ & t.bitmap_) != 0; }
      bool match(bitmap &b) { return (~bitmap_ & b.bitmap_) == 0; }
      bool operator==(bitmap &t) { return bitmap_ == t.bitmap_; }
      size_t num_of_ones(void) {
	size_t num = 0;
	for(int i = 0; i<max_size; i++)
	  if (bitmap_ & (1<<i)) num++;
	return num;
      }
    };

    template <typename exec_type, size_t size> class actor;

    template <typename exec_type, size_t max_size>
    class chord_common : public chord_base {
    public:
      actor<exec_type, max_size> *actor_;
      typename actor<exec_type, max_size>::bitmap_t mask_;// ports of this chord
      size_t num_ports_; //for scheduling policy fire_as_much_as_possible
      port *synch_p_;
      int priority_; //sched priority of chord: 0 - max, the bigger the lower

      chord_common(typename actor<exec_type, max_size>::bitmap_t &m, port *s, actor<exec_type, max_size>* a, int pri) : 
	actor_(a), mask_(m), synch_p_(s), priority_(pri) {
	num_ports_ = m.num_of_ones();
      }

      template <typename PortT>
      typename PortT::var_type
      top(PortT &p) {
	return p.top();
      }
      template <typename PortT, size_t N>
      boost::array<typename PortT::var_type,N>
      top(boost::array<PortT,N> &vp) {
	boost::array<typename PortT::var_type,N> vv;
	for(size_t i=0; i<N; i++)
	  vv[i] = vp[i].top();
	return vv;
      }
      template <typename PortT>
      void pop_top(PortT &p) {
	p.pop_top();
      }
      template <typename PortT, std::size_t N>
      void pop_top(boost::array<PortT,N> &vp) {
	for(size_t i=0; i<N; i++)
	  vp[i].pop_top();
      }

      chord_base * fire(port *caller_port) {
	actor_->log.msg("a chord fired");
	if(caller_port->type_ == port::synch) {//caller is sync
	  //invoke callback later in the same caller thread
	  return this;
	}
	else { //caller is async_f
	  //based on ports_, find any synch_port in this chord
	  //and transfer control to its thread and let its  thread to run callback
	  if (synch_p_) {
	    ((synch_port*)synch_p_)->transfer(this);
	    return NULL;
	  }
	  else { //no sync ports in chord
	    if(actor_->spawn_ != NULL) {
	      return this;
	    } else
	      throw no_executor_exception();
	  }
	}
	return NULL;
      }
    };

    template <typename PortT>
    struct var_type {
      typedef typename PortT::var_type result;
    };
    template <typename PortT, std::size_t N>
    struct var_type<boost::array<PortT,N> > {
      typedef boost::array<typename PortT::var_type,N> result;
    };
    template <typename PortT>
    struct res_type {
      typedef typename PortT::result_type result;
    };
    template <typename PortT, std::size_t N>
    struct res_type<boost::array<PortT,N> > {
      typedef void result;
    };

    template <typename exec_type, size_t max_size, typename PortT, typename CallT>
    class chord1 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT>::result> {
      typedef typename res_type<PortT>::result result_type;
    public:
      PortT &port_;
      CallT call_;
      chord1(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT &p, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a,pri), port_(p), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port_));
	pop_top(port_);
      }      
    };

    template <typename exec_type, size_t max_size, typename PortT1, typename PortT2, typename CallT>
    class chord2 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT1>::result> {
      typedef typename res_type<PortT1>::result result_type;
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      CallT call_;
      chord2(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT1 &p1, PortT2 &p2, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a, pri), port1_(p1), port2_(p2), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port1_), top(port2_));
	pop_top(port1_);
	pop_top(port2_);
      }      
    };

    template <typename exec_type, size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename CallT>
    class chord3 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT1>::result> {
      typedef typename res_type<PortT1>::result result_type;
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      CallT call_;
      chord3(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a,pri), port1_(p1), port2_(p2), port3_(p3), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port1_), top(port2_), top(port3_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
      }      
    };

    template <typename exec_type, size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT>
    class chord4 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT1>::result> {
      typedef typename res_type<PortT1>::result result_type;
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      CallT call_;
      chord4(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a,pri), port1_(p1), port2_(p2), port3_(p3), port4_(p4), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
      }      
    };

    template <typename exec_type, size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT>
    class chord5 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT1>::result> {
      typedef typename res_type<PortT1>::result result_type;
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      CallT call_;
      chord5(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a,pri), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
      }      
    };

    template <typename exec_type, size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT>
    class chord6 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT1>::result> {
      typedef typename res_type<PortT1>::result result_type;
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      PortT6 &port6_;
      CallT call_;
      chord6(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a,pri), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), port6_(p6), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
	pop_top(port6_);
      }      
    };

    template <typename exec_type, size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT>
    class chord7 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT1>::result> {
      typedef typename res_type<PortT1>::result result_type;
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      PortT6 &port6_;
      PortT7 &port7_;
      CallT call_;
      chord7(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a,pri), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), port6_(p6), port7_(p7), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_), top(port7_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
	pop_top(port6_);
	pop_top(port7_);
      }      
    };

    template <typename exec_type, size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT>
    class chord8 : public chord_common<exec_type, max_size>, public chord_oper<typename res_type<PortT1>::result> {
      typedef typename res_type<PortT1>::result result_type;
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      PortT6 &port6_;
      PortT7 &port7_;
      PortT8 &port8_;
      CallT call_;
      chord8(typename actor<exec_type, max_size>::bitmap_t &m, port *sp, actor<exec_type, max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c, int pri) : 
	chord_common<exec_type, max_size>(m,sp,a,pri), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), port6_(p6), port7_(p7), call_(c) {
      }
      void capture_arguments(boost::function0<result_type> &cb) {
	cb = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_), top(port7_), top(port8_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
	pop_top(port6_);
	pop_top(port7_);
	pop_top(port8_);
      }      
    };

    template <typename exec_type=async_f<typename actor_base::callable>, size_t max_size=32>
    class actor : public actor_base, private boost::noncopyable {
      template <class,size_t> friend class chord_common;
      friend class port;

    public:
      typedef bitmap<max_size> bitmap_t;
      typedef typename actor_base::callable callable;
      typedef async_f<typename actor_base::callable> default_executor;
      typedef exec_type executor; //in fact this is a task que to a real executor
      typedef chord_common<exec_type, max_size> chord_type;
      //??1 should we integrate port_data content into port itself?
      //?? bitmap<size> depend on template - trouble! we want ports
      // and actors are independent types, so that diff ports can be
      // used with diff actors
      //still use port_data, however dont allocate them from heap, since
      //they are really small, just copy their value into vector
      //so 
      //vector<port_data> ports_; since it is continuous array, when we read
      //it, use reference
      typedef struct port_data_ {
	port *port_;
	bitmap_t mask_;
      } port_data;

      enum dispatch_policy {
	fire_as_soon_as_possible, //(first match will fire)
	fire_as_much_as_possible,  //(longest match will fire)
	fire_by_round_robin  //(round robin)
      };

    private:
      executor *spawn_;
      dispatch_policy dispatcher_;
      bitmap_t status_; //bitmap marking which port is active
      std::vector<port_data> ports_; //all unique ports in this actor, actor not owning
      //them and will not destroy them, actor will destroy port_data
      std::vector<boost::shared_ptr<chord_type> > chords_; //actor owns chords_ and will destroy them

    public:
      actor(executor *s = NULL, const char *name = NULL, 
	    dispatch_policy d = fire_as_soon_as_possible) : 
	actor_base(name), spawn_(s), dispatcher_(d), status_(0){}

      ~actor() {
	//for(size_t i=0; i<ports_.size(); i++) 
	//ports_[i].port_->reset();
      }

      void spawn(callable c) {
	(*spawn_)(c);
      }
      dispatch_policy my_dispatcher(void) { return dispatcher_; }

    private:
      //ports call this to notify that a new msg comes
      //return: true - chord fired, false - chord not fired
      chord_base * port_invoked(int ind) {
	port_data &pd(ports_[ind]);
	pd.port_->num_pending_++;
	if(status_.test(pd.mask_)) {
	  //already set
	  log.msg("port_invoked: a port add more pending calls");
	  //do nothing
	} else {
	  status_.set(pd.mask_);
	  log.msg("port_invoked: a empty port get a call");
	  chord_type *c = scan_chords(pd.port_); //find chord to fire based on dispatch_policy
	  if(c != NULL) {
	    //update msg arrival status first, mark msgs to be consumed as
	    //"unavailable", kinds of "reserve" these msgs
	    //so that thread-scheduling will not interfere: another thread may come in
	    //between try to take some of these msgs
	    update_status(c->mask_);
	    return c->fire(pd.port_);
	  }
	}
	return NULL;
      }

      //find any chords can be fired, based on dispatch_policy:
      //. match_as_soon_as_possible (first match will fire)
      //. match_as_much_as_possible (longest match will fire)
      chord_type * scan_chords(port *p) {
	chord_type *chord_ready = NULL;

	if (dispatcher_ == fire_as_soon_as_possible) {
	  for(size_t i=0; i<p->chords_.size() && chord_ready == NULL; i++) 
	    for(size_t j=0; j<p->chords_[i].size() && chord_ready == NULL; j++) {
	      if(status_.match(((chord_type *)p->chords_[i][j])->mask_))
		chord_ready = (chord_type *)p->chords_[i][j];
	    }
	} 
	else if (dispatcher_ == fire_as_much_as_possible) { 
	  for(size_t i=0; i<p->chords_.size() && chord_ready == NULL; i++) {
	    size_t chord_size = 0;
	    for(size_t j=0; j<p->chords_[i].size(); j++) {
	      if(((chord_type *)p->chords_[i][j])->num_ports_ > chord_size) {
		if(status_.match(((chord_type *)p->chords_[i][j])->mask_)) {
		  chord_ready = (chord_type *)p->chords_[i][j];
		  chord_size = chord_ready->num_ports_;
		}
	      }	    
	    }
	  }
	}
	else if (dispatcher_ == fire_by_round_robin) { 
	  for(size_t i=0; i<p->chords_.size() && chord_ready == NULL; i++) 
	    if(p->chords_[i].size()>0) {
	      size_t min = p->last_chord_fired_[i]+1;
	      for(size_t j=min; j<p->chords_[i].size() && chord_ready == NULL; j++) {
		if(status_.match(((chord_type *)p->chords_[i][j])->mask_)) {
		  chord_ready = (chord_type *)p->chords_[i][j];
		  p->last_chord_fired_[i] = (int)j;
		}
	      }
	      if (chord_ready == NULL && min > 0) 
		for(size_t j=0; j<min && chord_ready == NULL; j++) {
		  if(status_.match(((chord_type *)p->chords_[i][j])->mask_)) {
		    chord_ready = (chord_type *)p->chords_[i][j];
		    p->last_chord_fired_[i] = (int)j;
		  }
		}
	    }
	}

	return chord_ready;
      }

      //one msg will be taken from each port in mask
      //query these ports to see if any msg remaininf and
      //if its bit in status_ should be flipped
      void update_status(bitmap_t &chord_mask) {
	for(size_t i=0; i<ports_.size(); i++)
	  if(chord_mask.test(ports_[i].mask_)) {
	    ports_[i].port_->num_pending_--;
	    if(ports_[i].port_->num_pending_ == 0)
	      status_.clear(ports_[i].mask_);
	  }
      }

      //
      // utils methods for creating chords
      //
      template <typename PortT>
      void add_port(PortT &p, bitmap_t &bmap) {
	port *pp = &p;
	port_data pd;
	int ind = -1;
	if(pp->actor_ != NULL && pp->actor_ != this) 
	  throw double_association_exception();
	for(size_t i=0; i<ports_.size() && ind == -1;i++)
	  if(pp == ports_[i].port_) {
	    ind = (int)i;
	    pd = ports_[i];
	  }
	if (ind == -1) {
	  ind = (int)ports_.size();
	  if((size_t)ind >= max_size) {
	    log.msg("too_many_ports_exception thrown");
	    throw too_many_ports_exception();
	  }
	  pd.port_ = pp;
	  pd.mask_ = bitmap_t(1<<ind);
	  ports_.push_back(pd);
	  pp->actor_ = this;
	  pp->index_ = ind;
	  pp->num_pending_ = 0;
	}
	bmap.set(pd.mask_);
      }
      template <typename PortT, std::size_t N>
      void add_port(boost::array<PortT,N> &vp, bitmap_t &bmap) {
	for(size_t i=0; i<N; i++) 
	  add_port(vp[i], bmap);
      }
      template <typename PortT>
      bool find_port(PortT &p, bitmap_t &bmap) {
	port *pp = &p;
	port_data pd;
	int ind = -1;
	if(pp->actor_ == NULL || pp->actor_ != this) 
	  return false;
	for(size_t i=0; i<ports_.size() && ind == -1;i++)
	  if(pp == ports_[i].port_) {
	    ind = i;
	    pd = ports_[i];
	  }
	if (ind != -1) {
	  bmap.set(pd.mask_);
	  return true;
	}
	return false;
      }
      template <typename PortT, std::size_t N>
      bool find_port(boost::array<PortT,N> &vp, bitmap_t &bmap) {
	for(size_t i=0; i<N; i++) 
	  if(!find_port(vp[i], bmap))
	    return false;
	return true;
      }
      template <typename PortT>
      void port_add_chord(PortT &p, chord_base *c, int priority) {
	if(p.chords_.size() < ((size_t)priority+1))
	  for(size_t i=p.chords_.size(); i<((size_t)priority+1); i++) {
	    p.chords_.push_back(std::vector<chord_base*>());
	    p.last_chord_fired_.push_back(-1);
	  }
	p.chords_[priority].push_back(c);
	if(!p.bound_) p.bound_ = true;
      }
      template <typename PortT, std::size_t N>
      void port_add_chord(boost::array<PortT,N> &vp, chord_base *c, int priority) {
	for(size_t i=0; i<N; i++)
	  port_add_chord(vp[i], c, priority);
      }
      template <typename PortT>
      void port_del_chord(PortT &p, chord_base *c, int priority) {
	typename std::vector<chord_base*>::iterator iter;
	if ((iter = std::find(p.chords_[priority].begin(), p.chords_[priority].end(), c)) != p.chords_[priority].end())
	  p.chords_[priority].erase(iter);
	p.bound_ = false;
	for(size_t i=0; i<p.chords_.size() && !p.bound_; i++)
	  if(p.chords_[i].size() > 0) p.bound_ = true;
      }
      template <typename PortT, std::size_t N>
      void port_del_chord(boost::array<PortT,N> &vp, chord_base *c, int priority) {
	for(size_t i=0; i<N; i++)
	  port_del_chord(vp[i], c, priority);
      }
      bool find_chord(bitmap_t &bmap, boost::shared_ptr<chord_type> &cd) {
	for(size_t i=0; i<chords_.size(); i++) {
	  if (chords_[i]->mask_ == bmap) {
	    cd = chords_[i];
	    return true;
	  }
	}
	return false;
      }
      bool del_chord(bitmap_t &bmap, boost::shared_ptr<chord_type> &cd) {
	typename std::vector<boost::shared_ptr<chord_type> >::iterator iter;
	for(iter = chords_.begin(); iter != chords_.end(); iter++) {
	  if ((*iter)->mask_ == bmap) {
	    cd = (*iter);
	    chords_.erase(iter);
	    return true;
	  }
	}
	return false;
      }
      void chord_data_validation(bitmap_t &bmap) {
	if (dispatcher_ == fire_as_soon_as_possible) {
	  //check_hidden_chord(bitmap_t &bmap)
	  for(size_t i=0; i<chords_.size(); i++) {
	    if (chords_[i]->mask_.match(bmap) || bmap.match(chords_[i]->mask_)) 
	      throw hidden_chord_exception();
	  }
	}
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd))
	  throw hidden_chord_exception();
      }

      template <typename PortT>
      typename port::port_type port_type(PortT &p) {
	return p.type_;
      }
      template <typename PortT, std::size_t N>
      typename port::port_type port_type(boost::array<PortT,N> &vp) {
	if (vp[0].type_ == port::synch && N > 1)
	  throw single_synch_exception();
	return vp[0].type_;
      }

    public:

      //
      // ***** "factory" methods to create chords ******
      //
      //--- chord with 1 port ---
      template <typename PortT, typename CallT>
      void chord(PortT &p, CallT c, int priority=0) {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if (port_type(p) == port::synch) sp = &p;
	add_port(p, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord1<executor,max_size,PortT,CallT>(bmap, sp, this, p, c, priority));
	chords_.push_back(cd);
	port_add_chord(p,cd.get(),priority);
      }

      template <typename PortT>
      void chord_remove(PortT &p) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!find_port(p, bmap)) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap,cd))
	  throw chord_remove_exception();
	port_del_chord(p, cd.get(), cd->priority_);
      }

      template <typename PortT, typename CallT>
      void chord_override(PortT &p, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!find_port(p, bmap)) 
	  throw chord_override_exception();
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord1<executor,max_size,PortT,CallT> *cdp = (chord1<executor,max_size,PortT,CallT>*) cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT, typename ActorT, typename R, typename ArgT>
      void chord(PortT &p, 
		 R (ActorT::*c)(ArgT), 
		 int priority=0) {
	chord(p, boost::bind(c, (ActorT*)this, _1), priority);
      }
      template <typename PortT, typename ActorT, typename R, typename ArgT>
      void chord_override(PortT &p, 
			  R (ActorT::*c)(ArgT), 
			  int priority=0) {
	chord_override(p, boost::bind(c, (ActorT*)this, _1), priority);
      }


      // ---- chord with 2 ports ----
      template <typename PortT1, typename PortT2, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, CallT c, int priority=0)
      {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);	
	if (port_type(p1) == port::synch) sp = &p1;
	if (port_type(p2) == port::synch)
	  throw synch_not_1st_exception();
	add_port(p1, bmap);
	add_port(p2, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord2<executor,max_size,PortT1,PortT2,CallT>(bmap, sp, this, p1, p2, c, priority));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2>
      void chord_remove(PortT1 &p1, PortT2 &p2) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap))) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap, cd))
	  throw chord_remove_exception();
	port_del_chord(p1, cd.get(), cd->priority_);
	port_del_chord(p2, cd.get(), cd->priority_);
      }

      template <typename PortT1, typename PortT2, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap)))
	  throw chord_override_exception();	  
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord2<executor,max_size,PortT1,PortT2,CallT>* cdp = (chord2<executor,max_size,PortT1,PortT2,CallT>*)cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p1, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p2, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p1, (chord_type*)cdp, priority);
	    port_add_chord(p2, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename ActorT, typename R, typename ArgT1, typename ArgT2>
      void chord(PortT1 &p1, PortT2 &p2, 
		 R (ActorT::*c)(ArgT1, ArgT2), int priority=0) {
	chord(p1, p2, boost::bind(c, (ActorT*)this, _1, _2), priority);
      }
      template <typename PortT1, typename PortT2, typename ActorT, typename R, typename ArgT1, typename ArgT2>
      void chord_override(PortT1 &p1, PortT2 &p2, 
			  R (ActorT::*c)(ArgT1, ArgT2), int priority=0) {
	chord_override(p1, p2, boost::bind(c, (ActorT*)this, _1, _2), priority);
      }

      //---- chord with 3 ports ---

      template <typename PortT1, typename PortT2, typename PortT3, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, CallT c, int priority=0)
      {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if (port_type(p1) == port::synch) sp = &p1;
	if (port_type(p2) == port::synch || port_type(p3) == port::synch)
	  throw synch_not_1st_exception();
	add_port(p1, bmap);
	add_port(p2, bmap);
	add_port(p3, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord3<executor,max_size,PortT1,PortT2,PortT3,CallT>(bmap, sp, this, p1, p2, p3, c, priority));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3>
      void chord_remove(PortT1 &p1, PortT2 &p2, PortT3 &p3) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap))) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap, cd))
	  throw chord_remove_exception();
	port_del_chord(p1, cd.get(), cd->priority_);
	port_del_chord(p2, cd.get(), cd->priority_);
	port_del_chord(p3, cd.get(), cd->priority_);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap)))
	  throw chord_override_exception();	  
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord3<executor,max_size,PortT1,PortT2,PortT3,CallT>* cdp = (chord3<executor,max_size,PortT1,PortT2,PortT3,CallT>*)cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p1, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p2, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p3, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p1, (chord_type*)cdp, priority);
	    port_add_chord(p2, (chord_type*)cdp, priority);
	    port_add_chord(p3, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, 
		 R (ActorT::*c)(ArgT1, ArgT2, ArgT3), int priority=0) {
	chord(p1, p2, p3, boost::bind(c, (ActorT*)this, _1, _2, _3), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, 
			  R (ActorT::*c)(ArgT1, ArgT2, ArgT3), int priority=0) {
	chord_override(p1, p2, p3, boost::bind(c, (ActorT*)this, _1, _2, _3)), priority;
      }

      //----- chord with 4 ports -----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, CallT c, int priority=0)
      {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if (port_type(p1) == port::synch) sp = &p1;
	if (port_type(p2) == port::synch || port_type(p3) == port::synch || port_type(p4) == port::synch)
	  throw synch_not_1st_exception();
	add_port(p1, bmap);
	add_port(p2, bmap);
	add_port(p3, bmap);
	add_port(p4, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord4<executor,max_size,PortT1,PortT2,PortT3,PortT4,CallT>(bmap, sp, this, p1, p2, p3, p4, c, priority));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4>
      void chord_remove(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap))) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap, cd))
	  throw chord_remove_exception();
	port_del_chord(p1, cd.get(), cd->priority_);
	port_del_chord(p2, cd.get(), cd->priority_);
	port_del_chord(p3, cd.get(), cd->priority_);
	port_del_chord(p4, cd.get(), cd->priority_);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap)))
	  throw chord_override_exception();	  
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord4<executor,max_size,PortT1,PortT2,PortT3,PortT4,CallT>* cdp = (chord4<executor,max_size,PortT1,PortT2,PortT3,PortT4,CallT>*)cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p1, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p2, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p3, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p4, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p1, (chord_type*)cdp, priority);
	    port_add_chord(p2, (chord_type*)cdp, priority);
	    port_add_chord(p3, (chord_type*)cdp, priority);
	    port_add_chord(p4, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, 
		 R (ActorT::*c)(ArgT1, ArgT2, ArgT3, ArgT4), int priority=0) {
	chord(p1, p2, p3, p4, boost::bind(c, (ActorT*)this, _1, _2, _3, _4), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, 
			  R (ActorT::*c)(ArgT1, ArgT2, ArgT3, ArgT4), int priority=0) {
	chord_override(p1, p2, p3, p4, boost::bind(c, (ActorT*)this, _1, _2, _3, _4), priority);
      }

      //----- chord with 5 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c, int priority=0)
      {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if (port_type(p1) == port::synch) sp = &p1;
	if (port_type(p2) == port::synch || port_type(p3) == port::synch || 
	    port_type(p4) == port::synch || port_type(p5) == port::synch)
	  throw synch_not_1st_exception();
	add_port(p1, bmap);
	add_port(p2, bmap);
	add_port(p3, bmap);
	add_port(p4, bmap);
	add_port(p5, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord5<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,CallT>(bmap, sp, this, p1, p2, p3, p4, p5, c, priority));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5>
      void chord_remove(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap))) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap, cd))
	  throw chord_remove_exception();
	port_del_chord(p1, cd.get(), cd->priority_);
	port_del_chord(p2, cd.get(), cd->priority_);
	port_del_chord(p3, cd.get(), cd->priority_);
	port_del_chord(p4, cd.get(), cd->priority_);
	port_del_chord(p5, cd.get(), cd->priority_);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap)))
	  throw chord_override_exception();	  
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord5<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,CallT>* cdp = (chord5<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,CallT>*)cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p1, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p2, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p3, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p4, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p5, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p1, (chord_type*)cdp, priority);
	    port_add_chord(p2, (chord_type*)cdp, priority);
	    port_add_chord(p3, (chord_type*)cdp, priority);
	    port_add_chord(p4, (chord_type*)cdp, priority);
	    port_add_chord(p5, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, 
		 R (ActorT::*c)(ArgT1, ArgT2, ArgT3, ArgT4, ArgT5), int priority=0) {
	chord(p1, p2, p3, p4, p5, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, 
			  R (ActorT::*c)(ArgT1, ArgT2, ArgT3, ArgT4, ArgT5), int priority=0) {
	chord_override(p1, p2, p3, p4, p5, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5), priority);
      }

      //----- chord with 6 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c, int priority=0)
      {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if (port_type(p1) == port::synch) sp = &p1;
	if (port_type(p2) == port::synch || port_type(p3) == port::synch || 
	    port_type(p4) == port::synch || port_type(p5) == port::synch || port_type(p6) == port::synch)
	  throw synch_not_1st_exception();
	add_port(p1, bmap);
	add_port(p2, bmap);
	add_port(p3, bmap);
	add_port(p4, bmap);
	add_port(p5, bmap);
	add_port(p6, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord6<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,CallT>(bmap, sp, this, p1, p2, p3, p4, p5, p6, c, priority));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
	port_add_chord(p6,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6>
      void chord_remove(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap) &&
	     find_port(p6, bmap))) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap, cd))
	  throw chord_remove_exception();
	port_del_chord(p1, cd.get(), cd->priority_);
	port_del_chord(p2, cd.get(), cd->priority_);
	port_del_chord(p3, cd.get(), cd->priority_);
	port_del_chord(p4, cd.get(), cd->priority_);
	port_del_chord(p5, cd.get(), cd->priority_);
	port_del_chord(p6, cd.get(), cd->priority_);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap) &&
	     find_port(p6, bmap)))
	  throw chord_override_exception();	  
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord6<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,CallT>* cdp = (chord6<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,CallT>*)cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p1, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p2, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p3, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p4, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p5, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p6, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p1, (chord_type*)cdp, priority);
	    port_add_chord(p2, (chord_type*)cdp, priority);
	    port_add_chord(p3, (chord_type*)cdp, priority);
	    port_add_chord(p4, (chord_type*)cdp, priority);
	    port_add_chord(p5, (chord_type*)cdp, priority);
	    port_add_chord(p6, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5, typename ArgT6>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, 
		 R (ActorT::*c)(ArgT1, ArgT2, ArgT3, ArgT4, ArgT5, ArgT6), int priority=0) {
	chord(p1, p2, p3, p4, p5, p6, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5, typename ArgT6>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, 
			  R (ActorT::*c)(ArgT1, ArgT2, ArgT3, ArgT4, ArgT5, ArgT6), int priority=0) {
	chord_override(p1, p2, p3, p4, p5, p6, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6), priority);
      }


      //----- chord with 7 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c, int priority=0)
      {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if (port_type(p1) == port::synch) sp = &p1;
	if (port_type(p2) == port::synch || port_type(p3) == port::synch || port_type(p4) == port::synch || 
	    port_type(p5) == port::synch ||port_type( p6) == port::synch || port_type(p7) == port::synch)
	  throw synch_not_1st_exception();
	add_port(p1, bmap);
	add_port(p2, bmap);
	add_port(p3, bmap);
	add_port(p4, bmap);
	add_port(p5, bmap);
	add_port(p6, bmap);
	add_port(p7, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord7<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,CallT>(bmap, sp, this, p1, p2, p3, p4, p5, p6, p7, c, priority));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
	port_add_chord(p6,cd.get(),priority);
	port_add_chord(p7,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7>
      void chord_remove(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap) &&
	     find_port(p6, bmap) &&
	     find_port(p7, bmap))) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap, cd))
	  throw chord_remove_exception();
	port_del_chord(p1, cd.get(), cd->priority_);
	port_del_chord(p2, cd.get(), cd->priority_);
	port_del_chord(p3, cd.get(), cd->priority_);
	port_del_chord(p4, cd.get(), cd->priority_);
	port_del_chord(p5, cd.get(), cd->priority_);
	port_del_chord(p6, cd.get(), cd->priority_);
	port_del_chord(p7, cd.get(), cd->priority_);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap) &&
	     find_port(p6, bmap) &&
	     find_port(p7, bmap)))
	  throw chord_override_exception();	  
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord7<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,CallT>* cdp = (chord7<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,CallT>*)cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p1, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p2, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p3, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p4, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p5, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p6, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p7, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p1, (chord_type*)cdp, priority);
	    port_add_chord(p2, (chord_type*)cdp, priority);
	    port_add_chord(p3, (chord_type*)cdp, priority);
	    port_add_chord(p4, (chord_type*)cdp, priority);
	    port_add_chord(p5, (chord_type*)cdp, priority);
	    port_add_chord(p6, (chord_type*)cdp, priority);
	    port_add_chord(p7, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5, typename ArgT6, typename ArgT7>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, 
		 R (ActorT::*c)(ArgT1,ArgT2,ArgT3,ArgT4,ArgT5,ArgT6,ArgT7), int priority=0) {
	chord(p1, p2, p3, p4, p5, p6, p7, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5, typename ArgT6, typename ArgT7>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, 
			  R (ActorT::*c)(ArgT1,ArgT2,ArgT3,ArgT4,ArgT5,ArgT6,ArgT7), int priority=0) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7), priority);
      }


      //----- chord with 8 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c, int priority=0)
      {
	port *sp = NULL;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if (port_type(p1) == port::synch) sp = &p1;
	if (port_type(p2) == port::synch || port_type(p3) == port::synch || port_type(p4) == port::synch || 
	    port_type(p5) == port::synch || port_type(p6) == port::synch || port_type(p7) == port::synch || port_type(p8) == port::synch)
	  throw synch_not_1st_exception();
	add_port(p1, bmap);
	add_port(p2, bmap);
	add_port(p3, bmap);
	add_port(p4, bmap);
	add_port(p5, bmap);
	add_port(p6, bmap);
	add_port(p7, bmap);
	add_port(p8, bmap);
	chord_data_validation(bmap);
	boost::shared_ptr<chord_type> cd(new chord8<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,PortT8,CallT>(bmap, sp, this, p1, p2, p3, p4, p5, p6, p7, p8, c, priority));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
	port_add_chord(p6,cd.get(),priority);
	port_add_chord(p7,cd.get(),priority);
	port_add_chord(p8,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8>
      void chord_remove(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap) &&
	     find_port(p6, bmap) &&
	     find_port(p7, bmap) &&
	     find_port(p8, bmap))) 
	  throw chord_remove_exception();
	boost::shared_ptr<chord_type> cd;
	if(!del_chord(bmap, cd))
	  throw chord_remove_exception();
	port_del_chord(p1, cd.get(), cd->priority_);
	port_del_chord(p2, cd.get(), cd->priority_);
	port_del_chord(p3, cd.get(), cd->priority_);
	port_del_chord(p4, cd.get(), cd->priority_);
	port_del_chord(p5, cd.get(), cd->priority_);
	port_del_chord(p6, cd.get(), cd->priority_);
	port_del_chord(p7, cd.get(), cd->priority_);
	port_del_chord(p8, cd.get(), cd->priority_);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c, int priority=0) {
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	if(!(find_port(p1, bmap) && 
	     find_port(p2, bmap) &&
	     find_port(p3, bmap) &&
	     find_port(p4, bmap) &&
	     find_port(p5, bmap) &&
	     find_port(p6, bmap) &&
	     find_port(p7, bmap) &&
	     find_port(p8, bmap)))
	  throw chord_override_exception();	  
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  chord8<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,PortT8,CallT>* cdp = (chord8<executor,max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,PortT8,CallT>*)cd.get();
	  cdp->call_ = c;
	  if (cdp->priority_ != priority) {
	    port_del_chord(p1, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p2, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p3, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p4, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p5, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p6, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p7, (chord_type*)cdp, cdp->priority_);
	    port_del_chord(p8, (chord_type*)cdp, cdp->priority_);
	    port_add_chord(p1, (chord_type*)cdp, priority);
	    port_add_chord(p2, (chord_type*)cdp, priority);
	    port_add_chord(p3, (chord_type*)cdp, priority);
	    port_add_chord(p4, (chord_type*)cdp, priority);
	    port_add_chord(p5, (chord_type*)cdp, priority);
	    port_add_chord(p6, (chord_type*)cdp, priority);
	    port_add_chord(p7, (chord_type*)cdp, priority);
	    port_add_chord(p8, (chord_type*)cdp, priority);
	    cdp->priority_ = priority;
	  }
	}
	else
	  throw chord_override_exception();
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5, typename ArgT6, typename ArgT7, typename ArgT8>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, 
		 R (ActorT::*c)(ArgT1,ArgT2,ArgT3,ArgT4,ArgT5,ArgT6,ArgT7,ArgT8), int priority=0) {
	chord(p1, p2, p3, p4, p5, p6, p7, p8, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename ActorT, typename R, typename ArgT1, typename ArgT2, typename ArgT3, typename ArgT4, typename ArgT5, typename ArgT6, typename ArgT7, typename ArgT8>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, 
			  R (ActorT::*c)(ArgT1,ArgT2,ArgT3,ArgT4,ArgT5,ArgT6,ArgT7,ArgT8), int priority=0) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, p8, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8), priority);
      }

    };

  }
}

#endif

  
