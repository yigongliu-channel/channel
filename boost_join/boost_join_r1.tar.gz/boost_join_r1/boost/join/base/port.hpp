//
// boost/join/port.hpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_JOIN_PORT_HPP
#define BOOST_JOIN_PORT_HPP

#include <exception>
#include <stdexcept>
#include <deque>
#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/join/base/join_base.hpp>
#include <boost/join/base/exceptions.hpp>

namespace boost {
  namespace join {

    //common interface of async/synch ports to actor(owner)
    //
    class actor_base;
    class chord_base;
    template <typename ArgT> class async_v;
    template <typename ResT, typename ArgT> class synch_v;
    template <typename ArgT> class async_f;
    template <typename ResT, typename ArgT> class synch_f;

    template <> 
    class async_v<void> {
    public:
      ///hacks for compile
      port *port_;  
      async_v(port *p) : port_(p) {}
      void operator()(void) {
	port_->put();
      }
    };
    template <> 
    class synch_v<void, void> {
    public:
      ///hacks for compile
      port *port_;  
      synch_v(port *p) : port_(p) {}
      void operator()(void) {
	port_->put();
      }
      void reply(void) {
      }
    };


    template <typename ArgT> 
    class async_f : public port {
    public:
      typedef ArgT argument_type;
      typedef ArgT arg1_type;
      typedef ArgT args_type;
      typedef async_v<ArgT> var_type;

      async_f(size_t sz=0) : port(port::async), max_size_(sz) {//sz==0 means unlimited
      } 

      void operator()(ArgT t) {
	if(actor_ == NULL) 
	  throw not_in_chord_exception();
	boost::mutex::scoped_lock lock(actor_->mutex_);
	if (max_size_> 0 && arg_.size() >= max_size_)
	  throw queue_overflow_exception();
	arg_.push_back(t);
	test_chord_fire();  //notify actor about a new msg
      }
      void put(ArgT t) {
	operator()(t);
      }
      ArgT &get(void) {
	return arg_.front();
      }
      void pop_top(void) {
	arg_.pop_front();
      }
      var_type top(void) {
	return var_type(this);
      }
    private:
      size_t max_size_;
      std::deque<ArgT> arg_;
    };

    template <> 
    class async_f<void> : public port {
    public:
      typedef void argument_type;
      typedef async_v<void> var_type;

      async_f(size_t sz=0) : port(port::async) {
      } 

      void operator()(void) {
	if(actor_ == NULL) 
	  throw not_in_chord_exception();
	boost::mutex::scoped_lock lock(actor_->mutex_);
	test_chord_fire();  //notify actor about a new msg
      }
      void put(void) {
	operator()();
      }
      void pop_top(void) {
      }
      var_type top(void) {
	return var_type(this);
      }
    };

    class synch_port : public port {
    public:
      typedef std::pair<chord_base*,actor_base::callable> chord_data_type;
      synch_port() : port(port::synch), num_waiting_(0) {}

      void set_chord(chord_data_type c) {
	actor_->log.msg("set_chord");
	fired_chords_.push_back(c);
      }

      //async call will call this to transfer control
      void transfer(chord_data_type c) {
	fired_chords_.push_back(c);
	if (num_waiting_ > 0)
	  cond_.notify_one();	  
	actor_->log.msg("transfer");
      }

      void finish(boost::shared_ptr<chord_exception_base> ep) {
	if (ep != NULL) 
	  chord_excepts_.push_back(ep);
	if (num_waiting_ > 0)
	  cond_.notify_one();
	actor_->log.msg("finish");
      }

      boost::condition cond_;
      int num_waiting_;
      std::deque<chord_data_type> fired_chords_;
      std::deque<boost::shared_ptr<chord_exception_base> > chord_excepts_;
    };

    template <typename ResT, typename ArgT>
    class synch_f : public synch_port {
    public:
      typedef ArgT argument_type;
      typedef ResT result_type;
      typedef synch_v<ResT, ArgT> var_type;

      synch_f(size_t sz=0) :  max_size_(sz) {//sz==0 means unlimited
      } 

      ResT operator()(ArgT t) {
	if(actor_ == NULL) 
	  throw not_in_chord_exception();
	boost::mutex::scoped_lock lock(actor_->mutex_);
	if (max_size_> 0 && arg_.size() >= max_size_)
	  throw queue_overflow_exception();
	arg_.push_back(t);
	if(!test_chord_fire()) {
	  //no chord ready to fire 
	  //block wait here till awaken by another msg
	  num_waiting_++;
	  cond_.wait(lock);
	  num_waiting_--;
	}
	if (!fired_chords_.empty()) { //assigned to complete chord callback
	  actor_->log.msg("synch<resT,argT> fired");
	  chord_data_type cd = fired_chords_.front();
	  fired_chords_.pop_front();
	  boost::shared_ptr<chord_exception_base> ep;
	  lock.unlock();
	  try {
	    cd.second();  //invoke callback in my thread
	  } 
	  catch(actor_base::chord_exception *e) {
	    actor_->log.msg("synch<resT,argT> chord body exception");
	    ep.reset(e);
	  }
	  catch(...) {
	    //save the caught exception() here
	    //and rethrow it to all synch<> threads after regrabbing lock
	    actor_->log.msg("synch<resT,argT> chord body UNKNOWN exception");
	    ep.reset(new chord_exception_t<std::runtime_error>("UNKNOWN exception inside synch<resT,argT> chord body"));
	  }
	  lock.lock();
	  if (ep)
	    chord_excepts_.push_back(boost::shared_ptr<chord_exception_base>(ep));
	  if(cd.first->num_synch_ports_ > 1)
	    actor_->notify_other_synch_calls_finish(cd.first, this, ep);
	  actor_->log.msg("synch<resT,argT> cb done");
	}
	if (!chord_excepts_.empty()) {
	  boost::shared_ptr<chord_exception_base> r = chord_excepts_.front();
	  chord_excepts_.pop_front();
	  actor_->log.msg("synch<resT,argT> reraise chord exception");
	  r->raise();  //exception reraise here
	}
	if (!ret_.empty()) {
	  ResT r = ret_.front();
	  ret_.pop_front();
	  return r;
	}
	else {
	  actor_->log.msg("missing_result_exception");
	  throw missing_result_exception();
	}
      }

      ResT put(ArgT t) {
	return operator()(t);
      }

      ArgT &get(void) {
	return arg_.front();
      }
      void pop_top(void) {
	arg_.pop_front();
      }
      var_type top(void) {
	return var_type(this);
      }

      //the following methods called from inside "join-method" body
      //lock needed
      void reply(ResT r) {
	boost::mutex::scoped_lock lock(actor_->mutex_);
	ret_.push_back(r);
	actor_->log.msg("reply set1 ");
      }

    private:
      size_t max_size_;
      std::deque<ArgT> arg_;
      std::deque<ResT> ret_;
    };


    template <typename ArgT>
    class synch_f<void, ArgT> : public synch_port {
    public:
      typedef ArgT argument_type;
      typedef void result_type;
      typedef synch_v<void, ArgT> var_type;

      synch_f(size_t sz=0) : max_size_(sz) {//sz==0 means unlimited
      } 

      void operator()(ArgT t) {
	if(actor_ == NULL) 
	  throw not_in_chord_exception();
	boost::mutex::scoped_lock lock(actor_->mutex_);
	if (max_size_> 0 && arg_.size() >= max_size_)
	  throw queue_overflow_exception();
	arg_.push_back(t);
	if(!test_chord_fire()) {
	  //no chord ready to fire 
	  //block wait here till awaken by another msg
	  num_waiting_++;
	  cond_.wait(lock);
	  num_waiting_--;
	}
	if (!fired_chords_.empty()) { //assigned to complete chord callback
	  actor_->log.msg("synch<void, argT> fired");
	  chord_data_type cd = fired_chords_.front();
	  fired_chords_.pop_front();
	  boost::shared_ptr<chord_exception_base> ep;
	  lock.unlock();
	  try {
	    cd.second();  //invoke callback in my thread
	  } 
	  catch(actor_base::chord_exception *e) {
	    actor_->log.msg("synch<void,resT> chord body exception");
	    ep.reset(e);
	  }
	  catch(...) {
	    //save the caught exception() here
	    //and rethrow it to all synch<> threads after regrabbing lock
	    actor_->log.msg("synch<void,resT> chord body UNKNOWN exception");
	    ep.reset(new chord_exception_t<std::runtime_error>("UNKNOWN exception inside synch<void,resT> chord body"));
	  }
	  lock.lock();
	  if (ep)
	    chord_excepts_.push_back(boost::shared_ptr<chord_exception_base>(ep));
	  if(cd.first->num_synch_ports_ > 1)
	    actor_->notify_other_synch_calls_finish(cd.first, this, ep);
	  actor_->log.msg("synch<void, argT> done");
	}
	if (!chord_excepts_.empty()) {
	  boost::shared_ptr<chord_exception_base> r = chord_excepts_.front();
	  chord_excepts_.pop_front();
	  r->raise();  //exception reraise here
	}
	return;
      }

      void put(ArgT t) {
	operator()(t);
      }

      ArgT &get(void) {
	return arg_.front();
      }
      void pop_top(void) {
	arg_.pop_front();
      }
      var_type top(void) {
	return var_type(this);
      }

      //the following methods called from inside "join-method" body
      //lock needed
      void reply(void) { //do nothing, since no ret val
      }
      //
    private:
      size_t max_size_;
      std::deque<ArgT> arg_;
    };

    template <typename ResT>
    class synch_f<ResT,void> : public synch_port {
    public:
      typedef void argument_type;
      typedef ResT result_type;
      typedef synch_v<ResT, void> var_type;

      synch_f(size_t sz=0) {} 

      ResT operator()(void) {
	if(actor_ == NULL) 
	  throw not_in_chord_exception();
	boost::mutex::scoped_lock lock(actor_->mutex_);

	if(!test_chord_fire()) {
	  //no chord ready to fire 
	  //block wait here till awaken by another msg
	  num_waiting_++;
	  cond_.wait(lock);
	  num_waiting_--;
	}
	if (!fired_chords_.empty()) { //assigned to complete chord callback
	  actor_->log.msg("synch<ResT,void> fired");
	  chord_data_type cd = fired_chords_.front();
	  fired_chords_.pop_front();
	  boost::shared_ptr<chord_exception_base> ep;
	  lock.unlock();
	  try {
	    cd.second();  //invoke callback in my thread
	  } 
	  catch(actor_base::chord_exception *e) {
	    actor_->log.msg("synch<ResT,void> chord body exception");
	    ep.reset(e);
	  }
	  catch(...) {
	    //save the caught exception() here
	    //and rethrow it to all synch<> threads after regrabbing lock
	    actor_->log.msg("synch<ResT,void> chord body UNKNOWN exception");
	    ep.reset(new chord_exception_t<std::runtime_error>("UNKNOWN exception inside synch<ResT,void> chord body"));
	  }
	  lock.lock();
	  if (ep)
	    chord_excepts_.push_back(boost::shared_ptr<chord_exception_base>(ep));
	  if(cd.first->num_synch_ports_ > 1)
	    actor_->notify_other_synch_calls_finish(cd.first, this, ep);
	  actor_->log.msg("synch<ResT,void> done");
	}

	if (!chord_excepts_.empty()) {
	  boost::shared_ptr<chord_exception_base> r = chord_excepts_.front();
	  chord_excepts_.pop_front();
	  r->raise();  //exception reraise here
	}
	if (!ret_.empty()) {
	  ResT r = ret_.front();
	  ret_.pop_front();
	  return r;
	}
	else {
	  actor_->log.msg("missing_result_exception");
	  throw missing_result_exception();
	}
      }

      void put(void) {
	operator()();
      }

      //the following methods called from inside "join-method" body
      //lock needed
      void reply(ResT r) {
	boost::mutex::scoped_lock lock(actor_->mutex_);
	ret_.push_back(r);
	actor_->log.msg("reply set2 ");
      }
      void pop_top(void) {
      }

      var_type top(void) {
	return var_type(this);
      }
    private:
      std::deque<ResT> ret_;
    };


    template <>
    class synch_f<void, void> : public synch_port {
    public:
      typedef void argument_type;
      typedef void result_type;
      typedef synch_v<void, void> var_type;

      synch_f(size_t sz=0) {} 

      void operator()(void) {
	if(actor_ == NULL) 
	  throw not_in_chord_exception();
	boost::mutex::scoped_lock lock(actor_->mutex_);

	if(!test_chord_fire()) {
	  //no chord ready to fire 
	  //block wait here till awaken by another msg
	  num_waiting_++;
	  cond_.wait(lock);
	  num_waiting_--;
	}
	if (!fired_chords_.empty()) { //assigned to complete chord callback
	  actor_->log.msg("synch<void,void> fired");
	  chord_data_type cd = fired_chords_.front();
	  fired_chords_.pop_front();
	  boost::shared_ptr<chord_exception_base> ep;
	  lock.unlock();
	  try {
	    cd.second();  //invoke callback in my thread
	  } 
	  catch(actor_base::chord_exception *e) {
	    actor_->log.msg("synch<void,void> chord body exception");
	    ep.reset(e);
	  }
	  catch(...) {
	    //save the caught exception() here
	    //and rethrow it to all synch<> threads after regrabbing lock
	    actor_->log.msg("synch<void,void> chord body UNKNOWN exception");
	    ep.reset(new chord_exception_t<std::runtime_error>("UNKNOWN exception inside synch<void,void> chord body"));
	  }
	  lock.lock();
	  if (ep)
	    chord_excepts_.push_back(boost::shared_ptr<chord_exception_base>(ep));
	  if(cd.first->num_synch_ports_ > 1)
	    actor_->notify_other_synch_calls_finish(cd.first, this, ep);
	  actor_->log.msg("synch<void,void> done");
	}

	if (!chord_excepts_.empty()) {
	  boost::shared_ptr<chord_exception_base> r = chord_excepts_.front();
	  chord_excepts_.pop_front();
	  r->raise();  //exception reraise here
	}
	return;
      }

      void put(void) {
	operator()();
      }

      //the following methods called from inside "join-method" body
      //lock needed
      void reply(void) {
      } //do nothing, since no ret val
      void pop_top(void) {
      }

      var_type top(void) {
	return var_type(this);
      }

    private:
    };


    template <typename ArgT> 
    class async_v {
    public:
      async_f<ArgT> *port_;
      ArgT arg1;
      async_v(async_f<ArgT> *p) :
	port_(p) {
	  arg1 = port_->get();
      }
      operator ArgT() {
	return arg1;
      }
      ArgT &arg(void) {
	return arg1;
      }
      void operator()(ArgT t) {
	port_->put(t);
      }
    };

    template <typename ResT, typename ArgT> 
    class synch_v {
    public:
      synch_f<ResT, ArgT> *port_;
      ArgT arg1;
      bool ret_flag_;
      synch_v(synch_f<ResT, ArgT> *p) :
	port_(p), ret_flag_(false) {
	  arg1 = port_->get();
      }
      operator ArgT(void) {
	return arg1;
      }
      ArgT &arg(void) {
	return arg1;
      }
      ResT operator()(ArgT t) {
	return port_->put(t);
      }
      void reply(ResT r) {
	if(ret_flag_) {
	  throw multi_return_exception();
	}
	ret_flag_ = true;
	port_->reply(r);
      }
    };

    template <typename ArgT> 
    class synch_v<void, ArgT> {
    public:
      synch_f<void, ArgT> *port_;
      ArgT arg1;
      bool ret_flag_;
      synch_v(synch_f<void, ArgT> *p) :
	port_(p), ret_flag_(false) {
	  arg1 = port_->get();
      }
      operator ArgT(void) {
	return arg1;
      }
      ArgT &arg(void) {
	return arg1;
      }
      void operator()(ArgT t) {
	port_->put(t);
      }
      void reply(void) {
	if(ret_flag_) {
	  throw multi_return_exception();
	}
	ret_flag_ = true;
	port_->reply();
      }
    };

    template <typename ResT> 
    class synch_v<ResT, void> {
    public:
      synch_f<ResT, void> *port_;
      bool ret_flag_;
      synch_v(synch_f<ResT, void> *p) :
	port_(p), ret_flag_(false) {}
      ResT operator()(void) {
	return port_->put();
      }
      void reply(ResT r) {
	if(ret_flag_) {
	  throw multi_return_exception();
	}
	//port_->actor_->log.msg("reply set4 ");
	ret_flag_ = true;
	port_->reply(r);
      }
    };

  }
}

#endif
