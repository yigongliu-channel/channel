//
// boost/join/actor.hpp
//
// Copyright (c) 2007 Yigong Liu (yigongliu at gmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_JOIN_ACTOR_HPP
#define BOOST_JOIN_ACTOR_HPP

#include <vector>
#include <bitset>
#include <boost/shared_ptr.hpp>
#include <boost/bind.hpp>
#include <boost/join/base/join_base.hpp>
#include <boost/join/base/exceptions.hpp>

namespace boost {
  namespace join {

    template <bool flag, typename T, typename U>
    struct select { typedef T result; };
    template <typename T, typename U>
    struct select<false, T, U> { typedef U result; };

    template <size_t size>
    struct bitmap {
      enum {
	max_size = size
      };
      typedef typename select<(size<=32), unsigned int, std::bitset<size> >::result bitset_type;
      bitset_type bitmap_;
      bitmap(unsigned int val=0) : bitmap_(val) {}
      void set(bitmap &t) { bitmap_ |= t.bitmap_; }
      void clear(bitmap &t) { bitmap_ &= ~t.bitmap_; }
      bool test(bitmap &t) { return (bitmap_ & t.bitmap_) != 0; }
      bool match(bitmap &b) { return (~bitmap_ & b.bitmap_) == 0; }
      bool operator==(bitmap &t) { return bitmap_ == t.bitmap_; }
      size_t num_of_ones(void) {
	size_t num = 0;
	for(int i = 0; i<max_size; i++)
	  if (bitmap_ & (1<<i)) num++;
	return num;
      }
    };

    template <size_t size> class actor;

    template <size_t max_size>
    class chord_common : public chord_base {
    public:
      actor<max_size> *actor_;
      typename actor<max_size>::bitmap_t mask_;// ports of this chord
      size_t num_ports_; //for scheduling policy fire_as_much_as_possible
      actor_base::callable cb_;//callback to fire; here chord_cb already bind with ports;
      bool guard_defined_;

      chord_common(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a) : 
	chord_base(sp), actor_(a), mask_(m), cb_(0), guard_defined_(false) {
	num_ports_ = m.num_of_ones();
      }
      virtual ~chord_common() {}

      virtual bool validate_guard(void) = 0;
      virtual void capture_arguments(void) = 0;

      template <typename PortT>
      typename PortT::var_type
      top(PortT &p) {
	return p.top();
      }
      template <typename PortT>
      std::vector<typename PortT::var_type>
      top(std::vector<PortT> &vp) {
	std::vector<typename PortT::var_type> vv;
	for(size_t i=0; i<vp.size(); i++)
	  vv.push_back(vp[i].top());
	return vv;
      }
      template <typename PortT>
      void pop_top(PortT &p) {
	p.pop_top();
      }
      template <typename PortT>
      void pop_top(std::vector<PortT> &vp) {
	for(size_t i=0; i<vp.size(); i++)
	  vp[i].pop_top();
      }

      void fire(port *caller_port) {
	if(caller_port->type_ == port::synch) //caller is sync
	  ((synch_port*)caller_port)->set_chord(std::make_pair(this,cb_)); //invoke callback later in the same caller thread
	else { //caller is async_f
	  //based on ports_, find any synch_port in this chord
	  //and transfer control to its thread and let its  thread to run callback
	  synch_port *sync_p = NULL;
	  if (num_synch_ports_>0) 
	    sync_p = actor_->find_synch_port(mask_);
	  if (sync_p)
	    sync_p->transfer(std::make_pair(this,cb_));
	  else { //no sync ports in chord
	    if(actor_->spawn_ != NULL)
	      (*actor_->spawn_)(cb_); //spawn callback in executor
	    else
	      throw no_executor_exception();
	  }
	}
      }
    };

    struct null_guard {};
    template <typename T>
    struct type2type {
      typedef T orig_type;
    };
    bool guard_defined(type2type<null_guard>) { return false; }
    template <typename guard_type>
    bool guard_defined(type2type<guard_type>) { return true; }

    template <typename PortT>
    struct var_type {
      typedef typename PortT::var_type result;
    };
    template <typename PortT>
    struct var_type<std::vector<PortT> > {
      typedef std::vector<typename PortT::var_type> result;
    };

    template <size_t max_size, typename PortT, typename CallT, typename GuardT>
    class chord1 : public chord_common<max_size> {
    public:
      PortT &port_;
      CallT call_;
      GuardT guard_;
      chord1(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT &p, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port_(p), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port_));
	pop_top(port_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	this->actor_->log.msg("validate_guard real_guard");
	return guard_(top(port_));
      }
      bool validate_guard(type2type<null_guard>) {
	this->actor_->log.msg("validate_guard null_guard");
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size, typename PortT1, typename PortT2, typename CallT, typename GuardT>
    class chord2 : public chord_common<max_size> {
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      CallT call_;
      GuardT guard_;
      chord2(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT1 &p1, PortT2 &p2, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port1_(p1), port2_(p2), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port1_), top(port2_));
	pop_top(port1_);
	pop_top(port2_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	return guard_(top(port1_), top(port2_));
      }
      bool validate_guard(type2type<null_guard>) {
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename CallT, typename GuardT>
    class chord3 : public chord_common<max_size> {
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      CallT call_;
      GuardT guard_;
      chord3(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port1_(p1), port2_(p2), port3_(p3), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port1_), top(port2_), top(port3_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	return guard_(top(port1_), top(port2_), top(port3_));
      }
      bool validate_guard(type2type<null_guard>) {
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT, typename GuardT>
    class chord4 : public chord_common<max_size> {
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      CallT call_;
      GuardT guard_;
      chord4(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port1_(p1), port2_(p2), port3_(p3), port4_(p4), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	return guard_(top(port1_), top(port2_), top(port3_), top(port4_));
      }
      bool validate_guard(type2type<null_guard>) {
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT, typename GuardT>
    class chord5 : public chord_common<max_size> {
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      CallT call_;
      GuardT guard_;
      chord5(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	return guard_(top(port1_), top(port2_), top(port3_), top(port4_), top(port5_));
      }
      bool validate_guard(type2type<null_guard>) {
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT, typename GuardT>
    class chord6 : public chord_common<max_size> {
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      PortT6 &port6_;
      CallT call_;
      GuardT guard_;
      chord6(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), port6_(p6), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
	pop_top(port6_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	return guard_(top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_));
      }
      bool validate_guard(type2type<null_guard>) {
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT, typename GuardT>
    class chord7 : public chord_common<max_size> {
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      PortT6 &port6_;
      PortT7 &port7_;
      CallT call_;
      GuardT guard_;
      chord7(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), port6_(p6), port7_(p7), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_), top(port7_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
	pop_top(port6_);
	pop_top(port7_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	return guard_(top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_), top(port7_));
      }
      bool validate_guard(type2type<null_guard>) {
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size, typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT, typename GuardT>
    class chord8 : public chord_common<max_size> {
    public:
      PortT1 &port1_;
      PortT2 &port2_;
      PortT3 &port3_;
      PortT4 &port4_;
      PortT5 &port5_;
      PortT6 &port6_;
      PortT7 &port7_;
      PortT8 &port8_;
      CallT call_;
      GuardT guard_;
      chord8(typename actor<max_size>::bitmap_t &m, int sp, actor<max_size>* a, PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c, GuardT g) : chord_common<max_size>(m,sp,a), port1_(p1), port2_(p2), port3_(p3), port4_(p4), port5_(p5), port6_(p6), port7_(p7), call_(c), guard_(g) {
	this->guard_defined_ = guard_defined(type2type<GuardT>());
      }
      void capture_arguments(void) {
	this->cb_ = 0; //clear it
	this->cb_ = boost::bind(call_, top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_), top(port7_), top(port8_));
	pop_top(port1_);
	pop_top(port2_);
	pop_top(port3_);
	pop_top(port4_);
	pop_top(port5_);
	pop_top(port6_);
	pop_top(port7_);
	pop_top(port8_);
      }      
      template <typename guard_type>
      bool validate_guard(type2type<guard_type>) {
	return guard_(top(port1_), top(port2_), top(port3_), top(port4_), top(port5_), top(port6_), top(port7_), top(port8_));
      }
      bool validate_guard(type2type<null_guard>) {
	return false;
      }
      bool validate_guard(void) {
	return validate_guard(type2type<GuardT>());
      }
    };

    template <size_t max_size=32>
    class actor : public actor_base {
    public:
      typedef bitmap<max_size> bitmap_t;
      typedef typename actor_base::callable callable;
      typedef async_f<callable> executor; //in fact this is a task que to a real executor
      typedef chord_common<max_size> chord_type;
      //??1 should we integrate port_data content into port itself?
      //?? bitmap<size> depend on template - trouble! we want ports
      // and actors are independent types, so that diff ports can be
      // used with diff actors
      //still use port_data, however dont allocate them from heap, since
      //they are really small, just copy their value into vector
      //so 
      //vector<port_data> ports_; since it is continuous array, when we read
      //it, use reference
      typedef struct port_data_ {
	port *port_;
	bitmap_t mask_;
      } port_data;


      enum dispatch_policy {
	fire_as_soon_as_possible, //(first match will fire)
	fire_as_much_as_possible,  //(longest match will fire)
	fire_by_round_robin  //(round robin)
      };

      executor *spawn_;
      dispatch_policy dispatcher_;
      bitmap_t status_; //bitmap marking which port is active
      std::vector<port_data> ports_; //all unique ports in this actor, actor not owning
      //them and will not destroy them, actor will destroy port_data
      std::vector<boost::shared_ptr<chord_type> > chords_; //actor owns chords_ and will destroy them

      actor(executor *s = NULL, const char *name = NULL, 
	    dispatch_policy d = fire_as_soon_as_possible) : 
	actor_base(name), spawn_(s), dispatcher_(d), status_(0){}

      ~actor() {
	//for(size_t i=0; i<ports_.size(); i++) 
	//ports_[i].port_->reset();
      }

      //ports call this to notify that a new msg comes
      //return: true - chord fired, false - chord not fired
      bool port_invoked(int ind) {
	port_data &pd(ports_[ind]);
	pd.port_->num_pending_++;
	if(status_.test(pd.mask_)) {
	  //already set
	  //do nothing
	} else {
	  status_.set(pd.mask_);
	  chord_type *c = scan_chords(pd.port_); //find chord to fire based on dispatch_policy
	  if(c != NULL) {
	    //update msg arrival status first, mark msgs to be consumed as
	    //"unavailable", kinds of "reserve" these msgs
	    //so that thread-scheduling will not interfere: another thread may come in
	    //between try to take some of these msgs
	    update_status(c->mask_);
	    c->capture_arguments();
	    c->fire(pd.port_);
	    return true;
	  }
	}
	return false;
      }

      //find any chords can be fired, based on dispatch_policy:
      //. match_as_soon_as_possible (first match will fire)
      //. match_as_much_as_possible (longest match will fire)
      chord_type * scan_chords(port *p) {
	chord_type *chord_ready = NULL;

	if (dispatcher_ == fire_as_soon_as_possible) {
	  for(size_t i=0; i<p->chords_.size() && chord_ready == NULL; i++) 
	    for(size_t j=0; j<p->chords_[i].size() && chord_ready == NULL; j++) {
	      if(status_.match(((chord_type *)p->chords_[i][j])->mask_) && 
		 (((chord_type *)p->chords_[i][j])->guard_defined_ == false ||
		  ((chord_type *)p->chords_[i][j])->validate_guard()))
		chord_ready = (chord_type *)p->chords_[i][j];
	    }
	} 
	else if (dispatcher_ == fire_as_much_as_possible) { 
	  for(size_t i=0; i<p->chords_.size() && chord_ready == NULL; i++) {
	    unsigned int chord_size = 0;
	    for(size_t j=0; j<p->chords_[i].size(); j++) {
	      if(((chord_type *)p->chords_[i][j])->num_ports_ > chord_size) {
		if(status_.match(((chord_type *)p->chords_[i][j])->mask_) && 
		   (((chord_type *)p->chords_[i][j])->guard_defined_ == false ||
		    ((chord_type *)p->chords_[i][j])->validate_guard())) {
		  chord_ready = (chord_type *)p->chords_[i][j];
		  chord_size = chord_ready->num_ports_;
		}
	      }	    
	    }
	  }
	}
	else if (dispatcher_ == fire_by_round_robin) { 
	  for(size_t i=0; i<p->chords_.size() && chord_ready == NULL; i++) 
	    if(p->chords_[i].size()>0) {
	      size_t min = p->last_chord_fired_[i]+1;
	      for(size_t j=min; j<p->chords_[i].size() && chord_ready == NULL; j++) {
		if(status_.match(((chord_type *)p->chords_[i][j])->mask_) && 
		   (((chord_type *)p->chords_[i][j])->guard_defined_ == false ||
		    ((chord_type *)p->chords_[i][j])->validate_guard())) {
		  chord_ready = (chord_type *)p->chords_[i][j];
		  p->last_chord_fired_[i] = j;
		}
	      }
	      if (chord_ready == NULL && min > 0) 
		for(size_t j=0; j<min && chord_ready == NULL; j++) {
		  if(status_.match(((chord_type *)p->chords_[i][j])->mask_) && 
		     (((chord_type *)p->chords_[i][j])->guard_defined_ == false ||
		      ((chord_type *)p->chords_[i][j])->validate_guard())) {
		    chord_ready = (chord_type *)p->chords_[i][j];
		    p->last_chord_fired_[i] = j;
		  }
		}
	    }
	}

	return chord_ready;
      }

      //one msg will be taken from each port in mask
      //query these ports to see if any msg remaininf and
      //if its bit in status_ should be flipped
      void update_status(bitmap_t &chord_mask) {
	for(size_t i=0; i<ports_.size(); i++)
	  if(chord_mask.test(ports_[i].mask_)) {
	    ports_[i].port_->num_pending_--;
	    if(ports_[i].port_->num_pending_ == 0)
	      status_.clear(ports_[i].mask_);
	  }
      }

      synch_port* find_synch_port(bitmap_t &chord_mask) {
	for(size_t i=0; i<ports_.size(); i++)
	  if(chord_mask.test(ports_[i].mask_))
	    if(ports_[i].port_->type_ == port::synch)
	      return ((synch_port*)ports_[i].port_);
	return NULL;
      }

      void notify_other_synch_calls_finish(chord_base *cc, port *p, boost::shared_ptr<chord_exception_base> ep) {
	chord_type *c = (chord_type*)cc;
	for(size_t i=0; i<ports_.size(); i++)
	  if(c->mask_.test(ports_[i].mask_))
	    if(ports_[i].port_->type_ == port::synch &&
	       ports_[i].port_ != p)
	      ((synch_port*)ports_[i].port_)->finish(ep);
      }

      //
      // utils methods for creating chords
      //
      template <typename PortT>
      void add(PortT &p, bitmap_t &bmap, int &num_sync) {
	port *pp = &p;
	port_data pd;
	int ind = -1;
	if(pp->actor_ != NULL && pp->actor_ != this) 
	  throw double_association_exception();
	num_sync += (pp->type_ == port::synch)?1:0;
	for(size_t i=0; i<ports_.size() && ind == -1;i++)
	  if(pp == ports_[i].port_) {
	    ind = i;
	    pd = ports_[i];
	  }
	if (ind == -1) {
	  ind = ports_.size();
	  if((size_t)ind >= max_size) {
	    log.msg("too_many_ports_exception thrown");
	    throw too_many_ports_exception();
	  }
	  pd.port_ = pp;
	  pd.mask_ = bitmap_t(1<<ind);
	  ports_.push_back(pd);
	  pp->actor_ = this;
	  pp->index_ = ind;
	  pp->num_pending_ = 0;
	}
	bmap.set(pd.mask_);
      }
      template <typename PortT>
      void add(std::vector<PortT> &vp, bitmap_t &bmap, int &num_sync) {
	for(size_t i=0; i<vp.size(); i++) 
	  add(vp[i], bmap, num_sync);
      }
      template <typename PortT>
      void port_add_chord(PortT &p, chord_base *c, int priority) {
	if(p.chords_.size() < ((size_t)priority+1))
	  for(size_t i=p.chords_.size(); i<((size_t)priority+1); i++) {
	    p.chords_.push_back(std::vector<chord_base*>());
	    p.last_chord_fired_.push_back(-1);
	  }
	p.chords_[priority].push_back(c);
      }
      template <typename PortT>
      void port_add_chord(std::vector<PortT> &vp, chord_base *c, int priority) {
	for(size_t i=0; i<vp.size(); i++)
	  port_add_chord(vp[i], c, priority);
      }
      bool find_chord(bitmap_t &bmap, boost::shared_ptr<chord_type> &cd) {
	for(size_t i=0; i<chords_.size(); i++) {
	  if (chords_[i]->mask_ == bmap) {
	    cd = chords_[i];
	    return true;
	  }
	}
	return false;
      }
      void check_hidden_chord(bitmap_t &bmap) {
	for(size_t i=0; i<chords_.size(); i++) {
	  if (chords_[i]->mask_.match(bmap) || bmap.match(chords_[i]->mask_)) 
	    throw hidden_chord_exception();
	}
      }
      //
      // ***** "factory" methods to create chords ******
      //
      //--- chord with 1 port ---
      template <typename PortT, typename CallT, typename GuardT>
      void chord(PortT &p, CallT c, int priority, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord1<max_size,PortT,CallT,GuardT>(bmap, num_sync, this, p, c, g));
	chords_.push_back(cd);
	port_add_chord(p,cd.get(),priority);
      }

      template <typename PortT, typename CallT>
      void chord(PortT &p, CallT c, int priority=0) {
	chord(p, c, priority, null_guard());
      }

      template <typename PortT, typename CallT, typename GuardT>
      void chord_override(PortT &p, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord1<max_size,PortT,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord1<max_size,PortT,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT, typename CallT>
      void chord_override(PortT &p, CallT c) {
	chord_override(p, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT, typename ActorT>
      void chord(PortT &p, void (ActorT::*c)(typename var_type<PortT>::result), 
		 int priority, bool (ActorT::*g)(typename var_type<PortT>::result)) {
	chord(p, boost::bind(c, (ActorT*)this, _1), priority, boost::bind(g, (ActorT*)this, _1));
      }
      template <typename PortT, typename ActorT>
      void chord(PortT &p, void (ActorT::*c)(typename var_type<PortT>::result), int priority=0) {
	chord(p, boost::bind(c, (ActorT*)this, _1), priority);
      }
      template <typename PortT, typename ActorT>
      void chord_override(PortT &p, void (ActorT::*c)(typename var_type<PortT>::result), 
			  bool (ActorT::*g)(typename var_type<PortT>::result)) {
	chord_override(p, boost::bind(c, (ActorT*)this, _1), boost::bind(g, (ActorT*)this, _1));
      }
      template <typename PortT, typename ActorT>
      void chord_override(PortT &p, void (ActorT::*c)(typename var_type<PortT>::result)) {
	chord_override(p, boost::bind(c, (ActorT*)this, _1));
      }


      // ---- chord with 2 ports ----
      template <typename PortT1, typename PortT2, typename CallT, typename GuardT>
      void chord(PortT1 &p1, PortT2 &p2, CallT c, int priority, GuardT g)
      {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);	
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord2<max_size,PortT1,PortT2,CallT,GuardT>(bmap, num_sync, this, p1, p2, c, g));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2, CallT c, int priority=0)
      {
	chord(p1, p2, c, priority, null_guard());
      }

      template <typename PortT1, typename PortT2, typename CallT, typename GuardT>
      void chord_override(PortT1 &p1, PortT2 &p2, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord2<max_size,PortT1,PortT2,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord2<max_size,PortT2,PortT2,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT1, typename PortT2, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, CallT c) {
	chord_override(p1, p2, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result), 
		 int priority, 
		 bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result)) {
	chord(p1, p2, boost::bind(c, (ActorT*)this, _1, _2), 
	      priority, boost::bind(g, (ActorT*)this, _1, _2));
      }
      template <typename PortT1, typename PortT2, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result), int priority=0) {
	chord(p1, p2, boost::bind(c, (ActorT*)this, _1, _2), priority);
      }
      template <typename PortT1, typename PortT2, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result), 
			  bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result)) {
	chord_override(p1, p2, boost::bind(c, (ActorT*)this, _1, _2), boost::bind(g, (ActorT*)this, _1, _2));
      }
      template <typename PortT1, typename PortT2, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result)) {
	chord_override(p1, p2, boost::bind(c, (ActorT*)this, _1, _2));
      }

      //---- chord with 3 ports ---

      template <typename PortT1, typename PortT2, typename PortT3, typename CallT, typename GuardT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, CallT c, int priority, GuardT g)
      {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord3<max_size,PortT1,PortT2,PortT3,CallT,GuardT>(bmap, num_sync, this, p1, p2, p3, c, g));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2,  PortT3 &p3, CallT c, int priority=0)
      {
	chord(p1, p2, p3, c, priority, null_guard());
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename CallT, typename GuardT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord3<max_size,PortT1,PortT2,PortT3,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord3<max_size,PortT1,PortT2,PortT3,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, CallT c) {
	chord_override(p1, p2, p3, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result), 
		 int priority, 
		 bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result)) {
	chord(p1, p2, p3, boost::bind(c, (ActorT*)this, _1, _2, _3), priority, boost::bind(g, (ActorT*)this, _1, _2, _3));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result), int priority=0) {
	chord(p1, p2, p3, boost::bind(c, (ActorT*)this, _1, _2, _3), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result), 
			  bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result)) {
	chord_override(p1, p2, p3, boost::bind(c, (ActorT*)this, _1, _2, _3), boost::bind(g, (ActorT*)this, _1, _2, _3));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result)) {
	chord_override(p1, p2, p3, boost::bind(c, (ActorT*)this, _1, _2, _3));
      }

      //----- chord with 4 ports -----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT, typename GuardT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, CallT c, int priority, GuardT g)
      {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord4<max_size,PortT1,PortT2,PortT3,PortT4,CallT,GuardT>(bmap, num_sync, this, p1, p2, p3, p4, c, g));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2,  PortT3 &p3, PortT4 &p4, CallT c, int priority=0)
      {
	chord(p1, p2, p3, p4, c, priority, null_guard());
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT, typename GuardT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord4<max_size,PortT1,PortT2,PortT3,PortT4,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord4<max_size,PortT1,PortT2,PortT3,PortT4,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, CallT c) {
	chord_override(p1, p2, p3, p4, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result), 
		 int priority, 
		 bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result)) {
	chord(p1, p2, p3, p4, boost::bind(c, (ActorT*)this, _1, _2, _3, _4), priority, boost::bind(g, (ActorT*)this, _1, _2, _3, _4));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result), int priority=0) {
	chord(p1, p2, p3, p4, boost::bind(c, (ActorT*)this, _1, _2, _3, _4), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result),
			  bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result)) {
	chord_override(p1, p2, p3, p4, boost::bind(c, (ActorT*)this, _1, _2, _3, _4), boost::bind(g, (ActorT*)this, _1, _2, _3, _4));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result)) {
	chord_override(p1, p2, p3, p4, boost::bind(c, (ActorT*)this, _1, _2, _3, _4));
      }

      //----- chord with 5 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT, typename GuardT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c, int priority, GuardT g)
      {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord5<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,CallT,GuardT>(bmap, num_sync, this, p1, p2, p3, p4, p5, c, g));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2,  PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c, int priority=0)
      {
	chord(p1, p2, p3, p4, p5, c, priority, null_guard());
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT, typename GuardT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord5<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord5<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, CallT c) {
	chord_override(p1, p2, p3, p4, p5, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result), 
		 int priority, 
		 bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result)) {
	chord(p1, p2, p3, p4, p5, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5), priority, 
	      boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result), int priority=0) {
	chord(p1, p2, p3, p4, p5, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result), 
			  bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result)) {
	chord_override(p1, p2, p3, p4, p5, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5), 
		       boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result)) {
	chord_override(p1, p2, p3, p4, p5, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5));
      }

      //----- chord with 6 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT, typename GuardT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c, int priority, GuardT g)
      {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	add(p6, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord6<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,CallT,GuardT>(bmap, num_sync, this, p1, p2, p3, p4, p5, p6, c, g));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
	port_add_chord(p6,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2,  PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c, int priority=0)
      {
	chord(p1, p2, p3, p4, p5, p6, c, priority, null_guard());
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT, typename GuardT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	add(p6, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord6<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord6<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, CallT c) {
	chord_override(p1, p2, p3, p4, p5, p6, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result), 
		 int priority, 
		 bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result)) {
	chord(p1, p2, p3, p4, p5, p6, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6), priority, 
	      boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5, _6));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result), int priority=0) {
	chord(p1, p2, p3, p4, p5, p6, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result), 
			  bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result)) {
	chord_override(p1, p2, p3, p4, p5, p6, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6), 
		       boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5, _6));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result)) {
	chord_override(p1, p2, p3, p4, p5, p6, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6));
      }


      //----- chord with 7 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT, typename GuardT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c, int priority, GuardT g)
      {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	add(p6, bmap, num_sync);
	add(p7, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord7<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,CallT,GuardT>(bmap, num_sync, this, p1, p2, p3, p4, p5, p6, p7, c, g));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
	port_add_chord(p6,cd.get(),priority);
	port_add_chord(p7,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2,  PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c, int priority=0)
      {
	chord(p1, p2, p3, p4, p5, p6, p7, c, priority, null_guard());
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT, typename GuardT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	add(p6, bmap, num_sync);
	add(p7, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord7<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord7<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, CallT c) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result), 
		 int priority, 
		 bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result)) {
	chord(p1, p2, p3, p4, p5, p6, p7, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7), priority, 
	      boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result), int priority=0) {
	chord(p1, p2, p3, p4, p5, p6, p7, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result), 
			  bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result)) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7), 
		       boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result)) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7));
      }


      //----- chord with 8 ports ----

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT, typename GuardT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c, int priority, GuardT g)
      {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	add(p6, bmap, num_sync);
	add(p7, bmap, num_sync);
	add(p8, bmap, num_sync);
	if (dispatcher_ == fire_as_soon_as_possible)
	  check_hidden_chord(bmap);
	boost::shared_ptr<chord_type> cd(new chord8<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,PortT8,CallT,GuardT>(bmap, num_sync, this, p1, p2, p3, p4, p5, p6, p7, p8, c, g));
	chords_.push_back(cd);
	port_add_chord(p1,cd.get(),priority);
	port_add_chord(p2,cd.get(),priority);
	port_add_chord(p3,cd.get(),priority);
	port_add_chord(p4,cd.get(),priority);
	port_add_chord(p5,cd.get(),priority);
	port_add_chord(p6,cd.get(),priority);
	port_add_chord(p7,cd.get(),priority);
	port_add_chord(p8,cd.get(),priority);
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT>
      void chord(PortT1 &p1, PortT2 &p2,  PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c, int priority=0)
      {
	chord(p1, p2, p3, p4, p5, p6, p7, p8, c, priority, null_guard());
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT, typename GuardT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c, GuardT g) {
	int num_sync = 0;
	bitmap_t bmap;
	boost::mutex::scoped_lock lock(mutex_);
	add(p1, bmap, num_sync);
	add(p2, bmap, num_sync);
	add(p3, bmap, num_sync);
	add(p4, bmap, num_sync);
	add(p5, bmap, num_sync);
	add(p6, bmap, num_sync);
	add(p7, bmap, num_sync);
	add(p8, bmap, num_sync);
	boost::shared_ptr<chord_type> cd;
	if(find_chord(bmap, cd)) { //override chord
	  ((chord8<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,PortT8,CallT,GuardT>*)cd.get())->call_ = c;
	  ((chord8<max_size,PortT1,PortT2,PortT3,PortT4,PortT5,PortT6,PortT7,PortT8,CallT,GuardT>*)cd.get())->guard_ = g;
	}
	else
	  throw chord_override_exception();
      }

      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename CallT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, CallT c) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, p8, c, null_guard());
      }

      //wrappers for pointers to member methods as chord body
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result, typename var_type<PortT8>::result), 
		 int priority, 
		 bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result, typename var_type<PortT8>::result)) {
	chord(p1, p2, p3, p4, p5, p6, p7, p8, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8), priority, 
	      boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename ActorT>
      void chord(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, 
		 void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result, typename var_type<PortT8>::result), int priority=0) {
	chord(p1, p2, p3, p4, p5, p6, p7, p8, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8), priority);
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result, typename var_type<PortT8>::result), 
			  bool (ActorT::*g)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result, typename var_type<PortT8>::result)) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, p8, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8), 
		       boost::bind(g, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8));
      }
      template <typename PortT1, typename PortT2, typename PortT3, typename PortT4, typename PortT5, typename PortT6, typename PortT7, typename PortT8, typename ActorT>
      void chord_override(PortT1 &p1, PortT2 &p2, PortT3 &p3, PortT4 &p4, PortT5 &p5, PortT6 &p6, PortT7 &p7, PortT8 &p8, 
			  void (ActorT::*c)(typename var_type<PortT1>::result, typename var_type<PortT2>::result, typename var_type<PortT3>::result, typename var_type<PortT4>::result, typename var_type<PortT5>::result, typename var_type<PortT6>::result, typename var_type<PortT7>::result, typename var_type<PortT8>::result)) {
	chord_override(p1, p2, p3, p4, p5, p6, p7, p8, boost::bind(c, (ActorT*)this, _1, _2, _3, _4, _5, _6, _7, _8));
      }

    };

  }
}

#endif

  
