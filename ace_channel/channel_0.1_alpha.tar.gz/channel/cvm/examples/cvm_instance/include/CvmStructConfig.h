////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _CVM_STRUCT_CONFIG_H_
#define _CVM_STRUCT_CONFIG_H_

namespace channel {

  enum MessageFamily {
    SYSTEM_MESSAGE,
    APPLICATION_MESSAGE
  };

  struct StructId {
    MessageFamily family;
    int type;
    bool operator< (const StructId &id) const {
      if (family < id.family || (family == id.family && type < id.type))
	return true;
      return false;
    }
    bool operator== (const StructId &id) const {
      if (family == id.family && type == id.type)
	return true;
      return false;
    }
    bool operator!= (const StructId &id) const {
      if (family != id.family || type != id.type)
	return true;
      return false;
    }
  };


  template <>
    class IdTrait<StructId> {
    public:
    //define system msgs

    static StructId CHANNEL_CONN_MSG;
    static StructId CHANNEL_DISCONN_MSG;
    static StructId INIT_SUBSCRIPTION_INFO_MSG;
    static StructId INIT_PUBLICATION_INFO_MSG;
    static StructId SUBSCRIPTION_INFO_MSG;
    static StructId UNSUBSCRIPTION_INFO_MSG;
    static StructId PUBLICATION_INFO_MSG;
    static StructId UNPUBLICATION_INFO_MSG;

    typedef StructId IdType;

    //need the comparisons for msg matching and map
    static bool eq(const StructId &id1, const StructId &id2)
      { return id1 == id2; }
    static bool lt(const StructId &id1, const StructId &id2)
      { return id1 < id2; }

    static std::string idToString(const StructId id) {
      std::ostringstream os;
      os << "[Family:" << id.family << ", Type:" << id.type <<"]";
      return os.str();
    }

    static int size(const StructId &id2) {
      ACE_UNUSED_ARG(id2);
      return sizeof(StructId);
    }

    //Id marshalling code; CDR...
    static int marshal(ACE_OutputCDR &cdr, const StructId &id)
      {
	cdr << ACE_CDR::Long (id.family);
	cdr << ACE_CDR::Long (id.type);
	return cdr.good_bit();
      }
    static int demarshal(ACE_InputCDR &cdr, StructId &id)
      {
	ACE_CDR::Long d;
	cdr >> d;
	id.family = (MessageFamily) d;
	cdr >> d;
	id.type = (int) d;
	return cdr.good_bit();
      }    
  };

  /* system msg ids */
  StructId IdTrait<StructId>::CHANNEL_CONN_MSG = {SYSTEM_MESSAGE, 1};
  StructId IdTrait<StructId>::CHANNEL_DISCONN_MSG = {SYSTEM_MESSAGE, 2};
  StructId IdTrait<StructId>::INIT_SUBSCRIPTION_INFO_MSG = {SYSTEM_MESSAGE, 3};
  StructId IdTrait<StructId>::INIT_PUBLICATION_INFO_MSG = {SYSTEM_MESSAGE, 4};
  StructId IdTrait<StructId>::SUBSCRIPTION_INFO_MSG = {SYSTEM_MESSAGE, 5};
  StructId IdTrait<StructId>::UNSUBSCRIPTION_INFO_MSG = {SYSTEM_MESSAGE, 6};
  StructId IdTrait<StructId>::PUBLICATION_INFO_MSG = {SYSTEM_MESSAGE, 7};
  StructId IdTrait<StructId>::UNPUBLICATION_INFO_MSG = {SYSTEM_MESSAGE, 8};

};

typedef channel::StructId IdType;

/* application msg ids */
channel::StructId PING_MSG = {channel::APPLICATION_MESSAGE, 1};
channel::StructId PONG_MSG = {channel::APPLICATION_MESSAGE, 2};
channel::StructId TEST_STRING_MSG = {channel::APPLICATION_MESSAGE, 3};

#endif
