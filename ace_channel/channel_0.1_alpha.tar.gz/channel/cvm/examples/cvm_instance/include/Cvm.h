////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _CVM_H_
#define _CVM_H_

#include <Channel.h>
#include <CvmBase.h>
#include <Cvm_export.h>
#include <CvmStructConfig.h>  //here we define channel configuations
#include <Task_Msg.h>

using namespace channel;
using namespace cvm;

namespace cvm {

  //here we specialize/instantiate CVM (channel virtual machine) based on
  //message id type, router, and other parameters defined in CvmXXXConfig.h
  class Cvm_Export CvmChannel : public CvmBase<channel::Channel<IdType> >::Channel {
  };
  class Cvm_Export CvmUnixConnector : public CvmBase<channel::Channel<IdType> >::UnixConnector {
  };
  class Cvm_Export CvmTcpConnector : public CvmBase<channel::Channel<IdType> >::TcpConnector {
  };
  class Cvm_Export CvmTask : public CvmBase<channel::Channel<IdType> >::Task {
  public:
    typedef channel::Channel<IdType>::Msg Msg;
    typedef channel::Channel<IdType>::UnixSockConnector UnixSockConnector;
    typedef channel::Channel<IdType>::TcpSockConnector TcpSockConnector;
  };

};

#endif
