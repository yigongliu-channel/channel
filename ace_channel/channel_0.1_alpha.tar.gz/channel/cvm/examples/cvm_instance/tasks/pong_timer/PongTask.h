////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

//---------------------------------------------------------
//
// a demo application task:
//   inherited from Task and implement the following methods:
//   prepare() - preparation before app thread start, such
//               as registry for msgs, que, open files...
//   work() - main processing loop, call recv_msg to get app
//            msgs
//   cleanup() - called right before app thread exits, such
//               as unreg for msgs, ques, close files....
//
//   this task will be built as a shared lib and dynamically linked 
//   into runtime (main) thru conf file
//
//---------------------------------------------------------

#include <Cvm.h>

using namespace channel;
using namespace cvm;

class Pong_Task : public CvmTask {
 public:
  //Each app should implement the following 3 methods
  //to get app control flow going
  Status prepare(void); //initialization before thread starts
  Status cleanup(void); //cleanup before threads exit
  int work (void);       //main processing loop
  void send_ping_pong(void);
};


