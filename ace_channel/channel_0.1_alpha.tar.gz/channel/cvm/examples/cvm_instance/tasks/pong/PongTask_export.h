
// -*- C++ -*-
// $IdType$
// Definition for Win32 Export directives.
// This file is generated automatically by generate_export_file.pl PongTask
// ------------------------------
#ifndef PONGTASK_EXPORT_H
#define PONGTASK_EXPORT_H

#include "ace/config-all.h"

#if !defined (PONGTASK_HAS_DLL)
#  define PONGTASK_HAS_DLL 1
#endif /* ! PONGTASK_HAS_DLL */

#if defined (PONGTASK_HAS_DLL) && (PONGTASK_HAS_DLL == 1)
#  if defined (PONGTASK_BUILD_DLL)
#    define PongTask_Export ACE_Proper_Export_Flag
#    define PONGTASK_SINGLETON_DECLARATION(T) ACE_EXPORT_SINGLETON_DECLARATION (T)
#    define PONGTASK_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_EXPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  else /* PONGTASK_BUILD_DLL */
#    define PongTask_Export ACE_Proper_Import_Flag
#    define PONGTASK_SINGLETON_DECLARATION(T) ACE_IMPORT_SINGLETON_DECLARATION (T)
#    define PONGTASK_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_IMPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  endif /* PONGTASK_BUILD_DLL */
#else /* PONGTASK_HAS_DLL == 1 */
#  define PongTask_Export
#  define PONGTASK_SINGLETON_DECLARATION(T)
#  define PONGTASK_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#endif /* PONGTASK_HAS_DLL == 1 */

// Set PONGTASK_NTRACE = 0 to turn on library specific tracing even if
// tracing is turned off for ACE.
#if !defined (PONGTASK_NTRACE)
#  if (ACE_NTRACE == 1)
#    define PONGTASK_NTRACE 1
#  else /* (ACE_NTRACE == 1) */
#    define PONGTASK_NTRACE 0
#  endif /* (ACE_NTRACE == 1) */
#endif /* !PONGTASK_NTRACE */

#if (PONGTASK_NTRACE == 1)
#  define PONGTASK_TRACE(X)
#else /* (PONGTASK_NTRACE == 1) */
#  if !defined (ACE_HAS_TRACE)
#    define ACE_HAS_TRACE
#  endif /* ACE_HAS_TRACE */
#  define PONGTASK_TRACE(X) ACE_TRACE_IMPL(X)
#  include "ace/Trace.h"
#endif /* (PONGTASK_NTRACE == 1) */

#endif /* PONGTASK_EXPORT_H */

// End of auto generated file.
