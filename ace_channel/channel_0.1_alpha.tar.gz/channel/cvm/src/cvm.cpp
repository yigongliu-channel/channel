////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/*
** cvm - the generic runtime environment for channel based apps
*/

#include "ace/OS_main.h"
#include "ace/Service_Config.h"
#include "ace/Reactor.h"
#include "ace/ACE.h"
#include "ace/Auto_Ptr.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_stdio.h"
#include <iostream>
#include "ace/Thread_Manager.h"

using namespace std;


int ACE_TMAIN (int argc, ACE_TCHAR *argv[]) {
  ACE::debug('y');

  ACE_LOG_MSG->open
    (argv[0], ACE_Log_Msg::SYSLOG, ACE_TEXT (argv[0]));
  ACE_LOG_MSG->set_flags (ACE_Log_Msg::STDERR);

  ACE_STATIC_SVC_REGISTER (ACE_Service_Manager);

  ACE_Service_Config::open
    (argc, argv, ACE_TEXT (argv[0]), 0);

  ACE_DEBUG((LM_DEBUG, "main thread start listening for incoming conn...\n"));

  ACE_Reactor::instance ()->run_reactor_event_loop ();
  return 0;
}
