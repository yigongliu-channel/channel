////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <CvmService.h>
#include "ace/Service_Repository.h"
#include "ace/Service_Types.h"
#include "ace/Dynamic_Service.h"

using namespace cvm;

const ACE_TCHAR * CvmService::rtrv_name (void)
{
  ACE_Service_Repository_Iterator iter
    (*ACE_Service_Repository::instance (), 0);

  for (const ACE_Service_Type *st;
       iter.next (st) != 0; iter.advance()) {
    const ACE_Service_Type_Impl *type = st->type();
    if (type == 0) continue;
    if (((ACE_Service_Object *)this) == type->object ())
      return st->name ();
  }
  
  return "Unamed Object";
}
