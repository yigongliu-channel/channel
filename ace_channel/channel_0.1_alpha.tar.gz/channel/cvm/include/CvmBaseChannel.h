////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

//------------------------------------------------------
//
// CvmChannel.h - a dynamically linked Channel instance
//
//------------------------------------------------------

#ifndef _CVM_BASE_CHANNEL_H_
#define _CVM_BASE_CHANNEL_H_

#include "ace/Dynamic_Service.h"

#include <Channel.h>
#include <CvmService.h>

#include <iostream>
#include <vector>
#include <string>


namespace cvm {

  //use ACE_Service_Object to wrap a Channel object so that
  //it can be dynamically loaded
  template <class Channel>
  class CvmBaseChannel : public CvmService {
  public:
    Channel ch_;
    Channel * chan(void) { return &ch_; }
    // Constructor.
    // Service Configurator hook methods.
    virtual int init (int argc, ACE_TCHAR *argv[])
      {
	ACE_UNUSED_ARG(argc);
	ACE_UNUSED_ARG(argv);
	//-------------- Channel init -----------------
	ACE_DEBUG((LM_DEBUG, "### Channel is up and running ... ###\n"));
	return 0;
      }
    virtual int close (u_long)
      {
	//do nothing
	return 0;
      }
    virtual int fini ()
      {
	ACE_DEBUG((LM_DEBUG, "### Channel [%s] is shuting down ... ###\n", name().c_str()));

	ACE_DEBUG((LM_DEBUG, "Channel/Connector shutdown and ask all reader/writer threads exit...\n"));
	ACE_DEBUG((LM_DEBUG, "all reader/writeer threads exit...\n"));
	ACE_DEBUG((LM_DEBUG, "shutdown clock thread now...\n"));
	channel::Clock::instance()->stop();
	ACE_DEBUG((LM_DEBUG, "clock thread exit...\n"));
	//ACE_Reactor::end_event_loop ();
	ACE_OS::sleep(1);  //sleep 1 sec to give other threads another chance
	return 0;
      }
    virtual int info (ACE_TCHAR **strp, size_t length = 0) const
      {
	char buf[256];

	ACE_OS::sprintf (buf,
			 "CvmBaseChannel coming up ... \n");

	if (*strp == 0 && (*strp = ACE_OS::strdup (buf)) == 0)
	  return -1;
	else
	  ACE_OS::strncpy (*strp, buf, length);
	return ACE_OS::strlen (buf);
      }
    //virtual int suspend ();
    //virtual int resume ();

    static Channel *find_chan(const char* name) //find dynamic instantied channels
      {
	CvmBaseChannel<Channel> *d = ACE_Dynamic_Service<CvmBaseChannel<Channel> >::instance(ACE_TEXT(name));
	if (d==NULL)
	  return NULL;
	else
	  return d->chan();
      }
  };

};

#endif
