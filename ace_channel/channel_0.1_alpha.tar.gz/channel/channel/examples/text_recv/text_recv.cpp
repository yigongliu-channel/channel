////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * text_recv - simple C++ code to use channels to recv msgs
 * apply both asynchronous message passing and synchronous
 * event dispatching 
 */

#include "ace/OS_main.h"
#include "ace/ACE.h"
#include "ace/Auto_Ptr.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_stdio.h"
#include "ace/Get_Opt.h"

#include <iostream>
#include <string>

#include <Channel.h>
#include <Task_Msg.h>

using namespace std;
using namespace channel;

typedef Channel<string> Chan;
typedef Channel<string>::Msg ChanMsg;

class My_Callback: public Chan::Callback {
public:
  My_Callback(Chan *c) : Chan::Callback(c) {}
  Status process(Msg *msg) {
    Test_String_Msg *sm = (Test_String_Msg *)msg->data();
    ACE_DEBUG ((LM_DEBUG, "(%t) text_recv/My_Callback recv the following: \n%s\n",
		sm->data));
    ACE_DEBUG ((LM_DEBUG, "(%t) Please notice callback borrow Channel internal thread\n"));
 
    delete msg;

    return SUCCESS;
  }
};

int ACE_TMAIN (int argc, ACE_TCHAR *argv[]) {
  ACE::debug('y');

  ACE_LOG_MSG->open
    (argv[0], ACE_Log_Msg::SYSLOG, ACE_TEXT (argv[0]));
  ACE_LOG_MSG->set_flags (ACE_Log_Msg::STDERR);

  if (argc < 3) {
    ACE_DEBUG((LM_DEBUG, "Usage: text_recv my_unix_sock_path peer_unix_sock_path role(s-sender/r-recver)\n"));
    return -1;
  }
    
  bool role_recv = true;
  if (argc > 3 && argv[3][0] == 's')
    role_recv = false;

  //step1. create channel
  Chan * my_chan = new Chan(); 
  
  //step2. connect channels
  char *my_addr = argv[1];
  char *peer_addr = argv[2];
  Chan::UnixSockConnector *unix_conn = new Chan::UnixSockConnector(my_chan);
  if (unix_conn->open (my_addr) == FAILURE) {
    ACE_DEBUG((LM_DEBUG, "failed to open my unix domain socket at %s", my_addr));
    return -1;
  }
  ConnInfo ci(peer_addr);
  if (unix_conn->connect (ci) == FAILURE) { 
    //ACE_DEBUG((LM_DEBUG, "failed to connect peer unix domain socket at %s", peer_addr));
    if(!role_recv) 
      return -1;
    else {
      //since we are single-threaded here. cannot run
      //event-loop for reactor, so run a loop here
      while (unix_conn->is_connected (ci) == false) {
	ACE_DEBUG((LM_DEBUG, "wait for connection...\n"));
	::sleep(2);
      }
    }
  }

  //step3. create ports/callbacks attached to channels
  Chan::Port my_port(my_chan); //use my own queue
  My_Callback my_calbak(my_chan);
 
  //step4. pub/sub msgs thru ports/callbacks
  if(!role_recv) { 
    //sender
    my_port.publish_msg(TEST_STRING_MSG);
  } else {
    //recver
    my_port.subscribe_msg(TEST_STRING_MSG);
    my_calbak.subscribe_msg(TEST_STRING_MSG);
  }

  ACE_DEBUG ((LM_DEBUG,
	      "(%t) text_recv coming up ...\n"));

  ChanMsg *msg;
  Test_String_Msg *sm;

  //step5. recv msgs from ports and process them

  if(!role_recv) { 
    //sender
    for(;;) {
      ACE_DEBUG((LM_DEBUG,  "--- Please enter one line msg: "));
      Test_String_Msg *tm =  new Test_String_Msg();
      if (!gets (tm->data))
	break;
      tm->len = strlen(tm->data)+1;
      ChanMsg *m = new ChanMsg(TEST_STRING_MSG, (char*)tm,sizeof(Test_String_Msg));
      my_port.send_msg (m);
    }
  } else {
    //recver
    for(;;) {
      if(my_port.recv_msg(msg) == SUCCESS) {
	//handle_msg(msg);
	if (msg->type == TEST_STRING_MSG) {
	  sm = (Test_String_Msg *)msg->data();
	  sm->data[sm->len-1] = '\0';

	  ACE_DEBUG ((LM_DEBUG, "(%t) text_recv receive the following: \n%s\n",
		      sm->data));
 
	  delete msg;
	}
      } else {
	//handle_error();
	break;
      }
    }
  }

  ACE_DEBUG ((LM_DEBUG,
	      "(%t) text_recv  exits...\n"));

  return 0;
}
