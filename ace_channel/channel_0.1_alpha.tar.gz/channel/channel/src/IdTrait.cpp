////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <IdTrait.h>
#include <string>

using namespace std;
using namespace channel;

template <> string IdTrait<string>::CHANNEL_CONN_MSG = "_CHANNEL_CONN_MSG_";
template <> string IdTrait<string>::CHANNEL_DISCONN_MSG = "_CHANNEL_DISCONN_MSG_";
template <> string IdTrait<string>::INIT_SUBSCRIPTION_INFO_MSG = "_INIT_SUBSCRIPTION_INFO_MSG_";
template <> string IdTrait<string>::INIT_PUBLICATION_INFO_MSG = "_INIT_PUBLICATION_INFO_MSG_";
template <> string IdTrait<string>::SUBSCRIPTION_INFO_MSG = "_SUBSCRIPTION_INFO_MSG_";
template <> string IdTrait<string>::UNSUBSCRIPTION_INFO_MSG = "_UNSUBSCRIPTION_INFO_MSG_";
template <> string IdTrait<string>::PUBLICATION_INFO_MSG = "_PUBLICATION_INFO_MSG_";
template <> string IdTrait<string>::UNPUBLICATION_INFO_MSG = "_UNPUBLICATION_INFO_MSG_";

