////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <RouterBase.h>

using namespace channel;
short 
RouterBase::scope_checking_tbl_[][SCOPE_NUMBER * MEMBER_NUMBER] = {
  {1, 0, 1, 0, 0, 0},
  {0, 0, 0, 1, 0, 0},
  {1, 0, 1, 1, 0, 0},
  {0, 1, 1, 0, 0, 0},
  {0, 0, 0, 0, 0, 0},
  {0, 0, 0, 0, 0, 0}
};
