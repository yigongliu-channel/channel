////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _BASE_DEF_H_
#define _BASE_DEF_H_


namespace channel {

  typedef enum {
    SUCCESS,
    FAILURE
  } Status;

  typedef enum {
    SCOPE_UNDEFINED = -1,
    SCOPE_LOCAL = 0,
    SCOPE_REMOTE,
    SCOPE_GLOBAL,
    SCOPE_NUMBER
  } PubSub_Scope;

  typedef enum {
    MEMBER_LOCAL = 0,//local queues and callbacks
    MEMBER_REMOTE,   //interfaces to remote/local channels
    MEMBER_NUMBER
  } Member_Type;

  typedef enum {
    CONN_NULL = 0,
    CONN_INIT,
    CONN_ACTIVE
  } Interface_State;

  typedef enum { 
    UNIX_SOCK,
    INET_SOCK
  } Interface_Type;

  typedef enum {
    ACTIVE_ROLE,  //i start connection setup process
    PASSIVE_ROLE, //i wait for others to connect
  } Interface_Role;

  //owner of msgs responsible for
  //managing their lifetime, either delete or reuse
  typedef enum {
    RECEIVER,
    SENDER
  } MessageOwnerType;

  enum Oper_Type {
    OPER_PUBLISH = 0,
    OPER_UNPUBLISH,
    OPER_SUBSCRIBE,
    OPER_UNSUBSCRIBE
  };

};

#define ID2STR(id) Channel::idToString(id)


#endif
