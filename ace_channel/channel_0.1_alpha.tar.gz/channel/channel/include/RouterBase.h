////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _ROUTER_BASE_H_
#define _ROUTER_BASE_H_

#include <BaseDef.h>

namespace channel {

  ///common features of all routers
  ///specific routing data structures and algorithms are 
  ///implemented in concrete router classes
  class RouterBase {
  public:
    ///routing scope checking table:
    ///row: publish_member_type * SCOPE_NUMBER + publish_scope
    ///col: subscribe_member_type * SCOPE_NUMBER + subscribe_scope
    ///since "remote" members can only send_to/recv_from "local"
    ///members, only the upper-left 4x4 sub-matrix have value
    ///value "1" marks a valid combo of publisher(row) sending to subscriber(col)
    ///value "0" marks invalid
    static short scope_checking_tbl_[][SCOPE_NUMBER * MEMBER_NUMBER];
  };

};

#endif
