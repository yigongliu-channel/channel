////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 *   Msg.h - the generic msg holder used inside channel
 *
 *
 */

#ifndef _MSG_H_
#define _MSG_H_

#include "ace/Thread_Mutex.h"
#include "ace/Thread_Semaphore.h"
#include "ace/Log_Msg.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"
#include "ace/CDR_Stream.h"


#include <BaseDef.h>
#include <IdTrait.h>

namespace channel {

  ///2 reasons we cannot directly use ACE_Message_Block
  ///for all msg passing:
  ///1> channel msg types are not limited to integers.
  ///2> the design of ACE_Message_Block refuses to free
  ///   any foreign msg payload whose memory is not mallocated
  ///   by msg_block. 
  ///   We have to support "Deleting foriegn msgs from inside channel"
  ///   by asking the msg sender/creator to provide msg_free
  ///   callback functions, which sometimes are better solution
  ///   than simple-delete because we can call some foriegn message
  ///   class destructors
  ///we only use ACE_Message_Block for queing msgs in ACE_Message_Que
  ///so here is a simplified design based on ACE_Message_Block.
  ///this Msg class only acting as holder of foriegn data, never
  ///allocate data space.

  typedef void (*MsgFreeCallback) (char * data);

  class MsgDataHolder {
  public:
    char *data_;
    int ref_count_; ///reference count
    ACE_Thread_Mutex ref_count_lock_;
    MsgDataHolder (char *data) : data_(data), ref_count_(1) {}
    void set_data(char *d, MsgFreeCallback gobbler) {
      ACE_GUARD (ACE_Thread_Mutex, guard, ref_count_lock_);
      if (gobbler != NULL)
	gobbler (data_);
      else 
	delete data_; 
      data_ = d;
    }
    void ref_incr(void) {
      ACE_GUARD (ACE_Thread_Mutex, guard, ref_count_lock_);
      ref_count_++;
    }
    void ref_decr(void) {
      ACE_GUARD (ACE_Thread_Mutex, guard, ref_count_lock_);
      ref_count_--;
      if (ref_count_ < 0) ref_count_ = 0;
    }
    void release (MsgFreeCallback gobbler) {
      ACE_GUARD (ACE_Thread_Mutex, guard, ref_count_lock_);
      if (ref_count_ > 1) { ///i am not the only holder
	ref_count_--;
      } else {
	if (gobbler != NULL)
	  gobbler (data_);
	else 
	  delete data_; 
	delete this;
      }
    }
  private:
    ~MsgDataHolder() {};
  };
    
  ///if all msg classes inherit from MsgBase, we can
  ///use def msg free callback to free all foreign msgs
  class MsgBase {
  public:
    ///do i need virtual destructor here?
    virtual ~MsgBase () {}
  };
  void DefaultMsgFreeCallback (char *data) {
    MsgBase *m = (MsgBase *) data;
    delete m;
  }

  ///marshaling strategy objects
  class Marshaler {
  public:
    virtual int marshal(ACE_OutputCDR &cdr, const char *data, const int size) = 0;
    virtual int demarshal(ACE_InputCDR &cdr, char * &data, int &size) = 0;
  };

  class DefaultMarshaler {
  public:
    static int marshal(ACE_OutputCDR &cdr, const char *data, const int size)
      {
      cdr << ACE_CDR::ULong (size);
      cdr.write_char_array (data, size);
      return cdr.good_bit();
      }
    static int demarshal(ACE_InputCDR &cdr, char * &data, int &size)
      {
      ACE_CDR::ULong sz;
      cdr >> sz;
      size = (int)sz;
      data = new char[size];
      cdr.read_char_array(data, size);
      return cdr.good_bit();
      }
  };

  template <class IdType>
  struct  Msg {    
    IdType type;
    int size_;
    MsgDataHolder *data_holder_;
    MessageOwnerType owner_;
    MsgFreeCallback gobbler_;
    
    Msg () {}
    Msg (IdType t, char *d, int s, MessageOwnerType o = RECEIVER,
      MsgFreeCallback g = NULL) : 
      type(t),size_(s),owner_(o),gobbler_(g) {
      data_holder_ = new MsgDataHolder(d);
    }
    Msg *clone (void) {
      Msg *m = new Msg();
      m->type = type;
      m->size_ = size_;
      m->data_holder_ = data_holder_;
      m->owner_ = owner_;
      m->gobbler_ = gobbler_;
      m->data_holder_->ref_incr();
      return m;
    }
    ~Msg () {
      data_holder_->release(gobbler_);
    };

    char * data(void) {
      return data_holder_->data_;
    }
    void data(char *d) {
      data_holder_->set_data(d, gobbler_);
    }

    int marshal(ACE_OutputCDR &cdr, Marshaler *mar) {
      ///marshal IdType
      if (IdTrait<IdType>::marshal(cdr, type) == 0) {
	return 0;
      }
      ///marshal msg data
      if (mar != NULL)
	mar->marshal(cdr, data_holder_->data_, size_);
      else
	DefaultMarshaler::marshal(cdr, data_holder_->data_, size_);
      return cdr.good_bit ();
    }

    int demarshal(ACE_InputCDR &cdr, Marshaler *mar) {
      ///demarshal_IdType is already done at outside
      ///IdTrait<IdType>::demarshal(cdr, type) == 0) {
      ///demarshal data
      char *data;
      if (mar != NULL)
	mar->demarshal(cdr, data, size_);
      else
	DefaultMarshaler::demarshal(cdr, data, size_);
      data_holder_ = new MsgDataHolder(data);
      owner_ = RECEIVER;
      gobbler_ = NULL;
      return cdr.good_bit();
    }
      
  };

  ///--------------------------------------------
  /// Channel Management Msg types
  ///

  struct Channel_Info_Msg {
    enum { MAX_ADDR_NAME_LEN = 128 };
    char host_addr[MAX_ADDR_NAME_LEN];
    u_short port;
    char unix_addr[MAX_ADDR_NAME_LEN];
    int conn_type;
    void *intf;  ///the interface connect to peer
    bool is_local;
    Channel_Info_Msg() {
      port = 0;
      host_addr[0] = '\0';
      unix_addr[0] = '\0';
      conn_type = 0;
      intf = NULL;
      is_local = false;
    }
  };

  template <class IdType>
  struct PubSub_Info_Msg {
    enum { MAX_REGISTRY_ENTRIES = 128 };
    int num_msg_types;
    IdType msg_types[MAX_REGISTRY_ENTRIES];
    PubSub_Info_Msg() {
      num_msg_types = 0;
    }
    ///
    int size(void) {
      int sz = 4; ///for num_msg_types
      for(int i=0;i<num_msg_types;i++) {
	sz += 4;
	sz += IdTrait<IdType>::size(msg_types[i]);
      }
      return sz;
    }
    int marshal(ACE_OutputCDR &cdr)
    {
      cdr << ACE_CDR::Long (num_msg_types);
      for (int i=0;i<num_msg_types;i++) {
	IdType id = msg_types[i];
	IdTrait<IdType>::marshal(cdr, id);
      }
      return cdr.good_bit();
    }
    int demarshal(ACE_InputCDR &cdr)
    {
      ACE_CDR::Long num;
      cdr >> num;
      num_msg_types = (int)num;
      for (int i=0;i<num_msg_types;i++) {
	IdType id;
	IdTrait<IdType>::demarshal(cdr, id);
	msg_types[i] = id;
      }
      return cdr.good_bit();
    }
  };

  template <class IdType>
  class PubSubMsg_Marshaler : public Marshaler {
  public:
    virtual int marshal(ACE_OutputCDR &cdr, const char *data, const int size) 
      {
	ACE_UNUSED_ARG(size);
	PubSub_Info_Msg<IdType> *msg = (PubSub_Info_Msg<IdType> *) data;
	return msg->marshal(cdr);
      }
    virtual int demarshal(ACE_InputCDR &cdr, char * &data, int &size)
      {
	PubSub_Info_Msg<IdType> *msg = new PubSub_Info_Msg<IdType>();
	msg->demarshal(cdr);
	data = (char*)msg;
	size = sizeof(PubSub_Info_Msg<IdType>);
	return cdr.good_bit();
      }
  };

};

#endif
