////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

///-----------------------------------------------------------------
///
/// Connector: 
///     1. setup conn
///     2. maintain conn
///     3. forward msgs between Channel and outside world
///
///-----------------------------------------------------------------

#ifndef _CONNECTOR_H_
#define _CONNECTOR_H_

///ACE headers 
#include "ace/Thread_Mutex.h"
#include "ace/Thread_Semaphore.h"
#include "ace/Synch.h"
#include "ace/OS.h"
#include "ace/os_include/os_netdb.h"
#include "ace/Log_Msg.h"
#include "ace/Synch_Options.h"

///std
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <algorithm>
#include <netinet/in.h>

///channel
#include <BaseDef.h>



namespace channel {

  template <class, class> class ConnHandler;
  template <class, class> class OutputMgr;
  class ConnInfo;
  template <class, class> class MarshalerRegistry;
  template <class, class> class BinderRegistry;
  template <class, class> class Binder;

  /**
   *  Connector correlates Channel, Transport, OutputMgr(threads)
   *  ConnHandler(threads) and RemoteInterface
   */
  template <class Channel, class Transport>
  class Connector : public Transport, 
    public MarshalerRegistry<typename Channel::IdType, typename Channel::IdTrait>,
    public BinderRegistry<typename Channel::IdType, typename Channel::IdTrait> {
    template <class, class> friend class ConnHandler;
    template <class, class> friend class RemoteInterface;

  public:

    typedef ConnHandler<Channel, Transport> ConnHandler;
    typedef Interface<Channel> Interface;
    typedef RemoteInterface<Channel, ConnHandler> RemoteInterface;
    typedef Binder<typename Channel::IdType, typename Channel::IdTrait> Binder;

    bool exit_start_; ///conn threads start exiting
    ACE_Thread_Semaphore exit_sema_; ///for thread group exit gracely

  protected:

    /// output thread-pool 
    OutputMgr<Channel, ConnHandler> output_mgr_;
    int num_thr_;
    ///current active connections
    ///indexed by remote listening addresses, which is fixed for rmt systems
    std::map<ConnInfo, ConnHandler *> conn_map_; 
    ACE_Thread_Mutex conn_map_lock_;

  public:

    Channel *ch_;

    Connector(Channel *mchan, int nt=1) : Transport(this) {
      conn_map_.clear();
      exit_start_ = false;
      ch_ = mchan;
      num_thr_ = nt;
    }
    ~Connector() {}

    static Interface_Type type(void) { 
      return Transport::type(); }

    Status open(std::string addr)
      {
	output_mgr_.num_thr(num_thr_);
	output_mgr_.open();

	ConnInfo ci(addr);
	Transport::open(ci);

	return SUCCESS;
      }
    Status close(void)
      {
	ACE_DEBUG ((LM_DEBUG, "(%t) Connector::close() before lock conn_map_lock...\n"));
	ACE_GUARD_RETURN (ACE_Thread_Mutex, guard, conn_map_lock_, FAILURE);
	ACE_DEBUG ((LM_DEBUG, "(%t) Connector::close() after lock conn_map_lock...\n"));
	ACE_DEBUG ((LM_DEBUG, "(%t) Connector first shutdown all writer threads...\n"));
	output_mgr_.shut_down(); ///gracely shutdown
	ACE_DEBUG ((LM_DEBUG, "(%t) Connector shutdown all reader threads...\n"));
	exit_start_=true;
	typename std::map<ConnInfo, ConnHandler *>::iterator iter;
	for(iter=conn_map_.begin(); iter!=conn_map_.end(); iter++)
	  iter->second->shut_down();
	///wait for read thread to exit
	for(iter=conn_map_.begin(); iter!=conn_map_.end(); iter++)
	  exit_sema_.acquire();

	Transport::close();

	return SUCCESS;
      }

    Status connect(std::string addr_str, Binder *b = NULL)
      {
	ConnInfo addr(addr_str);
	return connect(addr, b);
      }

    Status connect(ConnInfo addr, Binder *bind = NULL)
      {
	ConnInfo adr2(addr);
	Transport::get_map_index(adr2);
	if(is_connected(adr2))
	  return SUCCESS;
	ConnHandler *ch = NULL;
	if(Transport::connect (addr, ch) != SUCCESS)
	  return FAILURE;
	ch->rmt_addr_ = adr2;
	//register binders(filters+translators) here
	if (bind != NULL)
	  register_binder(adr2, bind);
	return SUCCESS;
      }
    Status disconnect(std::string addr) { 
      ACE_UNUSED_ARG(addr);
      return SUCCESS; }

    ///manage conn_map
    Status add_conn(ConnInfo peer_addr, ConnHandler *ch)
      {
	ACE_GUARD_RETURN (ACE_Thread_Mutex, guard, conn_map_lock_, FAILURE);
	if(conn_map_.find(peer_addr) != conn_map_.end()) {
	  ACE_DEBUG ((LM_DEBUG, "duplicate connection...\n"));
	  return FAILURE; ///duplicated conn, should be dropped
	}
	conn_map_[peer_addr] = ch;

	///conn_map_[peer_addr]->dump();
	return SUCCESS;
      }
    Status del_conn(ConnHandler *ch)
      {
	ACE_GUARD_RETURN (ACE_Thread_Mutex, guard, conn_map_lock_, FAILURE);
	typename std::map<ConnInfo, ConnHandler*>::iterator iter;
	for(iter = conn_map_.begin(); iter != conn_map_.end(); iter++) 
	  if(iter->second == ch) {
	    conn_map_.erase(iter->first);
	    break;
	  }
	return SUCCESS;
      }
    Status del_conn(ConnInfo addr)
      {
	ACE_GUARD_RETURN (ACE_Thread_Mutex, guard, conn_map_lock_, FAILURE);
	conn_map_.erase(addr);
	return SUCCESS;
      }
    bool is_connected(ConnInfo addr)
      {
	ACE_GUARD_RETURN (ACE_Thread_Mutex, guard, conn_map_lock_, FAILURE);
	if(conn_map_.find(addr) != conn_map_.end())
	  return true;
	return false;
      }

  };


};

#endif
