////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

//------------------------------------------------------------
//
// Clock.h: a process-wide MT-safe timer 
//
//------------------------------------------------------------

#ifndef _CLOCK_H_
#define _CLOCK_H_

#include "ace/Singleton.h"
#include "ace/Time_Value.h"
#include "ace/OS_NS_sys_time.h"
#include "ace/Timer_Queue_Adapters.h"
#include "ace/Timer_Heap.h"
#include "ace/Recursive_Thread_Mutex.h"
#include "ace/Thread_Semaphore.h"



namespace channel {

  class ActiveTimer : public ACE_Thread_Timer_Queue_Adapter<ACE_Timer_Heap>
    {
    public:
      ACE_Thread_Semaphore exit_sema_;
      ActiveTimer() : exit_sema_(0) {}
      virtual int close(u_long flag=0) {
	ACE_UNUSED_ARG (flag);
	ACE_DEBUG((LM_DEBUG, "(%t) timer thread exit...\n"));
	exit_sema_.release();
	return 0;
      }
      void wait_timer_thr_exit(void) {
	ACE_DEBUG((LM_DEBUG, "(%t) wait for timer thread exit...\n"));
	exit_sema_.acquire();
      }
    };

  class  ActiveTimerPointer {
    friend class ACE_Singleton<ActiveTimerPointer, ACE_Recursive_Thread_Mutex>;
  public:
    //i cannot use smart pointer here
    //ActiveTimer* operator->() { return actimer; }
    long schedule (ACE_Event_Handler *handler,
		   const void *act,
		   const ACE_Time_Value &future_time,
		   const ACE_Time_Value &interval = ACE_Time_Value::zero)
      {
	return actimer->schedule(handler,act,future_time,interval);
      }
    int cancel (long timer_id, const void **act = 0)
      {
	return actimer->cancel(timer_id, act);
      }
    void stop(void)
      {
	if(actimer != NULL) {
	  actimer->timer_queue()->expire();
	  actimer->deactivate(); 
	  actimer->wait_timer_thr_exit();
	  ACE_OS::sleep(1); //to allow timer thread to exit
	  delete actimer; 
	  actimer = NULL;
	}
      }
  private:
    ActiveTimerPointer() { actimer = new ActiveTimer(); actimer->activate(); }
    ~ActiveTimerPointer() 
      { 
	if(actimer != NULL) {
	  actimer->timer_queue()->expire();
	  actimer->deactivate(); 
	  actimer->wait_timer_thr_exit();
	  ACE_OS::sleep(1); //to allow timer thread to exit
	  delete actimer; 
	  actimer = NULL;
	}
      }
    ActiveTimer *actimer;
  };

  typedef ACE_Singleton<ActiveTimerPointer, ACE_Recursive_Thread_Mutex>
    Clock;

};


#endif
 
