////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _BINDER_H_
#define _BINDER_H_

//ACE headers
#include "ace/Thread_Mutex.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

#include <map>

#include <BaseDef.h>

namespace channel {

  class ConnInfo;

  /**
   * Filters: 
   * 1. provision the permissions which messages/ids can flow in/out 
   *    channel thru interfaces
   * 2. ONLY works on sub/pub msgs, not other(application) msgs
   *    affect how sub/pub msgs are exchanged between local channel and
   *    remote channel - how remote and local namespaces "merge"
   *    not affect the normal message passing process
   * 3. Default Filters are "transparent" - all Ids allowed in/out:
   *    
   */
  template <class IdType, class IdTrait>
    class Filter {
    public:
    virtual bool block_inward (IdType id) {
      ACE_UNUSED_ARG(id);
      return false;
    }
    virtual bool block_outward (IdType id) {
      ACE_UNUSED_ARG(id);
      return false;
    }
  };

  /**
   * Translator:
   * 1. translate inward/outward msg ids, help integration of namespaces
   * 2. ONLY works on application msgs
   *    affect (potentially change) each msgs passed in/out interfaces - 
   *    must be highly efficient
   * 3. Default Translator is non-op
   */
  template <class IdType, class IdTrait>
    class Translator {
    public:
    virtual Status translate_inward (IdType &id) { 
      ACE_UNUSED_ARG(id);
      return SUCCESS;
    }
    virtual Status translate_outward (IdType &id) { 
      ACE_UNUSED_ARG(id);
      return SUCCESS;
    }
  };

  /**
   * Binder:
   * 1. affect ONLY the interface - the "binding" point between local
   *    channel and remote connections
   * 2. contains both filter and transltor
   * 3. if filters/translators are NULL, they are no-op
   */
  template <class IdType, class IdTrait>
    class Binder {
    public:
    typedef Filter<IdType, IdTrait> Filter;
    typedef Translator<IdType, IdTrait> Translator;
    Filter *filter;
    Translator *translator;
    Binder (Filter *f = NULL, Translator *t = NULL) {
      filter = f;
      translator = t;
    }
  };

  /**
   * BinderRegistry:
   * 1. provision what filter/translator for each external connections;
   *    similar to NFS config files decide which remote machines can access which files
   * 2. not inherent to Channel, owned by connectors
   */
  template <class IdType, class IdTrait>
  class BinderRegistry {
  private:
    //marshaler registration
    typedef Binder<IdType, IdTrait> Binder;
    std::map<ConnInfo, Binder*> binder_tbl_;
    ACE_Thread_Mutex binder_tbl_lock_;
  public:
    BinderRegistry () {
    }

    Status register_binder(ConnInfo ci, Binder *b)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, binder_tbl_lock_, FAILURE);
	binder_tbl_[ci] = b;
	return SUCCESS;
      }

    Binder * get_binder(ConnInfo ci)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, binder_tbl_lock_, NULL);
	if (binder_tbl_.find(ci) != binder_tbl_.end())
	  return binder_tbl_[ci];
	else
	  return NULL;
      }
  };

};

#endif
