////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _CONN_INFO_
#define _CONN_INFO_

#include <string>
#include <BaseDef.h>


namespace channel {

  //helper class to encode/decode (ip:port or unix_addr)
  class  ConnInfo {
  public:
    Interface_Type type_;
    std::string ip_;  //ip addr or hostname
    u_short port_;
    std::string unix_addr_;
    bool valid_;

    ConnInfo() {}

    ConnInfo(const ConnInfo &ci) {
      type_ = ci.type_;
      ip_ = ci.ip_;
      port_ = ci.port_;
      unix_addr_ = ci.unix_addr_;
      valid_ = ci.valid_;
    }

    void parse(std::string conn_info);

    ConnInfo(std::string ip, int port) {
      ip_ = ip;
      port_ = port;
      type_ = INET_SOCK;
      valid_ = true;
    }

    void set(std::string ip, int port) {
      ip_= ip;
      port_= port;
      type_ = INET_SOCK;
      valid_ = true;
    }
   
    ConnInfo(std::string addr) {
      parse(addr);
    }

    void set(std::string addr) {
      parse(addr);
    }

    Interface_Type type(void) { return type_;}

    bool valid(void) { return valid_; }

    std::string ip(void) { return ip_;}
    void ip(std::string ip) { ip_ = ip; }
    u_short port(void) {return port_;}
    void port(u_short p) {
      port_= p;
    }

    std::string get_host_addr(void) { return ip_;}
    void set_host_addr(std::string hn) { ip_ = hn;}
    u_short get_port_number(void) { return port_;}
    void set_port_number(u_short p) { port(p);}

    std::string unix_addr(void) { return unix_addr_;}

    bool operator< (const ConnInfo &ci) const;
    bool operator== (const ConnInfo &ci) const;
    void dump(void);
  
  };

};

#endif

