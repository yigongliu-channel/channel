////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _MEMBER_H_
#define _MEMBER_H_

#include "ace/Thread_Mutex.h"
#include "ace/Thread_Semaphore.h"
#include "ace/Log_Msg.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

//std headers
#include <map>

//export 
#include <BaseDef.h>

namespace channel {

  //a member of channels, either Source or Destination
  template <class Channel>
    class  Member {
    public:
    //cannot use the following constructor because it requires the
    //most derived class to construct virtual base class explicitly
    //Member(Channel *c) : ch_(c) {}
    Member() : ch_(NULL) {}
    virtual ~Member() {};
    virtual Member_Type type() { return MEMBER_LOCAL; } //default local members
    protected:
    Channel *ch_;
  };    

  //channel src_points, where msgs are created and sent
  template <class Channel>
    class Source : virtual public Member<Channel> {
    public:
    typedef typename Channel::IdType IdType;
    typedef typename Channel::Msg Msg;

    Source (Channel *c) { Member<Channel>::ch_ = c; }
    virtual ~Source() {};
    //publish msgs
    virtual Status publish_msg(IdType t, PubSub_Scope s=SCOPE_GLOBAL)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, scope_lock_, FAILURE);
	msg_scope_[t] = s;
	//Q: why i have to use this->ch_ in template classes?
	return this->ch_->publish_msg(t,this);
      }
    virtual Status unpublish_msg(IdType t)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, scope_lock_, FAILURE);
	msg_scope_.erase(t);
	return this->ch_->unpublish_msg(t,this);
      }
    virtual Status unpublish_all(void)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, scope_lock_, FAILURE);
	for(typename std::map<IdType, PubSub_Scope>::iterator iter =  msg_scope_.begin();
	    iter !=  msg_scope_.end(); iter++) {
	  this->ch_->unpublish_msg(iter->first, this);
	}
	msg_scope_.clear();
	return SUCCESS;
      }
    //send msgs
    virtual Status send_msg(IdType t, char *msg, int sz, 
			    MessageOwnerType owner = RECEIVER, 
			    MsgFreeCallback g = NULL,
			    ACE_Time_Value *timeout=0) {
      Msg *m = new Msg(t, msg, sz, owner, g);
      return send_msg (m, timeout);
    }
    virtual Status send_msg(Msg *msg, ACE_Time_Value *timeout=0)
      {
	if (msg_scope_.find(msg->type) != msg_scope_.end()) {
	  ACE_DEBUG((LM_DEBUG, "src sends msg [%s]\n", ID2STR(msg->type).c_str()));
	  return this->ch_->route_msg(msg, this->type(), msg_scope_[msg->type], timeout);
	} else {
	  ACE_DEBUG((LM_DEBUG, "src failed to sends unpublished msg [%s], dropped\n", ID2STR(msg->type).c_str()));
	  if (msg->owner_ == RECEIVER)
	    delete msg;
	}
	return FAILURE;
      }
    PubSub_Scope scope(IdType t)
      {
	if(msg_scope_.find(t) != msg_scope_.end())
	  return msg_scope_[t];
	else
	  return SCOPE_UNDEFINED;
      }
    protected:
    //published msgs scopes
    std::map<IdType, PubSub_Scope> msg_scope_;
    ACE_Thread_Mutex scope_lock_;
  };

  //channel endpoints, where msgs are destinated and consumed
  template <class Channel>
    class Destination : virtual public Member<Channel> {
    public:
    typedef typename Channel::IdType IdType;
    typedef typename Channel::Msg Msg;
    Destination (Channel *c) { Member<Channel>::ch_ = c; }
    virtual ~Destination() {}
    //subscribe to chan msgs
    virtual Status subscribe_msg(IdType t, PubSub_Scope s=SCOPE_GLOBAL)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, scope_lock_, FAILURE);
	msg_scope_[t] = s;
	return this->ch_->subscribe_msg(t, this);
      }
    virtual Status unsubscribe_msg(IdType t)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, scope_lock_, FAILURE);
	msg_scope_.erase(t);
	return this->ch_->unsubscribe_msg(t, this);
      }
    virtual Status unsubscribe_all(void)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, scope_lock_, FAILURE);
	for(typename std::map<IdType, PubSub_Scope>::iterator iter =  msg_scope_.begin();
	    iter !=  msg_scope_.end(); iter++) {
	  this->ch_->unsubscribe_msg(iter->first, this);
	}
	msg_scope_.clear();
	return SUCCESS;
      }
    //recv msgs from chan
    virtual Status put_msg(Msg *msg, ACE_Time_Value *timeout=0) = 0;
    //utils
    bool operator==(Destination *s) { 
      return equals(s);
    }
    bool equals(Destination *s) { 
      //Q: why we need this->type(), not type()?
      if (this->type() != s->type()) return false;
      if (((Destination *)this) != s) return false;
      return true;
    }
    PubSub_Scope scope(IdType t)
      {
	if(msg_scope_.find(t) != msg_scope_.end())
	  return msg_scope_[t];
	else
	  return SCOPE_UNDEFINED;
      }
    protected:
    //subscribed msgs scopes
    std::map<IdType, PubSub_Scope> msg_scope_;
    ACE_Thread_Mutex scope_lock_;
  }; 

  //parent class of synchronous callbacks
  //synchronous callbacks dont have their own threads
  //the thread which dispatch channel msgs (either thread inside
  //connector or the thread which publish msgs to channels) 
  //will drive callback process().
  template <class Channel>
    class  Callback : public Destination<Channel> {
    public:
    typedef typename Channel::Msg Msg;

    Callback (Channel *c) : Destination<Channel>(c) {}
    Status put_msg(Msg *msg, ACE_Time_Value *timeout) {
      ACE_UNUSED_ARG(timeout);
      //callback, msg should be deleted inside process
      return process (msg);
    }
    //here the real callback processing
    virtual Status process(Msg *msg) = 0;
  };

};

#endif

