////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAP_ROUTER_H_
#define _MAP_ROUTER_H_

//ACE headers
#include "ace/Thread_Mutex.h"
#include "ace/Thread_Semaphore.h"
#include "ace/Log_Msg.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

//std
#include <map>
#include <list>
#include <vector>
#include <string>
#include <algorithm>

//Channel
#include <BaseDef.h>
#include <RouterBase.h>
#include <Msg.h>

namespace channel {

  template <class, class, class> class Channel;
  template <class> class Destination;
  template <class> class Source;
  class Marshaler;

  /**
   *     MapRouter:
   *     using stl map as routing table
   *     using id matching
   */  
  template <class IdType, class IdTrait>
  class MapRouter : public RouterBase {

    typedef Channel<IdType, IdTrait, MapRouter<IdType, IdTrait> > Channel;
    typedef Destination<Channel> Destination;
    typedef Source<Channel> Source;
    //Q: why i cannot use Channel::Msg here?
    typedef Msg<IdType> Msg;
    typedef PubSub_Info_Msg<IdType> PubSub_Info_Msg;
  private:

    //subscription(routing) table
    std::map<IdType, std::list<Destination *>* > msg_sub_tbl_;
    ACE_Thread_Mutex msg_sub_tbl_lock_;
    //publication(global) table
    std::map<IdType, std::list<Source *>* > msg_pub_tbl_;
    ACE_Thread_Mutex msg_pub_tbl_lock_;

  public:

    MapRouter() {
    }

    /**
     * 1. Local operations on Channel/Router namespace:
     *    pub/unpub, sub/unsub
     */
    /// publish 
    Status publish_msg(IdType t, Source *src)
      {
	PubSub_Scope s = src->scope(t);
	bool send2remote = false;
	if (s == SCOPE_REMOTE || s == SCOPE_GLOBAL) {
	  ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_pub_tbl_lock_, FAILURE);
	  std::list<Source *> *srcs = NULL;
	  if(msg_pub_tbl_.find(t) != msg_pub_tbl_.end())
	    srcs = msg_pub_tbl_[t];
	  if(srcs == NULL) {
	    srcs = new std::list<Source *>();
	    msg_pub_tbl_[t] = srcs;
	    send2remote = true;
	  }
	  if(std::find(srcs->begin(),srcs->end(),src)==srcs->end()) {
	    srcs->push_back(src);
	  }
	}
	if (send2remote)
	  propagate_change_to_neighbors(OPER_PUBLISH, t);
	return SUCCESS;
      }
    ///unpublish
    Status unpublish_msg(IdType t, Source *src)
      {
	bool send2remote = false;
	{
	  ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_pub_tbl_lock_, FAILURE);
	  std::list<Source *> *srcs = NULL;
	  if(msg_pub_tbl_.find(t) != msg_pub_tbl_.end())
	    srcs = msg_pub_tbl_[t];
	  if(srcs == NULL) return SUCCESS;
	  bool found = false;
	  typename std::list<Source *>::iterator iter;
	  for(iter=srcs->begin(); iter!=srcs->end(); iter++) {
	    Source *ss = (*iter);
	    if(ss == src) {
	      //remove registration
	      srcs->erase(iter);
	      found = true;
	      iter--;
	    }
	  }
	  if(srcs->empty()) {
	    msg_pub_tbl_[t]=NULL; //have to do it, since map doesn't work correctly
	    msg_pub_tbl_.erase(t);
	    send2remote = true;
	  }
	}
	if (send2remote)
	  propagate_change_to_neighbors(OPER_UNPUBLISH, t);
	return SUCCESS;
      }
    ///subscribe
    Status subscribe_msg(IdType t, Destination *s) 
      {
	ACE_DEBUG((LM_DEBUG, "MapRouter::subscribe_msg: [%s]\n",ID2STR(t).c_str()));
	bool send2remote = false;
	{
	  ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_sub_tbl_lock_, FAILURE);
	  std::list<Destination *> *dests = NULL;
	  if(msg_sub_tbl_.find(t) != msg_sub_tbl_.end())
	    dests = msg_sub_tbl_[t];
	  if(dests == NULL) {
	    dests = new std::list<Destination *>();
	    msg_sub_tbl_[t] = dests;
	  }
	  if(std::find(dests->begin(),dests->end(),s)==dests->end()) {
	    if((s->type()==MEMBER_LOCAL) && s->scope(t) != SCOPE_LOCAL) {
	      bool found = false;
	      for (typename std::list<Destination *>::iterator iter = dests->begin(); 
		   iter!=dests->end() && !found; iter++) {
		if ((*iter)->type()==MEMBER_LOCAL && (*iter)->scope(t) != SCOPE_LOCAL)
		  found = true;
	      }
	      if (!found)
		send2remote = true;
	    }
	    dests->push_back(s);
	  }
	}
	if (send2remote)
	  propagate_change_to_neighbors(OPER_SUBSCRIBE, t);
	return SUCCESS;
      }
    ///unsubscribe
    Status unsubscribe_msg(IdType t, Destination *s)
      {
	ACE_DEBUG((LM_DEBUG, "MapRouter::unsubscribe_msg[%s]...\n", ID2STR(t).c_str()));
	bool send2remote = false;
	{
	  ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_sub_tbl_lock_, FAILURE);
	  std::list<Destination *> *dests = NULL;
	  if(msg_sub_tbl_.find(t) != msg_sub_tbl_.end())
	    dests = msg_sub_tbl_[t];
	  if(dests == NULL || dests->empty()) return SUCCESS;
	  bool found = false;
	  typename std::list<Destination *>::iterator iter;
	  for(iter=dests->begin(); iter!=dests->end(); iter++) {
	    if((*iter)->equals(s)) {
	      //remove registration
	      dests->erase(iter);
	      found = true;
	      iter--;
	    }
	  }

	  if(dests->empty()) {
	    msg_sub_tbl_[t]=NULL; //have to do it, since map doesn't work correctly
	    msg_sub_tbl_.erase(t);
	  }
	  if((s->type()==MEMBER_LOCAL) && s->scope(t) != SCOPE_LOCAL) {
	    if (msg_sub_tbl_[t]==NULL) {
	      ACE_DEBUG((LM_DEBUG, "notify Peers to unsubscribe msgs...\n"));
	      send2remote = true;
	    } else {
	      bool found = false;
	      for (typename std::list<Destination *>::iterator iter = dests->begin(); 
		   iter!=dests->end() && !found; iter++) {
		if ((*iter)->type()==MEMBER_LOCAL && (*iter)->scope(t) != SCOPE_LOCAL)
		  found = true;
	      }
	      if (!found) {
		ACE_DEBUG((LM_DEBUG, "notify Peers to unsubscribe msgs...\n"));
		send2remote = true;
	      }
	    }
	  }
	}
	if (send2remote)
	  propagate_change_to_neighbors(OPER_UNSUBSCRIBE, t);
	return SUCCESS;
      }
    
    /**
     * 2.
     * route msgs (from src to dest) based on :
     * src_type(local/remote) & publish_scope AND
     * dest_type(local/remote) & subscribe_scope
     */
    Status route_msg(Msg *msg, Member_Type src_type, PubSub_Scope scope, ACE_Time_Value *timeout=0)
      {
	ACE_DEBUG ((LM_DEBUG, "MapRouter::route_msg: src_type[%d],scope[%d],msg[%s]\n", src_type, scope, ID2STR(msg->type).c_str()));
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_sub_tbl_lock_, FAILURE);
	std::list<Destination *> *dests = msg_sub_tbl_[msg->type];
	if(dests==NULL || dests->size()==0) {
	  ACE_DEBUG ((LM_DEBUG, "msg [%s] dropped, no subscriber\n", ID2STR(msg->type).c_str()));
	  delete msg;
	  return FAILURE;
	}

	if(dests->size()==1) {
	  typename std::list<Destination *>::iterator iter=dests->begin();
	  short src_row = src_type * SCOPE_NUMBER + scope;
	  short dst_col = (*iter)->type() * SCOPE_NUMBER + (*iter)->scope(msg->type);
	  if(scope_checking_tbl_[src_row][dst_col]) {
	    ACE_DEBUG ((LM_DEBUG, "msg [%s] delivered\n", ID2STR(msg->type).c_str()));
	    (*iter)->put_msg(msg, timeout);
	  } else {
	    ACE_DEBUG ((LM_DEBUG, "msg [%s] dropped, scope dont match\n", ID2STR(msg->type).c_str()));
	    delete msg;
	  }
	} else {
	  Msg *dup=NULL;
	  for(typename std::list<Destination *>::iterator iter=dests->begin(); iter!=dests->end(); iter++) {
	    ///calc position in rule_tbl_
	    short src_row = src_type * SCOPE_NUMBER + scope;
	    short dst_col = (*iter)->type() * SCOPE_NUMBER + (*iter)->scope(msg->type);
	    if(scope_checking_tbl_[src_row][dst_col]) {
	      ///ACE_DEBUG ((LM_DEBUG, "before clone\n"));
	      dup=msg->clone();
	      ///ACE_DEBUG ((LM_DEBUG, "after clone\n"));
	      ACE_DEBUG ((LM_DEBUG, "msg [%s] delivered once\n", ID2STR(msg->type).c_str()));
	      (*iter)->put_msg(dup, timeout);
	    }
	  }
	  delete msg;
	}
 
	return SUCCESS;
      }

    /**
     * 3. query namespace content
     */
    ///exported namespace
    Status subscribed_global_msgs(std::vector<IdType> &global_msgs)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_sub_tbl_lock_, FAILURE);
	for(typename std::map<IdType, std::list<Destination *>* >::iterator iter = msg_sub_tbl_.begin();
	    iter != msg_sub_tbl_.end(); iter++) {
	  IdType t = iter->first;
	  bool candidate=false;
	  std::list<Destination *> *dests = iter->second;
	  if(dests==NULL) continue;
	  for(typename std::list<Destination *>::iterator iter2 = dests->begin();
	      iter2 != dests->end(); iter2++)
	    if(((*iter2)->type()==MEMBER_LOCAL) &&
	       ((*iter2)->scope(t)==SCOPE_REMOTE || (*iter2)->scope(t)==SCOPE_GLOBAL )) {
	      candidate=true;
	      break;
	    }
	  if(candidate)
	    global_msgs.push_back(iter->first);
	}

	return SUCCESS;
      }
    Status published_global_msgs(std::vector<IdType> &global_msgs)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_pub_tbl_lock_, FAILURE);
	for(typename std::map<IdType, std::list<Source *>* >::iterator iter = msg_pub_tbl_.begin();
	    iter != msg_pub_tbl_.end(); iter++) {
	  global_msgs.push_back(iter->first);
	}

	return SUCCESS;
      }

    ///internal namespace query
    Status subscribed_msgs(std::vector<IdType> &msg_types)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, msg_sub_tbl_lock_, FAILURE);
	for(typename std::map<IdType, std::list<Destination *>* >::iterator iter = msg_sub_tbl_.begin();
	    iter != msg_sub_tbl_.end(); iter++) {
	  bool candidate=false;
	  std::list<Destination *> *dests = iter->second;
	  if(dests==NULL) continue;
	  for(typename std::list<Destination *>::iterator iter2 = dests->begin();
	      iter2 != dests->end(); iter2++)
	    if((*iter2)->type()==MEMBER_LOCAL) {
	      candidate=true;
	      break;
	    }
	  if(candidate)
	    msg_types.push_back(iter->first);
	}

	return SUCCESS;
      }
    void dump_routing_tables(void)
      {
	ACE_DEBUG((LM_DEBUG, "The following %d IdTypes subscribed: \n", msg_sub_tbl_.size()));
	msg_sub_tbl_lock_.acquire();
	typename std::map<IdType, std::list<Destination *>* >::iterator iter;
	for(iter = msg_sub_tbl_.begin(); iter!=msg_sub_tbl_.end(); iter++) {
	  if(iter->second!=NULL)
	    ACE_DEBUG((LM_DEBUG, "%s ", ID2STR(iter->first).c_str()));
	}
	ACE_DEBUG((LM_DEBUG, "\n"));
	msg_sub_tbl_lock_.release();
      }

  protected:
    /**
     * 4. propagate namespace changes to connected channels
     */
    Status propagate_change_to_neighbors(Oper_Type op, IdType t)
      {
	ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors [%s]\n",ID2STR(t).c_str()));
	PubSub_Info_Msg *sub = new PubSub_Info_Msg();
	sub->num_msg_types = 1;
	sub->msg_types[0] = t;
	IdType mt;
	switch(op) {
	case OPER_PUBLISH:
	  mt = Channel::PUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors publish "));
	  break;
	case OPER_UNPUBLISH:
	  mt = Channel::UNPUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors unpublish "));
	  break;
	case OPER_SUBSCRIBE:
	  mt = Channel::SUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors subscribe "));
	  break;
	case OPER_UNSUBSCRIBE:
	  mt = Channel::UNSUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors unsubscribe "));
	  break;
	}
	Msg *m = new Msg(mt, (char*)sub, sizeof(PubSub_Info_Msg));
	route_msg(m, MEMBER_LOCAL, SCOPE_REMOTE);
	return SUCCESS;
      }
  };

};


#endif
