////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _CVM_BASE_H_
#define _CVM_BASE_H_

#include <CvmBaseChannel.h>
#include <CvmBaseConnector.h>
#include <CvmBaseTask.h>
#include <CvmBase_export.h>

namespace cvm {

  template <class Chan> //dont use "Channel" to avoid conflict with below
    class CvmBase_Export CvmBase {
    public:
    typedef CvmBaseChannel<Chan> Channel;
#if !defined (ACE_WIN32)
    typedef CvmBaseConnector<Chan, channel::UnixSockTransport<Chan> > UnixConnector;
#endif
	typedef CvmBaseConnector<Chan, channel::TcpSockTransport<Chan> > TcpConnector;
    typedef CvmBaseTask<Chan> Task;
  };

};


#endif
