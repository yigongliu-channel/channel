////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <PingTask.h>
#include <PingTask_export.h>
#include <iostream>
#include <Task_Msg.h>

using namespace std;
using namespace channel;

//----------------------------------------------
// the following 3 methods should be overwritten
// to implement application logic
//----------------------------------------------

//app hooks for resource reservation & cleanup
Status Ping_Task::prepare(void)
{  
  my_port_->publish_msg(PONG_MSG, SCOPE_GLOBAL);
  my_port_->subscribe_msg(PING_MSG);
  return SUCCESS;
}
 
Status Ping_Task::cleanup(void)
{
  my_port()->unpublish_msg(PONG_MSG);
  my_port()->unsubscribe_msg(PING_MSG);
  return SUCCESS;
}


int Ping_Task::work() {
  ACE_DEBUG ((LM_DEBUG,
	      "(%t) %s ping_task coming up ...\n", my_name().c_str()));
  Msg *msg;
  Ping_Pong_Msg *sm, *rsp;

  for(;;) {
    if(my_port()->recv_msg(msg) == SUCCESS) {
      //handle_msg(msg);
      if(msg->type == PING_MSG) {
	sm = (Ping_Pong_Msg *)msg->data();
	sm->data[sm->len-1] = '\0';

	ACE_DEBUG ((LM_DEBUG, "(%t) (%s) receive the Ping_Pong_Msg[%d]: \n%s\n",
		    my_name().c_str(),sm->count,sm->data));

	rsp = new Ping_Pong_Msg();
	rsp->len = sm->len;
	rsp->count = sm->count+1;
	if(rsp->count > 4096) rsp->count=0;
	rsp->data[0] = '\0';
	strcpy(rsp->data,sm->data);

	Msg *m = new Msg(PONG_MSG, rsp);
	my_port()->send_msg(m);

	delete msg; 
	}
   } else {
      //handle_error();
      cerr << "recv_msg() failed once...\n";
      break;
    }
  }

  ACE_DEBUG ((LM_DEBUG,
	      "(%t) %s ping_task exits...\n", my_name().c_str()));

  return 0;
}

ACE_FACTORY_DEFINE (PingTask, Ping_Task)
