////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#include <Cvm.h>

class Quit_Handler : public ACE_Event_Handler {
  friend class ace_dewarn_gplusplus;
 public:
  Quit_Handler (ACE_Reactor *r) : ACE_Event_Handler (r) {}

  virtual int handle_exception (ACE_HANDLE) {
    ACE_DEBUG((LM_DEBUG, "Channel Reactor shutting down now...\n"));
    reactor ()->end_reactor_event_loop ();
    //ACE_OS::sleep(1);  //sleep 2 seconds to allow reader threads to exit
    return -1; // Trigger call to handle_close() method.
  }

  virtual int handle_close (ACE_HANDLE, ACE_Reactor_Mask)
    { delete this; return 0; }

 private:

  // Private destructor ensures dynamic allocation.
  virtual ~Quit_Handler () {}
};

class Ctrl_Task : public cvm::CvmTask {
 public:
  //Each app should implement the following 3 methods
  //to get app control flow going
  Status prepare(void); //initialization before thread starts
  Status cleanup(void); //cleanup before threads exit
  int work (void);       //main processing loop
  int handle_signal (int signum, siginfo_t * = 0, ucontext_t * = 0);
  //test menu
  void showTestMenu();

  //need to overwrite fini() since we are not recving msgs
  int fini ();
};


