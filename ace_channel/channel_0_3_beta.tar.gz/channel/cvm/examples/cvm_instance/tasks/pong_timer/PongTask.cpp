////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <PongTask.h>
#include <PongTask_export.h>
#include <Clock.h>
#include <iostream>

using namespace std;


class TimeOutCB : public ACE_Event_Handler
{
public:
  TimeOutCB(Pong_Task *pt) : pong_task_(pt) {}
  virtual int handle_timeout (const ACE_Time_Value &,
                              const void *arg);
private:
  Pong_Task *pong_task_;
};

int TimeOutCB::handle_timeout (const ACE_Time_Value &, const void *arg)
{
  ACE_UNUSED_ARG(arg);
  pong_task_->send_ping_pong();
  return 0;
}

//----------------------------------------------
// the following 3 methods should be overwritten
// to implement application logic
//----------------------------------------------

//app hooks for resource reservation & cleanup
Status Pong_Task::prepare(void)
{  
  my_port()->publish_msg(PING_MSG, SCOPE_GLOBAL);
  //subscribe msg
  my_port()->subscribe_msg(PONG_MSG);

  const ACE_Time_Value curr_tv = ACE_OS::gettimeofday ();
  TimeOutCB *cb_ = new TimeOutCB(this);
  ACE_Time_Value interval = ACE_Time_Value (1, 0);
  Clock::instance()->schedule (cb_, NULL, curr_tv + interval, interval);

  return SUCCESS;
}

Status Pong_Task::cleanup(void)
{
  ACE_DEBUG ((LM_DEBUG,
	      "(%t) Pong_Task::cleanup(void)...\n"));
  my_port()->unpublish_msg(PING_MSG);
  //unsubscribe msg 
  my_port()->unsubscribe_msg(PONG_MSG);
  return SUCCESS;
}

void Pong_Task::send_ping_pong(void) {
  Ping_Pong_Msg *rsp;
  rsp = new Ping_Pong_Msg();
  rsp->count = 0;
  strcpy(rsp->data,"Lets ping pong...");
  rsp->len = strlen("Lets ping pong...");
  Msg *m = new Msg(PING_MSG, rsp);
  my_port()->send_msg(m);
  cerr << "send one msg...\n";
}


int Pong_Task::work() {
  ACE_DEBUG ((LM_DEBUG,
	      "(%t) %s pong_task coming up ...\n", my_name().c_str()));

  Msg *msg;
  Ping_Pong_Msg *sm, *rsp;

  //wait for sys ready
  ACE_OS::sleep(ACE_Time_Value(1));

  //start ping-pong
  rsp = new Ping_Pong_Msg();
  rsp->count = 0;
  strcpy(rsp->data,"Lets ping pong...");
  rsp->len = strlen("Lets ping pong...");
  Msg *m = new Msg(PING_MSG, rsp);
  my_port()->send_msg(m);

  for(;;) {
  ACE_OS::sleep(ACE_Time_Value(100));
  
    if(my_port()->recv_msg(msg) == SUCCESS) {
      //handle_msg(msg);
      if(msg->type == PONG_MSG) {
	sm = (Ping_Pong_Msg *)msg;
	sm->data[sm->len-1] = '\0';

	ACE_DEBUG ((LM_DEBUG, "(%t) (%s) receive the Pong_Pong_Msg[%d]: \n%s\n",
		    my_name().c_str(),sm->count,sm->data));
 
	rsp = new Ping_Pong_Msg();
	rsp->len = sm->len;
	rsp->count = sm->count+1;
	if(rsp->count > 4096) rsp->count=0;
	strcpy(rsp->data,sm->data);

	delete sm;

	ACE_OS::sleep(ACE_Time_Value(1));

	m = new Msg(PING_MSG, rsp);
	my_port()->send_msg(m);
      }
    } else {
      //handle_error();
      break;
    }
 
  }

  ACE_DEBUG ((LM_DEBUG,
	      "(%t) %s pong_task exits...\n", my_name().c_str()));

  return 0;
}

ACE_FACTORY_DEFINE (PongTask, Pong_Task)
