////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <DemoTask.h>
#include <DemoTask_export.h>

//----------------------------------------------
// the following 3 methods should be overwritten
// to implement application logic
//----------------------------------------------

//app hooks for resource reservation & cleanup
Status Demo_Task::prepare(void)
{  
  //subscribe msg
  my_port()->subscribe_msg(TEST_STRING_MSG);
  return SUCCESS;
}

Status Demo_Task::cleanup(void)
{
  //unsubscribe msg 
  my_port()->unsubscribe_msg(TEST_STRING_MSG);
  return SUCCESS;
}
 

int Demo_Task::work() {
  ACE_DEBUG ((LM_DEBUG,
	      "(%t) %s demo_task coming up ...\n", my_name().c_str()));
  Msg *msg;
  Test_String_Msg *sm;

  for(;;) {
    if(my_port()->recv_msg(msg) == SUCCESS) {
      //handle_msg(msg);
      if(msg->type == TEST_STRING_MSG) {
	sm = (Test_String_Msg *)msg->data();
	sm->data[sm->len-1] = '\0';

	ACE_DEBUG ((LM_DEBUG, "(%t) (%s) receive the following: \n%s\n",
		    my_name().c_str(),sm->data));
 
	delete msg;
      }

    } else {
      //handle_error();
      break;
    }
  }

  ACE_DEBUG ((LM_DEBUG,
	      "(%t) %s demo_task exits...\n", my_name().c_str()));

  return 0;
}

ACE_FACTORY_DEFINE (DemoTask, Demo_Task)
