////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _TASK_MSG_H_
#define _TASK_MSG_H_

#include <Channel.h>

/*  for channel using int as msg id/type 
int PING_MSG=2000;
int PONG_MSG=2001;
int TEST_STRING_MSG=2002;
*/

std::string PING_MSG = "_PING_";
std::string PONG_MSG = "_PONG_";
std::string TEST_STRING_MSG = "_TEST_";

struct Test_String_Msg {
  enum { MAX_STR_LEN = 1024 };
  int len;
  char data[MAX_STR_LEN];
  Test_String_Msg() {
  }
};

class Ping_Pong_Msg {
 public:
  enum { MAX_STR_LEN = 1024*1024 };
  int len;
  char data[MAX_STR_LEN];
  int count;
  Ping_Pong_Msg() {
  }
};


#endif
