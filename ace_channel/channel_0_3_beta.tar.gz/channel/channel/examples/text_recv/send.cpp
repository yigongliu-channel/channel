////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * text_recv - simple C++ code to use channels with linear namespace and routing
 * to recv/send msgs
 * apply both asynchronous message passing and synchronous
 * event dispatching 
 */

#include <iostream>
#include <string>

#include <Channel.h>

using namespace std;
using namespace channel;

//---------------------------------------------------------------
// Channel specialization
//
// use std::string as message/event ids;
//typedef string IdType;
// use int as message/event ids;
//typedef int IdType;
// use a POD struct as message/event ids;
typedef channel::StructId IdType;

//define Channel type with defined IdType, other template parameters
//take the default values: IdTrait<IdType>, ACE_MT_SYNCH, MapRouter
typedef Channel<IdType> Chan;
typedef Channel<IdType>::Msg ChanMsg;

//------------------------------------------------------------------
// Message definitions :
//
//message ids for channel using int as msg id/type 
/*
int PING_MSG=2000;
int PONG_MSG=2001;
int TEST_STRING_MSG=2002;
*/
//message ids for channel using string as msg id/type 
/*
std::string PING_MSG = "_PING_";
std::string PONG_MSG = "_PONG_";
std::string TEST_STRING_MSG = "_TEST_";
*/
//ids for channel using POD struct as msg id/type 
channel::StructId PING_MSG = {channel::APPLICATION_MESSAGE, 1};
channel::StructId PONG_MSG = {channel::APPLICATION_MESSAGE, 2};
channel::StructId TEST_STRING_MSG = {channel::APPLICATION_MESSAGE, 3};

//simple POD struct for msg definition
struct Test_String_Msg {
  enum { MAX_STR_LEN = 1024 };
  int len;
  char data[MAX_STR_LEN];
  Test_String_Msg() {
  }
};

//----------------------------------------------------------------
// Implementation
//

int main (int , char *argv[]) {
   
  //step1. create channel
  Chan * my_chan = new Chan(); 
  
  //step2. connect remote channels
  char *peer_addr = argv[1];
#if !defined (ACE_WIN32)
  Chan::UnixSockConnector *unix_conn = new Chan::UnixSockConnector(my_chan, true);
  unix_conn->open ();
  if (unix_conn->connect (peer_addr) == FAILURE) { 
    cout << "failed to connect peer unix domain socket at " << peer_addr << endl;
    return -1;
  }
#else
  Chan::TcpSockConnector *tcp_conn = new Chan::TcpSockConnector(my_chan, true);
  tcp_conn->open ();
  if (tcp_conn->connect (peer_addr) == FAILURE) { 
    cout << "failed to connect peer tcp socket at " << peer_addr << endl;
    return -1;
  }
#endif
  //step3. create src attached to channels
  Chan::Source my_src(my_chan); 
 
  //step4. publish msgs thru src, 
  //       default scope = SCOPE_GLOBAL: ie. publish to all receivers
  my_src.publish_msg(TEST_STRING_MSG);

  cout << "text_sender coming up ...\n";

  //step5. main thread will run in loop to send msgs
  for(;;) {
    cout <<  "--- Please enter one line msg: " << endl;
      Test_String_Msg *tm =  new Test_String_Msg();
      if (!gets (tm->data)) {
	delete tm;
	break;
      }
      tm->len = strlen(tm->data)+1;
      my_src.send_msg (TEST_STRING_MSG, tm);
  }

  cout <<  "text_sender  exits...\n";

  return 0;
}
