////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * text_recv - simple C++ code to use channels with linear namespace and routing
 * to recv/send msgs
 * apply both asynchronous message passing and synchronous
 * event dispatching 
 */

#include <iostream>
#include <string>

#include <Channel.h>

using namespace std;
using namespace channel;

//---------------------------------------------------------------
// Channel specialization
//
// use std::string as message/event ids;
//typedef string IdType;
// use int as message/event ids;
//typedef int IdType;
// use a POD struct as message/event ids;
typedef channel::StructId IdType;

//define Channel type with defined IdType, other template parameters
//take the default values: IdTrait<IdType>, ACE_MT_SYNCH, MapRouter
typedef Channel<IdType> Chan;
typedef Chan::Msg ChanMsg;

//------------------------------------------------------------------
// Message definitions :
//
//ids for channel using int as msg id/type 
/*
int PING_MSG=2000;
int PONG_MSG=2001;
int TEST_STRING_MSG=2002;
*/
//ids for channel using string as msg id/type 
/*
std::string PING_MSG = "_PING_";
std::string PONG_MSG = "_PONG_";
std::string TEST_STRING_MSG = "_TEST_";
*/
//ids for channel using POD struct as msg id/type 

channel::StructId PING_MSG = {channel::APPLICATION_MESSAGE, 1};
channel::StructId PONG_MSG = {channel::APPLICATION_MESSAGE, 2};
channel::StructId TEST_STRING_MSG = {channel::APPLICATION_MESSAGE, 3};

//a simple POD struct for message content
struct Test_String_Msg {
  enum { MAX_STR_LEN = 1024 };
  int len;
  char data[MAX_STR_LEN];
  Test_String_Msg() {
  }
};

//----------------------------------------------------------------
// Implementation
//

//a simple demo callback functor
struct cb_demo {
	void operator()(ChanMsg *msg) {
		Test_String_Msg *sm = (Test_String_Msg *)msg->data();
		cout << "hier_recv/My_Callback recv the following: " << sm->data << endl;
		cout << "...... Please notice callback borrow Channel internal thread\n";
		delete msg;
	}
};

int main (int argc, char *argv[]) {

  if (argc < 2) {
    cout << "Usage: recv my_unix_sock_path peer_unix_sock_path\n";
    return -1;
  }

  //step1. create channel
  Chan * my_chan = new Chan(); 
  
  //step2. setup channels:
  //       1. listening at specified address for incoming connections
  //       2. connect to remote peer channel at specified address
  char *my_addr = argv[1];
#if !defined (ACE_WIN32)
  Chan::UnixSockConnector *unix_conn = new Chan::UnixSockConnector(my_chan, true);
  if (unix_conn->open (my_addr) == FAILURE) {
    cout << "failed to open my unix domain socket at " <<  my_addr << endl;
    return -1;
  }
  if (argc >= 3) {
    char *peer_addr = argv[2];
    if (unix_conn->connect (peer_addr) == FAILURE) { 
      cout << "failed to connect peer unix domain socket at " << peer_addr << endl;
      return -1;
    }
  }
#else
  Chan::TcpSockConnector *tcp_conn = new Chan::TcpSockConnector(my_chan, true);
  if (tcp_conn->open (my_addr) == FAILURE) {
    cout << "failed to open at " << my_addr << endl;
    return -1;
  }
  if (argc >= 3) {
    char *peer_addr = argv[2];
    if (tcp_conn->connect (peer_addr) == FAILURE) { 
      cout << "failed to connect peer  at " << peer_addr << endl;
      return -1;
    }
  }
#endif

  //step3. create ports/callbacks attached to my channel
  Chan::Port my_port(my_chan); //use my own queue
  Callback<Chan, cb_demo> my_callback(my_chan, cb_demo());

  //step4. subscribe msgs thru ports/callbacks,
  //       default scope = SCOPE_GLOBAL ie. subscribe to message from all publishers
  my_port.subscribe_msg(TEST_STRING_MSG);
  my_callback.subscribe_msg(TEST_STRING_MSG);

  cout << "text_recv coming up ...\n";

  ChanMsg *msg;
  Test_String_Msg *sm;
 
  //step5. main thread will run in loop to recv msgs from ports and process them
  for(;;) {
    if(my_port.recv_msg(msg) == SUCCESS) {
      if (msg->type == TEST_STRING_MSG) {
	sm = (Test_String_Msg *)msg->data();
	sm->data[sm->len-1] = '\0';
	cout << "text_recv receive the following: " <<  sm->data << endl;
	//because of reference counting, delete msg (dont delete msg->data()!)
	delete msg;
      }
    } else {
      //handle_error();
      break;
    }
  }

  cout << "text_recv  exits...\n";

  return 0;
}
