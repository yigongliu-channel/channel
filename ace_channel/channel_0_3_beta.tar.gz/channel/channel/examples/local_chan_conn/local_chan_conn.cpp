////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * local_chan_conn - simple C++ code to test local chan conn
 */

#include "ace/OS_main.h"
#include "ace/ACE.h"
#include "ace/Auto_Ptr.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_stdio.h"
#include "ace/Get_Opt.h"

#include <iostream>
#include <string>
#include <Channel.h>

using namespace std;
using namespace channel;


//---------------------------------------------------------------
// Channel specialization
//
// use std::string as message/event ids;
//typedef string IdType;
// use int as message/event ids;
//typedef int IdType;
// use a POD struct as message/event ids;
typedef channel::StructId IdType;

//define Channel type with defined IdType, other template parameters
//take the default values: IdTrait<IdType>, ACE_MT_SYNCH, MapRouter
typedef Channel<IdType> Chan;
typedef Chan::Msg ChanMsg;

//------------------------------------------------------------------
// Message definitions :
//
//ids for channel using int as msg id/type 
/*
int PING_MSG=2000;
int PONG_MSG=2001;
int TEST_STRING_MSG=2002;
*/
//ids for channel using string as msg id/type 
/*
std::string PING_MSG = "_PING_";
std::string PONG_MSG = "_PONG_";
std::string TEST_STRING_MSG = "_TEST_";
*/
//ids for channel using POD struct as msg id/type 

channel::StructId PING_MSG = {channel::APPLICATION_MESSAGE, 1};
channel::StructId PONG_MSG = {channel::APPLICATION_MESSAGE, 2};
channel::StructId TEST_STRING_MSG = {channel::APPLICATION_MESSAGE, 3};

//a simple POD struct for message content
struct Test_String_Msg {
  enum { MAX_STR_LEN = 1024 };
  int len;
  char data[MAX_STR_LEN];
  Test_String_Msg() {
  }
};

//----------------------------------------------------------------
// Implementation
//

//a simple demo callback functor
struct cb_demo {
	void operator()(ChanMsg *msg) {
		Test_String_Msg *sm = (Test_String_Msg *)msg->data();
		cout << "hier_recv/My_Callback recv the following: " << sm->data << endl;
		cout << "...... Please notice callback borrow Channel internal thread\n";
		delete msg;
	}
};

int ACE_TMAIN (int argc, ACE_TCHAR *argv[]) {
  ACE_UNUSED_ARG(argc);
  ACE_UNUSED_ARG(argv);

  ACE::debug('y');

  ACE_LOG_MSG->open
    (argv[0], ACE_Log_Msg::SYSLOG, ACE_TEXT (argv[0]));
  ACE_LOG_MSG->set_flags (ACE_Log_Msg::STDERR);

  ///create channels
  Chan * chan1 = new Chan(); 
  Chan * chan2 = new Chan(); 
  
  if (Chan::LocalConnector::connect (chan1, chan2) != SUCCESS)
    ACE_DEBUG ((LM_DEBUG, "(%t) failed to connect 2 local channels ...\n"));

  ///create source/callbacks attached to channels
  Callback<Chan, cb_demo> my_callback(chan2, cb_demo());
  Chan::Source my_src(chan1);

  ///pub/sub msgs thru ports/callbacks
  my_src.publish_msg(TEST_STRING_MSG);
  my_callback.subscribe_msg(TEST_STRING_MSG);

  ACE_DEBUG ((LM_DEBUG, "(%t) local_chan_conn coming up ...\n"));

  ///send msgs from src -> chan1 -> chan2 -> callback

  for(;;) {
      ACE_DEBUG((LM_DEBUG,  "--- Please enter one line msg: "));
      Test_String_Msg *tm =  new Test_String_Msg();
      if (!gets (tm->data))
	break;
      tm->len = strlen(tm->data)+1;
      my_src.send_msg (TEST_STRING_MSG, tm);
  }

  return 0;
}
