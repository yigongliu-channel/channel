////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * hier_text_recv/send.cpp - simple C++ code to use channels with hierarchical 
 * namespace and routing to recv/send msgs
 * apply both asynchronous message passing and synchronous
 * event dispatching 
 */

#include <iostream>
#include <string>

#include <Channel.h>

using namespace std;
using namespace channel;

//---------------------------------------------------------------
// Channel specialization
//
//define IdType as string pathnames with '/' as separator, same unix pathname
typedef StringPathId<'/'> IdType;

//define the channel type with the above string pathname id type, and use
//trie based hierarchical routing
typedef Channel<IdType, IdTrait<IdType>, ACE_MT_SYNCH, RoundRobinDispatcher, TrieRouter<IdType, IdTrait<IdType>, ACE_MT_SYNCH, RoundRobinDispatcher> > Chan;
typedef Chan::Msg ChanMsg;

//------------------------------------------------------------------
// Message definitions :
//
//application msgs ids 
const char * PING_MSG = "/APP/PING";
const char * PONG_MSG = "/APP/PONG";
const char * TEST_STRING_MSG = "/APP/TEST";
//a wildcard msg id; ie. all application messages
const char * APP_WILDCARD_MSG = "/APP/*";

//a simple POD struct for message content
struct Test_String_Msg {
  enum { MAX_STR_LEN = 1024 };
  int len;
  char data[MAX_STR_LEN];
  Test_String_Msg() {
  }
};

//----------------------------------------------------------------
// Implementation
//

int main (int argc, char **argv) {
  if (argc < 2) {
    std::cout << "Usage: hsend peer_host:port\n";
    return -1;
  } 
   
  //step1. create channel
  Chan * my_chan = new Chan(); 
  
  //step2. connect remote channels
  char *peer_addr = argv[1];
  Chan::TcpSockConnector *tcp_conn = new Chan::TcpSockConnector(my_chan, true);
  tcp_conn->open ();
  if (tcp_conn->connect (peer_addr) == FAILURE) { 
    cout << "failed to connect peer tcp socket at " << peer_addr << endl;
    return -1;
  }

  //step3. create src attached to channels
  Chan::Source my_src(my_chan); 
 
  //step4. publish msgs thru src, 
  //       msg id = APP_WILDCARD_MSG: ie. my_src will send all types of app msgs
  //       default scope = SCOPE_GLOBAL: ie. publish to all receivers
  my_src.publish_msg(APP_WILDCARD_MSG);

  cout << "hier_sender coming up ...\n";

  //step5. main thread will run in loop to send msgs
  for(;;) {
    //ask user to input message in simple format: type|content_data
    //if no type defined, treat as TEST_STRING_MSG
    cout << "--- Please enter one line msg [type(ping,pong,test)|data]  ";
    Test_String_Msg *tm =  new Test_String_Msg();
    if (!gets (tm->data)) {
      delete tm;
      break;
    }
    tm->len = strlen(tm->data)+1;
    string str(tm->data);
    size_t pos = str.find('|');
    const char *id;
    if (pos == string::npos) 
      id = TEST_STRING_MSG;
    else if (str.substr(0,pos) == "ping")
      id = PING_MSG;
    else if (str.substr(0,pos) == "pong")
      id = PONG_MSG;
    else
      id = TEST_STRING_MSG;
      
    my_src.send_msg (id, tm);
  }

  cout << "hier_sender  exits...\n";

  return 0;
}
