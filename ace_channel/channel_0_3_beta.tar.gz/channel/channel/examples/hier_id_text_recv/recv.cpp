////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * hier_text_recv/recv.cpp - simple C++ code to use channels with hierarchical 
 * namespace and routing to recv/send msgs
 * apply both asynchronous message passing and synchronous
 * event dispatching 
 */

#include <iostream>
#include <string>

#include <Channel.h>

using namespace std;
using namespace channel;

//---------------------------------------------------------------------------
// Channel specialization
//
//define IdType as string pathnames with '/' as separator, same as unix pathname
typedef StringPathId<'/'> IdType;

//define the channel type with the above string pathname id type, and use
//trie based hierarchical routing
typedef Channel<IdType, IdTrait<IdType>, ACE_MT_SYNCH, RoundRobinDispatcher, TrieRouter<IdType, IdTrait<IdType>, ACE_MT_SYNCH, RoundRobinDispatcher> > Chan;
typedef Chan::Msg ChanMsg;

//---------------------------------------------------------------------------
// Message definitions :
//
//specific application msgs ids 
IdType PING_MSG = "/APP/PING";
IdType PONG_MSG = "/APP/PONG";
IdType TEST_STRING_MSG = "/APP/TEST";
//a wildcard msg id; ie. all application messages
IdType APP_WILDCARD_MSG = "/APP/*";

//a simple POD struct for message content
struct Test_String_Msg {
  enum { MAX_STR_LEN = 1024 };
  int len;
  char data[MAX_STR_LEN];
  Test_String_Msg() {
  }
};

//----------------------------------------------------------------
// Implementation
//
//a simple demo callback, which can be functions or functors
void cb_func(ChanMsg *msg) {
    Test_String_Msg *sm = (Test_String_Msg *)msg->data();
    cout << "hier_recv/My_Callback recv the following: " << sm->data << endl;
    cout << "...... Please notice callback borrow Channel internal thread\n";
	cout.flush();
    delete msg;
}

int main (int argc, char **argv) {
  if (argc < 2) {
    cout << "Usage: hrecv my_host:port [peer_host:port]\n";
    return -1;
  }

  //step1. create channel:
  Chan * my_chan = new Chan(); 
  
  //step2. setup channels
  //       1. listening at specified address for incoming connections
  //       2. connect to remote peer channel at specified address
  char *my_addr = argv[1];
  Chan::TcpSockConnector *tcp_conn = new Chan::TcpSockConnector(my_chan, true);
  if (tcp_conn->open (my_addr) == FAILURE) {
    cout << "failed to open at " << my_addr << endl;
    return -1;
  }
  if (argc >= 3) {
    char *peer_addr = argv[2];
    if (tcp_conn->connect (peer_addr) == FAILURE) { 
      cout << "failed to connect peer  at " << peer_addr << endl;
      return -1;
    }
  }

  //step3. create ports/callbacks attached to channels
  Chan::Port my_port(my_chan); //use my own queue
  //My_Callback my_calbak(my_chan);
  typedef void (*CallbackFuncPtr) (ChanMsg *);
  Callback<Chan, CallbackFuncPtr> my_callback(my_chan, cb_func);
 
  //step4. subscribe msgs thru ports/callbacks
  //       default scope = SCOPE_GLOBAL ie. subscribe to message from all publishers
  //my_port subscribe to wildcard message id, so the main thread will receive
  //all types of application messages (ping, pong, test)
  my_port.subscribe_msg(APP_WILDCARD_MSG);
  //my callback subscribe TEST_STRING_MSG, so it will only receive this type of msgs
  my_callback.subscribe_msg(TEST_STRING_MSG);

  cout << "hier_recv coming up ...\n";

  ChanMsg *msg;
  Test_String_Msg *sm;
 
  //step5. main thread will run in loop to recv msgs from ports and process them
  for(;;) {
    if(my_port.recv_msg(msg) == SUCCESS) {
      sm = (Test_String_Msg *)msg->data();
      sm->data[sm->len-1] = '\0';
      cout << "hier_recv thread receive the following: " << sm->data << endl;
      //because of reference counting, delete msg (dont delete msg->data()!)
      delete msg;
    } else {
      //handle_error();
      break;
    }
  }

  cout << "hier_recv  exits...\n";

  return 0;
}
