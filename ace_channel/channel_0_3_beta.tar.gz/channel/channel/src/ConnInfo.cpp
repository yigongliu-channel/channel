////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <ConnInfo.h>
#include "ace/OS.h"
#include "ace/os_include/os_netdb.h"
#include "ace/Log_Msg.h"
#include "ace/INET_Addr.h"
#include <ctype.h>

using namespace std;
using namespace channel;

void ConnInfo::parse(string conn_info) {
  valid_ = false;
  if (conn_info.length() == 0)
    return;
  size_t pos1 = conn_info.find(":");
  if(pos1 == string::npos) {
    bool found = false;
    for(size_t i=0; i<conn_info.length() && !found; i++) 
      if (::isdigit(conn_info[i]) == 0) found = true;
    if (found)
      type_ = UNIX_SOCK;
    else
      type_ = INET_SOCK;
  } else {
    type_ = INET_SOCK;
  }
  if(type_ == INET_SOCK) {
    if(pos1 == string::npos) {
      ip_ = ACE_LOCALHOST;
      port_ = ACE_OS::atoi(conn_info.c_str());
    } else {
      ip_ = conn_info.substr(0,pos1);
      port_ = ACE_OS::atoi((conn_info.substr(pos1+1,string::npos)).c_str());
    }
  } else 
    unix_addr_ = conn_info.substr(0,string::npos);
  if(type_ == INET_SOCK)
    ACE_DEBUG ((LM_DEBUG, "rmt_ip=%s, rmt_port=%d\n", ip_.c_str(), port_));
  else
    ACE_DEBUG ((LM_DEBUG, "unix_addr=%s\n", unix_addr_.c_str()));
  valid_ = true;
}

void ConnInfo::dump(void) {
  switch(type_) {
  case INET_SOCK:
    ACE_DEBUG ((LM_DEBUG, "ip=%s ",ip_.c_str()));
    ACE_DEBUG ((LM_DEBUG, " port=%d\n", port_)) ;
    break;
  case UNIX_SOCK:
    ACE_DEBUG ((LM_DEBUG, "unix_addr=%s\n", unix_addr_.c_str())) ;
    break;
  default:
    ACE_DEBUG ((LM_DEBUG, "Invalid Conn type...\n"));
    break;
  }
}

bool ConnInfo::operator== (const ConnInfo &ci) const {
  if(type_ != ci.type_) return false;
  switch(type_) {
  case UNIX_SOCK:
    return unix_addr_ == ci.unix_addr_;
    break;
  case INET_SOCK:
    {
      return ip_ != ci.ip_ ? false : port_ == ci.port_;
    }
    break;
  default:
    ACE_DEBUG ((LM_DEBUG, "invalid ConnInfo type...\n"));
    break;
  }
  //should not reach here
  ACE_DEBUG ((LM_DEBUG, "Should not reach here in ConnInfo ....\n"));
  return true;
}

bool ConnInfo::operator< (const ConnInfo &ci) const {
  if(type_ != ci.type_) return type_ < ci.type_;
  switch(type_) {
  case UNIX_SOCK:
    return unix_addr_ < ci.unix_addr_;
    break;
  case INET_SOCK:
    {
      return ip_ != ci.ip_ ? ip_ < ci.ip_ : port_ < ci.port_;
    }
    break;
  default:
    ACE_DEBUG ((LM_DEBUG, "invalid ConnInfo type...\n"));
    break;
  }
  //should not reach here
  ACE_DEBUG ((LM_DEBUG, "Should not reach here in ConnInfo ....\n"));
  return true;
}
