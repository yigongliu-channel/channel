////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <HierarchicalIdTrait.h>
#include <string>

using namespace std;
using namespace channel;

/// definitions of system messages for StringPathId<'/'> ids
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::CHANNEL_CONN_MSG = "/SYS/CHANNEL_CONN_MSG";
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::CHANNEL_DISCONN_MSG = "/SYS/CHANNEL_DISCONN_MSG";
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::INIT_SUBSCRIPTION_INFO_MSG = "/SYS/INIT_SUBSCRIPTION_INFO_MSG";
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::INIT_PUBLICATION_INFO_MSG = "/SYS/INIT_PUBLICATION_INFO_MSG";
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::SUBSCRIPTION_INFO_MSG = "/SYS/SUBSCRIPTION_INFO_MSG";
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::UNSUBSCRIPTION_INFO_MSG = "/SYS/UNSUBSCRIPTION_INFO_MSG";
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::PUBLICATION_INFO_MSG = "/SYS/PUBLICATION_INFO_MSG";
template <> StringPathId<'/'> IdTrait<StringPathId<'/'> >::UNPUBLICATION_INFO_MSG = "/SYS/UNPUBLICATION_INFO_MSG";
template <> StringPathId<'/'>::value_type IdTrait<StringPathId<'/'> >::RootName = "//";
template <> StringPathId<'/'>::value_type IdTrait<StringPathId<'/'> >::WildcardName = "*";
 
