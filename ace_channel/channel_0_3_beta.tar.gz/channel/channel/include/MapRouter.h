////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAP_ROUTER_H_
#define _MAP_ROUTER_H_

//ACE headers
#include "ace/Log_Msg.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

//std
#include <map>
#include <list>
#include <vector>
#include <string>
#include <algorithm>

//Channel
#include <BaseDef.h>
#include <RouterBase.h>
#include <Msg.h>
#include <TemplateUtils.h>

namespace channel {

  template <class, class, class, class, class> class Channel;

  /**
   *     MapRouter:
   *     using stl map as routing table
   *     using id matching
   */  
  template <class IdType, class IdTrait, class SynchPolicy/*, AllocPolicy*/, class Dispatch_Policy>
  class MapRouter : 
                  public RouterBase,
                  public IF<((int)Dispatch_Policy::type==(int)STATELESS), 
                            DispWrapper<Dispatch_Policy>, EmptyType>::RET {
  public:
    enum { NamespaceType = NAMESPACE_LINEAR };

  private:
    typedef Channel<IdType, IdTrait, SynchPolicy, Dispatch_Policy, MapRouter<IdType, IdTrait, SynchPolicy, Dispatch_Policy> > Channel;
    typedef Destination<Channel, NamespaceType> DestinationT;
    typedef Source<Channel, NamespaceType> SourceT;
    //cannot use Channel::Msg here, since Channel is not defined yet
    //Channel is defined using Router
    typedef Msg<IdType, SynchPolicy> MsgT;
    typedef PubSub_Info_Msg<IdType> PubSub_Info_MsgT;

  public:
    typedef Dispatch_Policy DispatchPolicy;
    typedef std::vector<DestinationT *> DispatchContainer;

  private:

    struct PubSub_Registry : 
           public IF<(int)Dispatch_Policy::type==(int)STATEFUL, 
                            DispWrapper<Dispatch_Policy>, EmptyType>::RET {
      std::map<DestinationT *, PubSub_Scope> *subers_;
      typename SynchPolicy::RW_MUTEX subers_lock_;
      PubSub_Registry() {
	subers_ = NULL;
      }
      ~PubSub_Registry() {
	if (subers_ != NULL) {
	  ACE_WRITE_GUARD(typename SynchPolicy::RW_MUTEX, guard, subers_lock_);
	  delete subers_;
	}
      }
    };

    //subscription(routing) table
    std::map<IdType, PubSub_Registry*> msg_sub_tbl_;
    typename SynchPolicy::RW_MUTEX msg_sub_tbl_lock_;

    //publication(global) table
    std::map<IdType, std::list<SourceT *>*> msg_pub_tbl_;
    typename SynchPolicy::RW_MUTEX msg_pub_tbl_lock_;

  public:

    MapRouter() {
    }

    ~MapRouter() {
      {
	ACE_WRITE_GUARD(typename SynchPolicy::RW_MUTEX, guard, msg_sub_tbl_lock_);
	for(typename std::map<IdType, PubSub_Registry*>::iterator iter = msg_sub_tbl_.begin();
	    iter != msg_sub_tbl_.end(); iter++) {
	  if (iter->second != NULL)
	    delete iter->second;
	}
      }
      {
	ACE_WRITE_GUARD(typename SynchPolicy::RW_MUTEX, guard, msg_pub_tbl_lock_);
	for(typename std::map<IdType, std::list<SourceT *>*>::iterator iter2 = msg_pub_tbl_.begin();
	    iter2 != msg_pub_tbl_.end(); iter2++) {
	  if (iter2->second != NULL)
	    delete iter2->second;
	}
      }
    }

    /**
     * 1. Local operations on Channel/Router namespace:
     *    pub/unpub, sub/unsub
     */
    /// publish 
    Status publish_msg(IdType t, PubSub_Scope s, SourceT *src)
      {
	bool send2remote = false;
	if (s == SCOPE_REMOTE || s == SCOPE_GLOBAL) {
	  ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_pub_tbl_lock_, FAILURE);
	  std::list<SourceT *> *srcs = NULL;
	  typename std::map<IdType, std::list<SourceT *>*>::iterator iter = msg_pub_tbl_.find(t);
	  if(iter != msg_pub_tbl_.end())
	    srcs = iter->second;
	  if(srcs == NULL) {
	    srcs = new std::list<SourceT *>();
	    msg_pub_tbl_[t] = srcs;
	    send2remote = true;
	  }
	  if(std::find(srcs->begin(),srcs->end(),src)==srcs->end()) {
	    srcs->push_back(src);
	  }
	}
	if (send2remote)
	  propagate_change_to_neighbors(OPER_PUBLISH, t);
	return SUCCESS;
      }

    ///unpublish
    Status unpublish_msg(IdType t, PubSub_Scope s, SourceT *src)
      {
	bool send2remote = false;
	if (s == SCOPE_REMOTE || s == SCOPE_GLOBAL) {
	  ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_pub_tbl_lock_, FAILURE);
	  std::list<SourceT *> *srcs = NULL;
	  typename std::map<IdType, std::list<SourceT *>*>::iterator iter = msg_pub_tbl_.find(t);
	  if(iter != msg_pub_tbl_.end())
	    srcs = iter->second;
	  if(srcs == NULL) return FAILURE;
	  typename std::list<SourceT *>::iterator iter2 = std::find(srcs->begin(),srcs->end(),src);
	  if (iter2 == srcs->end()) return FAILURE;
	  srcs->erase(iter2);
	  if(srcs->empty()) {
	    msg_pub_tbl_.erase(t);
	    send2remote = true;
	  }
	}
	if (send2remote)
	  propagate_change_to_neighbors(OPER_UNPUBLISH, t);
	return SUCCESS;
      }

    ///subscribe
    Status subscribe_msg(IdType t, PubSub_Scope c, DestinationT *dest) 
      {
	ACE_DEBUG((LM_DEBUG, "MapRouter::subscribe_msg: [%s]\n",ID2STR(t).c_str()));
	bool send2remote = false;
	PubSub_Registry *reg = NULL;
	{
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_sub_tbl_lock_, FAILURE);
	  typename std::map<IdType, PubSub_Registry*>::iterator iter = msg_sub_tbl_.find(t);
	  if (iter != msg_sub_tbl_.end())
	    reg = iter->second;
	}
	if (reg == NULL) {
	  ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_sub_tbl_lock_, FAILURE);
	  reg = new PubSub_Registry();
	  msg_sub_tbl_[t] = reg;
	  send2remote = true;
	}
	{
	  ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_, FAILURE);
	  if (reg->subers_ == NULL) {
	    reg->subers_ = new std::map<DestinationT *, PubSub_Scope>();
	    send2remote = true;
	  }
	  if (!send2remote) {
	    send2remote = true;
	    for(typename std::map<DestinationT *, PubSub_Scope>::iterator iter = reg->subers_->begin();
		iter != reg->subers_->end(); iter++)
	      if (iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL)
		send2remote = false;
	  }
	  (*reg->subers_)[dest] = c;
	}
	if (send2remote && dest->type()==MEMBER_LOCAL && (c == SCOPE_REMOTE || c == SCOPE_GLOBAL))
	  propagate_change_to_neighbors(OPER_SUBSCRIBE, t);
	return SUCCESS;
      }

    ///unsubscribe
    Status unsubscribe_msg(IdType t, DestinationT *dest)
      {
	ACE_DEBUG((LM_DEBUG, "MapRouter::unsubscribe_msg[%s]...\n", ID2STR(t).c_str()));
	bool send2remote = false;
	PubSub_Registry *reg = NULL;
	{
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_sub_tbl_lock_, FAILURE);
	  typename std::map<IdType, PubSub_Registry*>::iterator iter = msg_sub_tbl_.find(t);
	  if (iter != msg_sub_tbl_.end())
	    reg = iter->second;
	}
	if (reg == NULL) 
	  return SUCCESS;
	{
	  ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_, FAILURE);
	  if (reg->subers_ == NULL || reg->subers_->empty())
	    return SUCCESS;
	  typename std::map<DestinationT *, PubSub_Scope>::iterator iter = reg->subers_->find(dest);
	  if (iter == reg->subers_->end())
	    return SUCCESS;
	  if (dest->type() == MEMBER_LOCAL && 
	      (iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
	    send2remote = true;
	  reg->subers_->erase(dest);
	  if (send2remote && !reg->subers_->empty()) {
	    for(iter = reg->subers_->begin(); iter != reg->subers_->end(); iter++) {
	      if (iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL)
		send2remote = false;
	    }
	  }
	}
	if (send2remote)
	  propagate_change_to_neighbors(OPER_UNSUBSCRIBE, t);
	return SUCCESS;
      }
    
    /**
     * 2.
     * route msgs (from src to dest) based on :
     * src_type(local/remote) & publish_scope AND
     * dest_type(local/remote) & subscribe_scope
     */
    Status route_msg(MsgT *msg, Member_Type src_type, PubSub_Scope pub_scope, ACE_Time_Value *timeout=0)
      {
	ACE_DEBUG ((LM_DEBUG, "MapRouter::route_msg: src_type[%d],scope[%d],msg[%s]\n", src_type, pub_scope, ID2STR(msg->type).c_str()));
	PubSub_Registry *reg = NULL;
	{
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_sub_tbl_lock_, FAILURE);
	  typename std::map<IdType, PubSub_Registry*>::iterator iter = msg_sub_tbl_.find(msg->type);
	  if (iter != msg_sub_tbl_.end())
	    reg = iter->second;
	}
	if (reg == NULL) {
	  ACE_DEBUG ((LM_DEBUG, "msg [%s] dropped, no puber/suber\n", ID2STR(msg->type).c_str()));
	  delete msg;
	  return FAILURE;
	}
	//distribute to subscribers
	{
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_, FAILURE);
	  if (reg->subers_ == NULL || reg->subers_->empty()) {
	    ACE_DEBUG ((LM_DEBUG, "msg [%s] dropped, no subscriber\n", ID2STR(msg->type).c_str()));
	    delete msg;
	    return FAILURE;
	  }
	  	  
	  DispatchContainer subers;

	  for(typename std::map<DestinationT *, PubSub_Scope>::iterator iter = reg->subers_->begin(); 
	      iter != reg->subers_->end(); iter++) {
	    short src_row = src_type * SCOPE_NUMBER + pub_scope;
	    short dst_col = iter->first->type() * SCOPE_NUMBER + iter->second;
	    if(scope_checking_tbl_[src_row][dst_col]) {
	      subers.push_back(iter->first);
	    }
	  }

	  if (subers.size() == 0) {
	    ACE_DEBUG ((LM_DEBUG, "msg [%s] dropped, scope dont match\n", ID2STR(msg->type).c_str()));
	    delete msg;
	  } else if (subers.size() == 1) {
	    ACE_DEBUG ((LM_DEBUG, "msg [%s] delivered\n", ID2STR(msg->type).c_str()));
	    subers[0]->put_msg(msg, timeout);
	  } else 
	    internal_dispatch(reg, subers.begin(), subers.end(), msg, timeout);
	}

	return SUCCESS;
      }

    /**
     * 3. query msg_sub_tbl content
     */
    ///exported msg_sub_tbl
    Status subscribed_global_msgs(std::vector<IdType> &global_msgs)
      {
	ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_sub_tbl_lock_, FAILURE);
	for(typename std::map<IdType, PubSub_Registry*>::iterator iter = msg_sub_tbl_.begin();
	    iter != msg_sub_tbl_.end(); iter++) {
	  PubSub_Registry *reg = iter->second;
	  if (reg == NULL) 
	    continue;

	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_, FAILURE);
	  if (reg->subers_ == NULL || reg->subers_->empty()) 
	    continue;

	  bool found = false;
	  for(typename std::map<DestinationT *, PubSub_Scope>::iterator iter2 = reg->subers_->begin(); 
	      iter2 != reg->subers_->end() && !found; iter2++) {
	    if (iter2->first->type() == MEMBER_LOCAL && 
		(iter2->second == SCOPE_REMOTE || iter2->second == SCOPE_GLOBAL)) {
	      found = true;
	    }
	  }
	  if (found) 
	    global_msgs.push_back(iter->first);
	}

	return SUCCESS;
      }

    Status published_global_msgs(std::vector<IdType> &global_msgs)
      {
	ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, msg_pub_tbl_lock_, FAILURE);
	for(typename std::map<IdType, std::list<SourceT *>* >::iterator iter = msg_pub_tbl_.begin();
	    iter != msg_pub_tbl_.end(); iter++) {
	  if (iter->second != NULL && !iter->second->empty())
	    global_msgs.push_back(iter->first);
	}

	return SUCCESS;
      }

    void dump_routing_tables(void)
      {
	ACE_DEBUG((LM_DEBUG, "The following %d IdTypes subscribed: \n", msg_sub_tbl_.size()));
	{
	  ACE_READ_GUARD(typename SynchPolicy::RW_MUTEX, guard, msg_sub_tbl_lock_);
	  for(typename std::map<IdType, PubSub_Registry*>::iterator iter = msg_sub_tbl_.begin();
	      iter != msg_sub_tbl_.end(); iter++) {
	    PubSub_Registry *reg = iter->second;
	    if (reg == NULL) 
	      continue;

	    ACE_READ_GUARD(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_);
	    if (reg->subers_ == NULL || reg->subers_->empty()) 
	      continue;

	    ACE_DEBUG((LM_DEBUG, "%s\n", ID2STR(iter->first).c_str()));
	  }
	}

	ACE_DEBUG((LM_DEBUG, "The following %d IdTypes published: \n", msg_pub_tbl_.size()));
	{
	  ACE_READ_GUARD(typename SynchPolicy::RW_MUTEX, guard, msg_pub_tbl_lock_);
	  typename std::map<IdType, std::list<SourceT *>* >::iterator iter;
	  for(iter = msg_pub_tbl_.begin(); iter!=msg_pub_tbl_.end(); iter++) {
	    if(iter->second!=NULL && !iter->second->empty())
	      ACE_DEBUG((LM_DEBUG, "%s\n", ID2STR(iter->first).c_str()));
	  }
	}
      }

  protected:
    /**
     * 4. propagate namespace changes to connected channels
     */
    Status propagate_change_to_neighbors(Oper_Type op, IdType t)
      {
	ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors [%s]\n",ID2STR(t).c_str()));
	PubSub_Info_MsgT *sub = new PubSub_Info_MsgT();
	sub->num_msg_types = 1;
	sub->msg_types[0] = t;
	IdType mt;
	switch(op) {
	case OPER_PUBLISH:
	  mt = Channel::PUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors publish "));
	  break;
	case OPER_UNPUBLISH:
	  mt = Channel::UNPUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors unpublish "));
	  break;
	case OPER_SUBSCRIBE:
	  mt = Channel::SUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors subscribe "));
	  break;
	case OPER_UNSUBSCRIBE:
	  mt = Channel::UNSUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors unsubscribe "));
	  break;
	default:
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors invalid IdType "));
	  delete sub;
	  return SUCCESS;
	}
	MsgT *m = new MsgT(mt, sub);
	route_msg(m, MEMBER_LOCAL, SCOPE_REMOTE);
	return SUCCESS;
      }

  /**
   * template code to statically dispatch correct methods
   */
  void internal_dispatch (
			  PubSub_Registry *reg,
			  typename DispatchContainer::iterator begin, 
			  typename DispatchContainer::iterator end, 
			  MsgT *msg, 
			  ACE_Time_Value *timeout,
			  Int2Type<true>
			  ) 
  {
    //stateless dispatcher
    ACE_UNUSED_ARG(reg);
    this->dispatcher_(begin,end,msg,timeout);
  }
  void internal_dispatch (
			  PubSub_Registry *reg,
			  typename DispatchContainer::iterator begin, 
			  typename DispatchContainer::iterator end, 
			  MsgT *msg, 
			  ACE_Time_Value *timeout,
			  Int2Type<false>
			  ) 
  {
    //stateful dispatcher
    reg->dispatcher_(begin,end,msg,timeout);
  }
  void internal_dispatch (
			  PubSub_Registry *reg,
			  typename DispatchContainer::iterator begin, 
			  typename DispatchContainer::iterator end, 
			  MsgT *msg, 
			  ACE_Time_Value *timeout
			  ) 
  {
    internal_dispatch (reg,begin,end,msg,timeout,Int2Type<(int)DispatchPolicy::type==(int)STATELESS>());
  }

  };

};


#endif
