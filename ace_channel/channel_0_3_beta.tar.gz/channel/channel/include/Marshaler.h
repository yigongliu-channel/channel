////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _MARSHALER_H_
#define _MARSHALER_H_

//ACE headers
#include "ace/Thread_Mutex.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

#include <map>

#include <BaseDef.h>
#include <LinearIdTrait.h>
#include <HierarchicalIdTrait.h>

namespace channel {

  ///channel users should provide msg free callback
  typedef void (*MsgFreeCallback) (char * data);

  ///marshaling strategy objects
  class Marshaler {
  public:
    virtual int marshal(ACE_OutputCDR &cdr, const char *data, const int size) = 0;
    virtual int demarshal(ACE_InputCDR &cdr, char * &data, int &size, MsgFreeCallback &callback) = 0;
  };

  template <class> class PubSubMsg_Marshaler;
  class ChannelMsg_Marshaler;

  template <class IdType, class IdTrait>
  class MarshalerRegistry {
  private:
    //marshaler registration
    std::map<IdType, Marshaler *> mar_tbl_;
    ACE_Thread_Mutex mar_tbl_lock_;
  public:
    MarshalerRegistry () {
      //register marshaler for system internal msgs
      ChannelMsg_Marshaler *mar0 = new ChannelMsg_Marshaler();
      register_marshaler (IdTrait::CHANNEL_CONN_MSG, mar0);
      register_marshaler (IdTrait::CHANNEL_DISCONN_MSG, mar0);
            
      PubSubMsg_Marshaler<IdType> *mar1 = new PubSubMsg_Marshaler<IdType>();
      register_marshaler (IdTrait::INIT_SUBSCRIPTION_INFO_MSG, mar1);
      register_marshaler (IdTrait::INIT_PUBLICATION_INFO_MSG, mar1);
      register_marshaler (IdTrait::SUBSCRIPTION_INFO_MSG, mar1);
      register_marshaler (IdTrait::UNSUBSCRIPTION_INFO_MSG, mar1);
      register_marshaler (IdTrait::PUBLICATION_INFO_MSG, mar1);
      register_marshaler (IdTrait::UNPUBLICATION_INFO_MSG, mar1);
    }

    Status register_marshaler(IdType type, Marshaler *mar)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, mar_tbl_lock_, FAILURE);
	mar_tbl_[type] = mar;
	return SUCCESS;
      }

    Marshaler * get_marshaler(IdType type)
      {
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, mar_tbl_lock_, NULL);
	if (mar_tbl_.find(type) != mar_tbl_.end())
	  return mar_tbl_[type];
	else
	  return NULL;
      }

  };

};

#endif
