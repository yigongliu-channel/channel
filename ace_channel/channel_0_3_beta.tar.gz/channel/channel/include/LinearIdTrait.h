////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _LINEAR_IDTRAIT_H_
#define _LINEAR_IDTRAIT_H_

#include <sstream>
#include <string>
#include "ace/CDR_Stream.h"
#include <Channel_export.h>

/**
 * Here are the definitions related to channel ids:
 * 1> trait class for primitive id types: int, string,...
 * 2> definitions of non-primitive id types: struct id,... and their traits
 */

namespace channel {

  ///no default definition for id trait; must explicitly define it for each id type
  template <class IdType> class IdTrait;

  /// trait class for integer ids
  template <>
    class IdTrait<int> {
    public:
    ///define system msgs
    enum {
      ///--- sys msg starts at 1000 ---
      CHANNEL_CONN_MSG=1000,
      CHANNEL_DISCONN_MSG,
      INIT_SUBSCRIPTION_INFO_MSG,
      INIT_PUBLICATION_INFO_MSG,
      SUBSCRIPTION_INFO_MSG,
      UNSUBSCRIPTION_INFO_MSG,
      PUBLICATION_INFO_MSG,
      UNPUBLICATION_INFO_MSG,
      ///--- app msg starts at 2000 ---
      APP_MSG_BEGIN=2000
    };

    typedef int IdType;

    ///need the comparisons for msg matching and map
    static bool eq(const IdType &id1, const IdType &id2)
      { return id1 == id2; }
    static bool lt(const IdType &id1, const IdType &id2)
      { return id1 < id2; }

    //compiler doesnt allow references here
    //static bool match(const IdType &id1, const IdType &id2)
    static bool match(IdType id1, IdType id2)
      { return id1 == id2; }

    ///string representation of ids, for debugging
    static std::string idToString(const IdType &id) {
      std::ostringstream os;
      os << id;
      return os.str();
    }

    ///memory size the id will take
    static int size(const int &id2) {
      ACE_UNUSED_ARG(id2);
      return sizeof(int);
    }

    ///Id marshalling code; CDR...
    static int marshal(ACE_OutputCDR &cdr, const int &id)
      {
	cdr << ACE_CDR::Long(id);
	return cdr.good_bit();
      }
    static int demarshal(ACE_InputCDR &cdr, int &id)
      {
	ACE_CDR::Long d;
	cdr >> d;
	id = (int)d;
	return cdr.good_bit ();
      }
  };

  /// trait class for string ids
  template <>
    class Channel_Export IdTrait<std::string> {
    public:
    ///define system msgs

    static std::string CHANNEL_CONN_MSG;
    static std::string CHANNEL_DISCONN_MSG;
    static std::string INIT_SUBSCRIPTION_INFO_MSG;
    static std::string INIT_PUBLICATION_INFO_MSG;
    static std::string SUBSCRIPTION_INFO_MSG;
    static std::string UNSUBSCRIPTION_INFO_MSG;
    static std::string PUBLICATION_INFO_MSG;
    static std::string UNPUBLICATION_INFO_MSG;

    typedef std::string IdType;

    ///need the comparisons for msg matching and map
    static bool eq(const std::string &id1, const std::string &id2)
      { return id1 == id2; }
    static bool lt(const std::string &id1, const std::string &id2)
      { return id1 < id2; }

    //compiler doesnt allow references here
    //static bool match(const std::string &id1, const std::string &id2)
    static bool match(std::string id1, std::string id2)
      { return id1 == id2; }

    static std::string idToString(const std::string &id) {
      return id;
    }

    static int size(const std::string &id2) {
      return id2.length();
    }

    ///Id marshalling code; CDR...
    static int marshal(ACE_OutputCDR &cdr, const std::string &id)
      {
	int len = id.length()+1; //add 1 for '\0' added by c_str()
	cdr << ACE_CDR::Long (len);
	cdr.write_char_array(id.c_str(),len);
	return cdr.good_bit();
      }
    static int demarshal(ACE_InputCDR &cdr, std::string &id)
      {
	ACE_CDR::Long d;
	cdr >> d;
	char *data = new char[d];
	cdr.read_char_array(data, d);
	id = data;
	delete[] data;
	return cdr.good_bit();
      }
    
  };

  /**
   * definition of sample POD struct ids
   */
	///ids have 2 fields: family and type
	enum MessageFamily {
		SYSTEM_MESSAGE,
		APPLICATION_MESSAGE
	};

  struct StructId {
    MessageFamily family;
    int type;
    bool operator< (const StructId &id) const {
      if (family < id.family || (family == id.family && type < id.type))
	return true;
      return false;
    }
    bool operator== (const StructId &id) const {
      if (family == id.family && type == id.type)
	return true;
      return false;
    }
    bool operator!= (const StructId &id) const {
      if (family != id.family || type != id.type)
	return true;
      return false;
    }
  };

  /// trait class for sample POD struct ids
  template <>
    class Channel_Export IdTrait<StructId> {
    public:
    ///define system msgs

    static StructId CHANNEL_CONN_MSG;
    static StructId CHANNEL_DISCONN_MSG;
    static StructId INIT_SUBSCRIPTION_INFO_MSG;
    static StructId INIT_PUBLICATION_INFO_MSG;
    static StructId SUBSCRIPTION_INFO_MSG;
    static StructId UNSUBSCRIPTION_INFO_MSG;
    static StructId PUBLICATION_INFO_MSG;
    static StructId UNPUBLICATION_INFO_MSG;

    typedef StructId IdType;

    ///need the comparisons for msg matching and map
    static bool eq(const StructId &id1, const StructId &id2)
      { return id1 == id2; }
    static bool lt(const StructId &id1, const StructId &id2)
      { return id1 < id2; }

    //compiler doesnt allow references here
    //static bool match(const StructId &id1, const StructId &id2)
    static bool match(StructId id1, StructId id2)
      { return id1 == id2; }

    static std::string idToString(const StructId &id) {
      std::ostringstream os;
      os << "[Family:" << id.family << ", Type:" << id.type <<"]";
      return os.str();
    }

    static int size(const StructId &id2) {
      ACE_UNUSED_ARG(id2);
      return sizeof(StructId);
    }

    ///Id marshalling code; CDR...
    static int marshal(ACE_OutputCDR &cdr, const StructId &id)
      {
	cdr << ACE_CDR::Long (id.family);
	cdr << ACE_CDR::Long (id.type);
	return cdr.good_bit();
      }
    static int demarshal(ACE_InputCDR &cdr, StructId &id)
      {
	ACE_CDR::Long d;
	cdr >> d;
	id.family = (MessageFamily) d;
	cdr >> d;
	id.type = (int) d;
	return cdr.good_bit();
      }    
  };


};

#endif
