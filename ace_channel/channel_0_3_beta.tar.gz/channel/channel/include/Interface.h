////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * Interfaces are the ends of connections between channels:
 *       . child of both Source and Destination
 *	 . including :
 *	   . msgs pubed/sent by remote end
 *	   . msgs subed/recved by remote end
 *       . Translators:
 *	   . 2 functors: 
 *           . inward translator
 *           . outward translator to reverse translation
 *	   . always called for each msg passed
 *       . Filters:
 *	   . 2 functors:
 *	     . inward filter
 *	     . outward filter
 *	   . only called for sub/pub msgs
 *       . ptr to owner channel
 *       . ptr to peer:
 *	     . ptr to Link: remote chann
 *	     . ptr to Interface: in-proc channel connection
*/

#ifndef _INTERFACE_H_
#define _INTERFACE_H_

#include "ace/Message_Block.h"
#include "ace/Thread_Mutex.h"
#include "ace/Thread_Semaphore.h"
#include "ace/Log_Msg.h"
///for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

#include <vector>

#include <BaseDef.h>


namespace channel {

  class ConnInfo;
  template <class, class> class Out_Bound_Msg;

  ///parent class of all kinds of interfaces
  template <class Channel>
  class  Interface : public Channel::Destination, public Channel::Source {
  public:
    Interface (Channel *chan)  : 
      Channel::Destination(chan), Channel::Source(chan)
      {
	ch_ = chan;
	//subscribe to system msgs from local channel on behalf of the remote side
	//since CHANNEL_(DIS)CONN_MSG and INIT_SUB/PUB_INFO_MSG
	//are generated inside Interface, no need to subscribe to them in channels
	subscribe_msg(Channel::SUBSCRIPTION_INFO_MSG, SCOPE_LOCAL);
	subscribe_msg(Channel::UNSUBSCRIPTION_INFO_MSG, SCOPE_LOCAL);
	subscribe_msg(Channel::PUBLICATION_INFO_MSG, SCOPE_LOCAL);
	subscribe_msg(Channel::UNPUBLICATION_INFO_MSG, SCOPE_LOCAL);
	//publish system msgs at local channel on behalf of the remote side
	publish_msg(Channel::CHANNEL_CONN_MSG, SCOPE_LOCAL);
	publish_msg(Channel::CHANNEL_DISCONN_MSG, SCOPE_LOCAL);
	publish_msg(Channel::INIT_SUBSCRIPTION_INFO_MSG, SCOPE_LOCAL);
	publish_msg(Channel::INIT_PUBLICATION_INFO_MSG, SCOPE_LOCAL);
	publish_msg(Channel::SUBSCRIPTION_INFO_MSG, SCOPE_LOCAL);
	publish_msg(Channel::UNSUBSCRIPTION_INFO_MSG, SCOPE_LOCAL);
	publish_msg(Channel::PUBLICATION_INFO_MSG, SCOPE_LOCAL);
	publish_msg(Channel::UNPUBLICATION_INFO_MSG, SCOPE_LOCAL);
      }

    ~Interface () //unpub/unsub msgs
    {
      //detach from channel
      //why we need this->
      this->unsubscribe_all();
      this->unpublish_all();
    }

  public:

    Channel *ch_;
    //translators
    //filters
  };

  template <class, class> class Binder;
  template <class, class> class Filter;
  template <class, class> class Translator;

  ///LocalInterface: for connections to local/in-proc channels
  ///LocalInterface functions (interact with owner channel)
  ///as a proxy of remote peer channel
  template <class Channel>
  class  LocalInterface : public Interface<Channel> {
  public:
    typedef typename Channel::IdType IdType;
    typedef typename Channel::IdTrait IdTrait;
    typedef typename Channel::Msg Msg;
    typedef typename Channel::Source Source;
    typedef typename Channel::Destination Destination;
    typedef typename Channel::Channel_Info_Msg Channel_Info_Msg;
    typedef typename Channel::PubSub_Info_Msg PubSub_Info_Msg;
    typedef Binder<typename Channel::IdType, typename Channel::IdTrait> Binder;
    typedef Filter<typename Channel::IdType, typename Channel::IdTrait> Filter;
    typedef Translator<typename Channel::IdType, typename Channel::IdTrait> Translator;

    LocalInterface (Channel *chan, Binder *binder) : Interface<Channel>(chan) {
      if (binder == NULL) {
	filter_ = NULL;
	translator_ = NULL;
      } else {
	filter_ = binder->filter;
	translator_ = binder->translator;
      }
    };

    ///implement Destination (of owner channel) methods
    ///forward msgs from owner channel to remote peer
    Member_Type type() { return MEMBER_REMOTE;}
    Status put_msg(Msg *msg, ACE_Time_Value *timeout=NULL)
      {
	ACE_DEBUG ((LM_DEBUG, "LocalInterface::put_msg: recv MSG [%s]...\n", ID2STR(msg->type).c_str()));
	if (peer_interface_ != NULL) {
	  //translate it if set
	  if (translator_ != NULL &&
	      msg->type != Channel::CHANNEL_CONN_MSG &&
	      msg->type != Channel::CHANNEL_DISCONN_MSG &&
	      msg->type != Channel::INIT_SUBSCRIPTION_INFO_MSG &&
	      msg->type != Channel::INIT_PUBLICATION_INFO_MSG &&
	      msg->type != Channel::SUBSCRIPTION_INFO_MSG &&
	      msg->type != Channel::UNSUBSCRIPTION_INFO_MSG &&
	      msg->type != Channel::PUBLICATION_INFO_MSG &&
	      msg->type != Channel::UNPUBLICATION_INFO_MSG 
	      ) {
	    translator_->translate_outward(msg->type);
	  }

	  return peer_interface_->send_msg(msg, timeout);
	}
	return SUCCESS;
      }

    ///implement Source (of owner channel) methods
    ///allow remote peer send msgs to owner channel
    Status send_msg(Msg *msg, ACE_Time_Value *timeout=0)
      {
	ACE_DEBUG ((LM_DEBUG, "LocalInterface::send_msg: recv MSG [%s]...\n", ID2STR(msg->type).c_str()));
	PubSub_Info_Msg *subinfo;

	if (msg->type == Channel::CHANNEL_CONN_MSG || 
	    msg->type == Channel::CHANNEL_DISCONN_MSG) {
	  ///do nothing
	}
	else if (msg->type == Channel::SUBSCRIPTION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "LocalInterface::send_msg recv SUBSCRIPTION_INFO_MSG...\n"));
	  subinfo = (PubSub_Info_Msg *)msg->data();
	  Destination *dest = (Destination *) this;
	  std::vector<IdType> global_msgs;
	  ///Q: why need this->
	  this->ch_->published_global_msgs (global_msgs);
	  for(int i=0; i<subinfo->num_msg_types; i++) {
	    if (filter_ != NULL && filter_->block_outward((IdType)subinfo->msg_types[i]))
	      continue;
	    if (dest->scope(subinfo->msg_types[i]) == SCOPE_UNDEFINED) {
	      if(std::find_if(global_msgs.begin(), global_msgs.end(), 
			      std::bind2nd(std::ptr_fun(IdTrait::match),(IdType)subinfo->msg_types[i])) != 
		 global_msgs.end()) {
		ACE_DEBUG ((LM_DEBUG, "remote subsc to [%s]\n",ID2STR(subinfo->msg_types[i]).c_str()));
		subscribe_msg((IdType)subinfo->msg_types[i], SCOPE_LOCAL);
		peer_interface_->publish_msg ((IdType)subinfo->msg_types[i], SCOPE_LOCAL);
	      }
	    }
	  }
	} 
	else if (msg->type == Channel::UNSUBSCRIPTION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "LocalInterface::send_msg recv UNSUBSCRIPTION_INFO_MSG...\n"));
	  subinfo = (PubSub_Info_Msg *)msg->data();
	  for(int i=0; i<subinfo->num_msg_types; i++)
	    unsubscribe_msg((IdType)subinfo->msg_types[i]);
	} 
	else if (msg->type == Channel::PUBLICATION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "LocalInterface::send_msg recv PUBSCRIPTION_INFO_MSG...\n"));
	  PubSub_Info_Msg *pubinfo = (PubSub_Info_Msg *)msg->data();
	  Source *src = (Source *) this;
	  std::vector<IdType> mtypes;
	  ///Q: why this->
	  this->ch_->subscribed_global_msgs(mtypes);
	  for(int i=0; i<pubinfo->num_msg_types; i++) {
	    if (filter_ != NULL && filter_->block_inward((IdType)pubinfo->msg_types[i]))
	      continue;
	    if (src->scope (pubinfo->msg_types[i]) == SCOPE_UNDEFINED) {
	      if(std::find_if(mtypes.begin(), mtypes.end(), 
			      std::bind2nd(std::ptr_fun(IdTrait::match), (IdType)pubinfo->msg_types[i])) != 
		 mtypes.end()) {
		ACE_DEBUG ((LM_DEBUG, "remote pub msg [%s]\n",ID2STR(pubinfo->msg_types[i]).c_str()));
		///remote msgs only for local destinations
		publish_msg ((IdType)pubinfo->msg_types[i], SCOPE_LOCAL);
		peer_interface_->subscribe_msg((IdType)pubinfo->msg_types[i], SCOPE_LOCAL);
	      }
	    }
	  }
	}
	else if (msg->type == Channel::UNPUBLICATION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "LocalInterface::send_msg recv UNPUBSCRIPTION_INFO_MSG...\n"));
	} 
	else {
	  ///application msgs go to Channel
	  //application msgs go to Channel
	  //translate it if set
	  if (translator_ != NULL) {
	    translator_->translate_inward(msg->type);
	  }
	  ACE_DEBUG ((LM_DEBUG, "LocalInterface::send_msg forward an application msg [%s] to a local chan\n", ID2STR(msg->type).c_str()));
	}
	///forward all msgs to owner channels
	Source::send_msg (msg, timeout);
	return SUCCESS;
      }

    ///my peer, the interface at the other end of connection to a local peer channel
    LocalInterface *peer_interface_;
    ///filter & translators: policies for remote connections
    Filter *filter_;
    Translator *translator_;
  };

  template <class, class> class Connector;
  template <class, class> class ConnHandler;
#if !defined (ACE_WIN32)
  template <class> class UnixSockTransport;
#endif
  template <class> class TcpSockTransport;

  ///RemoteInterface: for connection to remote channels
  ///interact with owner channel as proxy of remote peer channel
  template <class Channel, class Transport>
  class RemoteInterface : public Interface<Channel> {
  public:
    typedef typename Channel::IdType IdType;
    typedef typename Channel::IdTrait IdTrait;
    typedef typename Channel::Msg Msg;
    typedef typename Channel::Source Source;
    typedef typename Channel::Destination Destination;
    typedef typename Channel::Channel_Info_Msg Channel_Info_Msg;
    typedef typename Channel::PubSub_Info_Msg PubSub_Info_Msg;
    typedef ConnHandler<Channel, Transport> ConnHandler;
#if !defined (ACE_WIN32)
    typedef Connector<Channel, UnixSockTransport<Channel> > UnixSockConnector;
#endif
	typedef Connector<Channel, TcpSockTransport<Channel> > TcpSockConnector;
    typedef Connector<Channel, Transport> Connector;
    typedef Binder<typename Channel::IdType, typename Channel::IdTrait> Binder;
    typedef Filter<typename Channel::IdType, typename Channel::IdTrait> Filter;
    typedef Translator<typename Channel::IdType, typename Channel::IdTrait> Translator;

  private:
    ///my peer, a connection to remote channel
    ConnHandler *conn_handler_;
    ///msg buffering when connection to remote peer is not ready yet
    std::vector<Msg *> pending_msgs_;
    ///filter & translators: policies for remote connections
    Filter *filter_;
    Translator *translator_;

  public:
    void dump(void);

    RemoteInterface(ConnHandler *st, Interface_Role r, Channel *c)
      : Interface<Channel>(c) {
      state_ = CONN_INIT;
      conn_handler_ = st;
      st->intf_ = this;
      role_ = r;
      //check if any binder<filter,tranlator> specified for this remote peer
      Binder *binder = conn_handler_->cm_->get_binder(conn_handler_->rmt_addr_);
      if (binder == NULL) {
	filter_ = NULL;
	translator_ = NULL;
      } else {
	filter_ = binder->filter;
	translator_ = binder->translator;
      }
    }

    ~RemoteInterface() {}
    ConnHandler *conn_handler(void) { return conn_handler_; }
    void conn_handler(ConnHandler *ch) { conn_handler_=ch; }

    Interface_Role role(void) { return role_;}
    void role(Interface_Role r) { role_ = r;}

    /**
     * methods handling msg buffering before remote connection is ready
     */
    void add_pending_msg(Msg *m) { pending_msgs_.push_back(m);}
    void resend_pending_msgs(void)
      {
	if (conn_handler_ != NULL) {
	  for(size_t i=0; i<pending_msgs_.size();i++) {
	    put_msg(pending_msgs_[i]);
	    ACE_DEBUG ((LM_DEBUG, "...resend 1 msg[%s]\n", ID2STR(pending_msgs_[i]->type).c_str()));
	  }
	  pending_msgs_.clear();
	}
      }

    ///when the owner/local channel makes an active connection to
    ///remote channels, when socket connection call comes back 
    ///successfully, fake a Channel_Info_Msg to tell owner channel
    ///member that a remote connection is ready (or connects in)
    ///fix me: need a better solution
    Status notify_connected (ConnInfo addr)
      {
	ACE_DEBUG ((LM_DEBUG, "notify local members remote connection complete...\n"));
	if (addr.valid()) {
	  Channel_Info_Msg *msg = new Channel_Info_Msg();
	  msg->conn_type = addr.type();
	  switch (addr.type()) {
	  case UNIX_SOCK:
	    {
	      strcpy(msg->unix_addr, addr.unix_addr().c_str());
	    }
	    break;
	  case INET_SOCK:
	    {
	      strcpy(msg->host_addr, addr.ip().c_str());
	      msg->port = addr.port();
	    }
	    break;
	  }
	  Msg *m = new Msg(Channel::CHANNEL_CONN_MSG, msg);
	  send_msg(m);
	}
	return SUCCESS;
      }
    
    /// main function to process remote msgs:
    /// 1> remote channel connect / disconnect
    /// 2> publish/unpublish, subscribe/unsubscribe
    /// 3> application msgs
    Status handle_message(Msg *msg)
      {
	ConnInfo addr;
	PubSub_Info_Msg *subinfo;
	Channel_Info_Msg *chaninfo;

	ACE_DEBUG ((LM_DEBUG, "recv MSG [%s] from sock...\n", ID2STR(msg->type).c_str()));

	///handle msgs
	///Channel internal management msgs
	if(msg->type == Channel::CHANNEL_CONN_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "recv CHANNEL_CONN_MSG...\n"));
	  chaninfo = (Channel_Info_Msg *)msg->data();
	  switch(role()) {
	  case ACTIVE_ROLE:
	    ACE_DEBUG ((LM_DEBUG, "i am active end of connection...\n"));
	    ACE_DEBUG ((LM_DEBUG, "should not recv Channel_Info_Msg, dropped ...\n"));
	    break;
	  case PASSIVE_ROLE:
	    ACE_DEBUG ((LM_DEBUG, "I am passive...\n"));
	    switch((Interface_Type) chaninfo->conn_type) {
	    case INET_SOCK:
	      addr.set(chaninfo->host_addr, chaninfo->port);
	      break;
	    case UNIX_SOCK:
	      addr.set(chaninfo->unix_addr);
	      break;
	    default:
	      ACE_DEBUG ((LM_DEBUG, "Invalid connection type...\n"));
	    }
      
	    conn_handler_->rmt_addr_ = addr;
	    if(conn_handler_->cm_->add_conn(addr,conn_handler_) == FAILURE)
	      return FAILURE;

	    ///add interface(myself) to msg
	    chaninfo->is_local = false;
	    chaninfo->intf = this;

	    ///send my subscription info
	    send2remote_init_subscribe_msg();
	    break;
	  default:
	    break;
	  }
	}
	else if(msg->type == Channel::CHANNEL_DISCONN_MSG) {
	}
	else if (msg->type == Channel::INIT_SUBSCRIPTION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "recv INIT_SUBSCRIPTION_INFO_MSG...\n"));
	  subinfo = (PubSub_Info_Msg *)msg->data();
	  std::vector<IdType> pub_msgs;
	  ///Q: why this->
	  this->ch_->published_global_msgs (pub_msgs);
	  for(int i=0; i<subinfo->num_msg_types; i++) {
	    if (filter_ != NULL && filter_->block_outward((IdType)subinfo->msg_types[i]))
	      continue;
	    if(std::find_if(pub_msgs.begin(), pub_msgs.end(), 
			    std::bind2nd(std::ptr_fun(IdTrait::match), (IdType)subinfo->msg_types[i])) != 
	       pub_msgs.end()) {
	      ACE_DEBUG ((LM_DEBUG, "remote subsc to [%s]\n",ID2STR(subinfo->msg_types[i]).c_str()));
	      subscribe_msg((IdType)subinfo->msg_types[i], SCOPE_LOCAL);
	      send2remote_pubsub_msg (OPER_PUBLISH, (IdType)subinfo->msg_types[i]);
	    }
	
	  }
	  if(role() == ACTIVE_ROLE) {     
	    ///send my subscription info
	    send2remote_init_subscribe_msg();	
	  } 
	  {
	    ACE_DEBUG ((LM_DEBUG, "conn active now...\n"));
	    ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, lock_, FAILURE);
	    state_ = CONN_ACTIVE;
	    resend_pending_msgs();
	  }
	}
	///no need for init_pub_info msgs, since they are all handled inside
	else if (msg->type == Channel::INIT_PUBLICATION_INFO_MSG) {
	}
	///init_sub_msgs
	else if (msg->type == Channel::SUBSCRIPTION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "recv SUBSCRIPTION_INFO_MSG...\n"));
	  subinfo = (PubSub_Info_Msg *)msg->data();
	  Destination *dest = (Destination *) this;
	  std::vector<IdType> global_msgs;
	  ///Q: why this->
	  this->ch_->published_global_msgs (global_msgs);
	  for(int i=0; i<subinfo->num_msg_types; i++) {
	    if (filter_ != NULL && filter_->block_outward((IdType)subinfo->msg_types[i]))
	      continue;
	    if (dest->scope(subinfo->msg_types[i]) == SCOPE_UNDEFINED) {
	      if(std::find_if(global_msgs.begin(), global_msgs.end(), 
			      std::bind2nd(std::ptr_fun(IdTrait::match), (IdType)subinfo->msg_types[i])) != 
		 global_msgs.end()) {
		ACE_DEBUG ((LM_DEBUG, "remote subsc to [%s]\n",ID2STR(subinfo->msg_types[i]).c_str()));
		subscribe_msg((IdType)subinfo->msg_types[i], SCOPE_LOCAL);
		send2remote_pubsub_msg (OPER_PUBLISH, (IdType)subinfo->msg_types[i]);
	      }
	    }
	  }
	}
	else if (msg->type == Channel::UNSUBSCRIPTION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "recv UNSUBSCRIPTION_INFO_MSG...\n"));
	  subinfo = (PubSub_Info_Msg *)msg->data();
	  for(int i=0; i<subinfo->num_msg_types; i++)
	    unsubscribe_msg((IdType)subinfo->msg_types[i]);
	}
	else if (msg->type == Channel::PUBLICATION_INFO_MSG) {
	  ACE_DEBUG ((LM_DEBUG, "recv PUBLICAION_INFO_MSG...\n"));
	  PubSub_Info_Msg *pubinfo = (PubSub_Info_Msg *)msg->data();
	  Source *src = (Source *) this;
	  std::vector<IdType> mtypes;
	  ///Q: why this->
	  this->ch_->subscribed_global_msgs(mtypes);
	  for(int i=0; i<pubinfo->num_msg_types; i++) {
	    if (filter_ != NULL && filter_->block_inward((IdType)pubinfo->msg_types[i]))
	      continue;
	    if (src->scope (pubinfo->msg_types[i]) == SCOPE_UNDEFINED) {
	      if(std::find_if(mtypes.begin(), mtypes.end(), 
			      std::bind2nd(std::ptr_fun(IdTrait::match),(IdType)pubinfo->msg_types[i])) != 
		 mtypes.end()) {
		ACE_DEBUG ((LM_DEBUG, "remote pub msg [%s]\n",ID2STR(pubinfo->msg_types[i]).c_str()));
		///remote msgs only for local destinations
		publish_msg ((IdType)pubinfo->msg_types[i], SCOPE_LOCAL);
		send2remote_pubsub_msg(OPER_SUBSCRIBE, (IdType)pubinfo->msg_types[i]);
	      }
	    }
	  }
	}
	else if (msg->type == Channel::UNPUBLICATION_INFO_MSG) {
	} 
	else {
	  //application msgs go to Channel
	  //translate it if set
	  if (translator_ != NULL) {
	    translator_->translate_inward(msg->type);
	  }
	  ACE_DEBUG ((LM_DEBUG, "recv an application msg [%s] from sock and sent to local\n", ID2STR(msg->type).c_str()));
	}

	///forward all msgs to local channel
	send_msg (msg);
	return SUCCESS;
      }

    ///send owner channel info to remote
    Status send2remote_chan_info(Interface_Type ct)
      {
	ACE_DEBUG ((LM_DEBUG, "send_chan_info_to_remote...\n"));
	Channel_Info_Msg *msg = new Channel_Info_Msg();
	msg->conn_type = ct;
	Connector *cm_ = conn_handler_->cm_;
	switch (ct) {
#if !defined (ACE_WIN32)
	case UNIX_SOCK:
	  {
	    UnixSockConnector *unix_cm_ = (UnixSockConnector *)cm_;
	    strcpy(msg->unix_addr, unix_cm_->unix_addr().c_str());
	  }
	  break;
#endif
	case INET_SOCK:
	  {
	    TcpSockConnector *tcp_cm_ = (TcpSockConnector *)cm_;
	    strcpy(msg->host_addr, tcp_cm_->host_addr().c_str());
	    msg->port = tcp_cm_->port();
	  }
	  break;
	}
	Msg *m = new Msg(Channel::CHANNEL_CONN_MSG, msg);
	return put_msg(m);
      }

    ///when 2 channels just connected, send all current sub info
    ///to remote
    Status send2remote_init_subscribe_msg(void)
      {
	///send subscription msg
	PubSub_Info_Msg *sub = new PubSub_Info_Msg();
	std::vector<IdType> mtypes;
	///Q: why this->
	this->ch_->subscribed_global_msgs(mtypes);
	sub->num_msg_types = mtypes.size();
	for(int i=0; i<sub->num_msg_types; i++) {
	  if (filter_ != NULL && filter_->block_inward(mtypes[i]))
	    continue;
	  sub->msg_types[i] = mtypes[i];
	}
	ACE_DEBUG ((LM_DEBUG, "send init_subscription info...\n")); 
	Msg *m = new Msg(Channel::INIT_SUBSCRIPTION_INFO_MSG, sub);
	put_msg(m);
	return SUCCESS;
      }

    ///when 2 channels just connected, send all current pub info
    ///to remote
    Status send2remote_init_publish_msg(void)
      {
	///send subscription msg
	PubSub_Info_Msg *pub = new PubSub_Info_Msg();
	std::vector<IdType> mtypes;
	///Q: why this->
	this->ch_->published_global_msgs(mtypes);
	pub->num_msg_types = mtypes.size();
	for(int i=0; i<pub->num_msg_types; i++) {
	  if (filter_ != NULL && filter_->block_outward(mtypes[i]))
	    continue;
	  pub->msg_types[i] = mtypes[i];
	}
	ACE_DEBUG ((LM_DEBUG, "send init_publication info...\n")); 
	Msg *m = new Msg(Channel::INIT_PUBLICATION_INFO_MSG, pub);
	put_msg(m);
	return SUCCESS;
      }

    ///forward local/owner channel memebers' pub/sub operations to remote
    Status send2remote_pubsub_msg(Oper_Type op, IdType t)
      {
	PubSub_Info_Msg *sub = new PubSub_Info_Msg();
	sub->num_msg_types = 1;
	sub->msg_types[0] = t;
	IdType mt;
	switch(op) {
	case OPER_PUBLISH:
	  if (filter_ != NULL && filter_->block_outward(t)) {
	    delete sub;
	    return SUCCESS;
	  }
	  mt = Channel::PUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "RemoteInterface::send2remote_pubsub_msg publish "));
	  break;
	case OPER_UNPUBLISH:
	  mt = Channel::UNPUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "RemoteInterface::send2remote_pubsub_msg unpublish "));
	  break;
	case OPER_SUBSCRIBE:
	  if (filter_ != NULL && filter_->block_inward(t)) {
	    delete sub;
	    return SUCCESS;
	  }
	  mt = Channel::SUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "RemoteInterface::send2remote_pubsub_msg subscribe "));
	  break;
	case OPER_UNSUBSCRIBE:
	  mt = Channel::UNSUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "RemoteInterface::send2remote_pubsub_msg unsubscribe "));
	  break;
	default:
	  ACE_DEBUG((LM_DEBUG, "MapRouter:::propagate_change_to_neighbors invalid IdType "));
	  delete sub;
	  return SUCCESS;
	}
	Msg *m = new Msg(mt, sub);
	put_msg(m);
	return SUCCESS;
      }

    ///implement Destination methods
    Member_Type type() { return MEMBER_REMOTE;}
    ///implement Destination (of owner channel) methods
    ///forward msgs from owner channel to remote peer
    Status put_msg(Msg *msg, ACE_Time_Value *timeout=NULL)
      {
	ACE_DEBUG ((LM_DEBUG, "RemoteInterface<Channel>::put_msg send 2 remote...\n"));
	if(conn_handler_!=NULL) {
	  if(state_ != CONN_ACTIVE && 
	     msg->type != Channel::CHANNEL_CONN_MSG && 
	     msg->type != Channel::INIT_SUBSCRIPTION_INFO_MSG &&
	     msg->type != Channel::INIT_PUBLICATION_INFO_MSG ) {
	    ACE_GUARD_REACTION(ACE_Thread_Mutex, guard, lock_, ACE_DEBUG ((LM_DEBUG, "failed to lock out-sock\n")); delete msg; return FAILURE);
	    add_pending_msg(msg);
	    ACE_DEBUG ((LM_DEBUG, "... msgs[%s] buffered \n", ID2STR(msg->type).c_str()));
	  } else {
	    ACE_Message_Block *payload;
	    Out_Bound_Msg<Channel, ConnHandler> *out_msg;
  
	    //translate it if set
	    if (translator_ != NULL &&
		msg->type != Channel::CHANNEL_CONN_MSG &&
		msg->type != Channel::CHANNEL_DISCONN_MSG &&
		msg->type != Channel::INIT_SUBSCRIPTION_INFO_MSG &&
		msg->type != Channel::INIT_PUBLICATION_INFO_MSG &&
		msg->type != Channel::SUBSCRIPTION_INFO_MSG &&
		msg->type != Channel::UNSUBSCRIPTION_INFO_MSG &&
		msg->type != Channel::PUBLICATION_INFO_MSG &&
		msg->type != Channel::UNPUBLICATION_INFO_MSG 
		) {
	      translator_->translate_outward(msg->type);
	    }
	    out_msg = new Out_Bound_Msg<Channel, ConnHandler>(msg, conn_handler_);
	    ///note: the msg_block don't own this out_msg (since it is not created
	    ///by this mblk; we have to delete it explicitly in OutputMgr::send()
	    payload = new ACE_Message_Block((const char*)out_msg, sizeof(Out_Bound_Msg<Channel, ConnHandler>));
	    payload->wr_ptr(sizeof(Out_Bound_Msg<Channel, ConnHandler>)); 
	    ///must be before put(), otherwise it could be deleted
	    ACE_DEBUG ((LM_DEBUG, "... msgs[%s] sent \n", ID2STR(msg->type).c_str()));
	    conn_handler_->cm_->output_mgr_.put(payload,timeout);
	  }
	} else {
	  delete msg;
	  return FAILURE;
	}
	return SUCCESS;
      }

  public:
    Interface_Role role_;  ///am i active or passive
    Interface_State state_;
    ACE_Thread_Mutex lock_;///No more than 2 threads can write to the connection at the same time
  };


};


#endif
