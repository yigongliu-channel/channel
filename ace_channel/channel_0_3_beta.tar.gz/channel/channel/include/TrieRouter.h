////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

/**
 * A sample hierarchical router based on trie data structure
 */

#ifndef _TRIE_ROUTER_H_
#define _TRIE_ROUTER_H_

//ACE headers
#include "ace/Log_Msg.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

//std
#include <map>
#include <list>
#include <vector>
#include <string>
#include <algorithm>

//Channel
#include <BaseDef.h>
#include <RouterBase.h>
#include <Msg.h>
#include <TemplateUtils.h>

namespace channel {

  template <class, class, class, class, class> class Channel;

  /**
   *     HierarchicalRouter:
   *     using trie as routing data structure
   *     using pathname matching
   */  
  template <class IdType, class IdTrait, class SynchPolicy, class Dispatch_Policy>
  class TrieRouter : public RouterBase {
  public:
    enum { NamespaceType = NAMESPACE_HIERARCHICAL };

  private:
    typedef Channel<IdType, IdTrait, SynchPolicy, Dispatch_Policy, TrieRouter<IdType, IdTrait, SynchPolicy, Dispatch_Policy> > Channel;
    typedef Destination<Channel, NamespaceType> DestinationType;
    typedef Source<Channel, NamespaceType> SourceType;
    //cannot use Channel::Msg here, since Channel is not defined yet
    //Channel is defined using Router
    typedef Msg<IdType, SynchPolicy> MsgT;
    typedef PubSub_Info_Msg<IdType> PubSub_Info_MsgT;
    typedef typename IdTrait::NameType NameType;

  public:
    typedef Dispatch_Policy DispatchPolicy;

  private:

    struct Pub_Registry {
      std::list<SourceType *> *pubers_;
      std::list<SourceType *> *w_pubers_;
      typename SynchPolicy::RW_MUTEX pubers_lock_;
      Pub_Registry() {
	pubers_ = NULL;
	w_pubers_ = NULL;
      }
      ~Pub_Registry() {
	ACE_WRITE_GUARD(typename SynchPolicy::RW_MUTEX, guard, pubers_lock_);
	if (pubers_ != NULL) {
	  delete pubers_;
	}
	if (w_pubers_ != NULL) {
	  delete w_pubers_;
	}
      }
    };
    struct Sub_Registry {
      std::map<DestinationType *, PubSub_Scope> *subers_;
      std::map<DestinationType *, PubSub_Scope> *w_subers_;
      typename SynchPolicy::RW_MUTEX subers_lock_;
      Sub_Registry() {
	subers_ = NULL;
	w_subers_ = NULL;
      }
      ~Sub_Registry() {
	ACE_WRITE_GUARD(typename SynchPolicy::RW_MUTEX, guard, subers_lock_);
	if (subers_ != NULL) {
	  delete subers_;
	}
	if (w_subers_ != NULL) {
	  delete w_subers_;
	}
      }
    };

    template <class Registry>
    struct TrieNode {
      NameType name;
      TrieNode *parent;
      std::map<NameType, TrieNode *> children;
      typename SynchPolicy::RW_MUTEX children_lock_;
      Registry registry;
      TrieNode(NameType n, TrieNode *p) : name(n), parent(p) {
      }
      ~TrieNode() {
	ACE_WRITE_GUARD(typename SynchPolicy::RW_MUTEX, guard, children_lock_);
	for(typename std::map<NameType, TrieNode *>::iterator iter = children.begin();
	    iter != children.end(); iter++) {
	  if (iter->second != NULL)
	    delete iter->second;
	}
      }
    };

    //namespace - pub/sub info indexed by IdType
    TrieNode<Sub_Registry> *sub_trie_root_;
    TrieNode<Pub_Registry> *pub_trie_root_;
 
    //dispatcher :
    typename IF<(int)Dispatch_Policy::type==(int)STATELESS, 
                Dispatch_Policy, 
                std::map<IdType, Dispatch_Policy> >::RET dispatcher_;

    typedef std::vector<DestinationType*> DispatchContainer;

  public:

    TrieRouter() {
      sub_trie_root_ = new TrieNode<Sub_Registry>(IdTrait::RootName, NULL);
      pub_trie_root_ = new TrieNode<Pub_Registry>(IdTrait::RootName, NULL);
    }

    ~TrieRouter() {
      delete sub_trie_root_;
      delete pub_trie_root_;
    }

    void propagate_child_pub_registry (IdType t, TrieNode<Pub_Registry> *node, Oper_Type oper) {
      Pub_Registry *reg = &(node->registry);
      //if encounter wildcard, stop going deeper
      {
	ACE_READ_GUARD(typename SynchPolicy::RW_MUTEX, guard, reg->pubers_lock_);
	if (reg->w_pubers_ != NULL && !reg->w_pubers_->empty()) {
	  t.push_back(IdTrait::WildcardName);
	  propagate_change_to_neighbors(oper, t);
	  t.pop_back();
	  return;
	}
	if (reg->pubers_ != NULL && !reg->pubers_->empty()) {
	  propagate_change_to_neighbors(oper, t);
	}
      }
      //recursively update children
      ACE_READ_GUARD(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_);
      for(typename std::map<NameType, TrieNode<Pub_Registry> *>::iterator iter = node->children.begin();
	  iter != node->children.end(); iter++) {
	t.push_back(iter->first);
	propagate_child_pub_registry (t, iter->second, oper);
	t.pop_back();
      }
    };


    void propagate_child_sub_registry (IdType t, TrieNode<Sub_Registry> *node, Oper_Type oper) {
      bool send2remote = false;
      Sub_Registry *reg = &(node->registry);
      //if encounter wildcard, stop going deeper
      {
	ACE_READ_GUARD(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_);
	if (reg->w_subers_ != NULL && !reg->w_subers_->empty()) {
	  for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
	      iter != reg->w_subers_->end() && !send2remote; iter++)
	    if (iter->first->type() == MEMBER_LOCAL && 
		(iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
	      send2remote = true;
	  if (send2remote) {
	    t.push_back(IdTrait::WildcardName);
	    propagate_change_to_neighbors(oper, t);
	    t.pop_back();
	    return;
	  }
	}
	if (reg->subers_ != NULL && !reg->subers_->empty()) {
	  for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->subers_->begin();
	      iter != reg->subers_->end() && !send2remote; iter++)
	    if (iter->first->type() == MEMBER_LOCAL &&
		(iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
	      send2remote = true;
	  if(send2remote)
	    propagate_change_to_neighbors(oper, t);
	}
      }
      //recursively update children
      ACE_READ_GUARD(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_);
      for(typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.begin();
	  iter != node->children.end(); iter++) {
	t.push_back(iter->first);
	propagate_child_sub_registry (t, iter->second, oper);
	t.pop_back();
      }
    };


    /**
     * 1. Local operations on Channel/Router namespace:
     *    pub/unpub, sub/unsub
     */
    /// publish 
    Status publish_msg(IdType t, PubSub_Scope c, SourceType *src)
      {
	bool send2remote = false;
	Pub_Registry *reg = NULL;
	TrieNode<Pub_Registry> *node = pub_trie_root_;
	bool wildcard = false;
	bool hidden = false;
	int sz = t.size();

	if (!(c == SCOPE_REMOTE || c == SCOPE_GLOBAL)) 
	  return SUCCESS;

	/**
	 * traverse to node designated by t
	 */
	for (int i=0; i<sz; i++) {
	  if (t[i] == IdTrait::WildcardName) {
	    if (i == (sz-1)) {
	      wildcard = true;
	      break;
	    } else {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unpublish_msg: Wildcard in middle [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	  }
	  //check if it is hidden
	  if (!hidden) {
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.pubers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_pubers_ != NULL && !reg->w_pubers_->empty()) 
	      hidden = true;
	  }
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	  typename std::map<NameType, TrieNode<Pub_Registry> *>::iterator iter = node->children.find(t[i]);
	  if (iter == node->children.end()) {
	    TrieNode<Pub_Registry> *cnd = new TrieNode<Pub_Registry> (t[i], node);
	    node->children[t[i]] = cnd;
	    node = cnd;
	  } 
	  else
	    node = iter->second;
	}

	//update pub registry
	if (!wildcard) {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.pubers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->pubers_ == NULL) {
	      reg->pubers_ = new std::list<SourceType *>();
	      send2remote = true;
	    }
	    reg->pubers_->push_back(src);
	  }
	  //broadcast t to remote
	  if (send2remote && !hidden && src->type() == MEMBER_LOCAL)
	    propagate_change_to_neighbors(OPER_PUBLISH, t);
	}
	/**
	 * if t[level] = *, add src & st -> node.registry->w_pubers, 
	 * if scope_state is active, deactivate children for src, return;
	 */
	else {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.pubers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_pubers_ == NULL) {
	      reg->w_pubers_ = new std::list<SourceType *>();
	      send2remote = true;
	    }
	    reg->w_pubers_->push_back(src);
	  }
	  if (send2remote && !hidden && src->type() == MEMBER_LOCAL) {
	    //unpublish child registry
	    IdType id = t;
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	    for(typename std::map<NameType, TrieNode<Pub_Registry> *>::iterator iter = node->children.begin();
		iter != node->children.end(); iter++) {
	      id[sz-1] = iter->first;
	      propagate_child_pub_registry (id, iter->second, OPER_UNPUBLISH);
	    }
	    //broadcast t to remote
	    propagate_change_to_neighbors(OPER_PUBLISH, t);
	  }
	}
	return SUCCESS;
      }

    ///unpublish
    Status unpublish_msg(IdType t, PubSub_Scope s, SourceType *src)
      {
	bool send2remote = false;
	Pub_Registry *reg = NULL;
	TrieNode<Pub_Registry> *node = pub_trie_root_;
	bool wildcard = false;
	bool hidden = false;
	int sz = t.size();

	if (!(s == SCOPE_REMOTE || s == SCOPE_GLOBAL)) 
	  return SUCCESS;

	/**
	 * traverse to node designated by t
	 */
	for (int i=0; i<sz; i++) {
	  if (t[i] == IdTrait::WildcardName) {
	    if (i == (sz-1)) {
	      wildcard = true;
	      break;
	    } else {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unpublish_msg: Wildcard in middle [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	  }
	  //check if it is hidden
	  if (!hidden) {
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.pubers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_pubers_ != NULL && !reg->w_pubers_->empty()) 
	      hidden = true;
	  }
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	  typename std::map<NameType, TrieNode<Pub_Registry> *>::iterator iter = node->children.find(t[i]);
	  if (iter == node->children.end()) {
	    ACE_DEBUG((LM_DEBUG, "TrieRouter::unpublish_msg: not found [%s]\n",ID2STR(t).c_str()));
	    return FAILURE;
	  }
	  node = iter->second;
	}
	if (!wildcard) {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.pubers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->pubers_ == NULL) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unpublish_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    typename std::list<SourceType *>::iterator iter = std::find(reg->pubers_->begin(),
		 reg->pubers_->end(), src);
	    if (iter == reg->pubers_->end()) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unpublish_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    reg->pubers_->erase(iter);
	    if (reg->pubers_->empty()) {
	      send2remote = true;
	    }
	  }
	  //broadcast t to remote
	  if (send2remote && !hidden && src->type() == MEMBER_LOCAL)
	    propagate_change_to_neighbors(OPER_UNPUBLISH, t);
	}
	/**
	 * if t[level] = *
	 */
	else {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.pubers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_pubers_ == NULL) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unpublish_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    typename std::list<SourceType *>::iterator iter = std::find(reg->w_pubers_->begin(),
		 reg->w_pubers_->end(), src);
	    if (iter == reg->w_pubers_->end()) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unpublish_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    reg->w_pubers_->erase(iter);
	    if (reg->w_pubers_->empty()) {
	      send2remote = true;
	    }
	  }
	  //
	  if (send2remote && !hidden && src->type() == MEMBER_LOCAL) {
	    //broadcast t to remote
	    propagate_change_to_neighbors(OPER_UNPUBLISH, t);
	    //publish child registry
	    IdType id = t;
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	    for(typename std::map<NameType, TrieNode<Pub_Registry> *>::iterator iter = node->children.begin();
		iter != node->children.end(); iter++) {
	      id[sz-1] = iter->first;
	      propagate_child_pub_registry (id, iter->second, OPER_PUBLISH);
	    }
	  }
	}
	return SUCCESS;
      }

    /// subscribe
    Status subscribe_msg(IdType t, PubSub_Scope c, DestinationType *dest)
      {
	bool send2remote = false;
	Sub_Registry *reg = NULL;
	TrieNode<Sub_Registry> *node = sub_trie_root_;
	bool wildcard = false;
	bool hidden = false;
	int sz = t.size();

	/**
	 * traverse to node designated by t
	 */
	for (int i=0; i<sz; i++) {
	  if (t[i] == IdTrait::WildcardName) {
	    if (i == (sz-1)) {
	      wildcard = true;
	      break;
	    } else {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::subscribe_msg: Wildcard in middle [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	  }
	  if (!hidden) {
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_subers_ != NULL && !reg->w_subers_->empty()) {
	      for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
		  iter != reg->w_subers_->end() && !hidden; iter++) 
		if (iter->first->type() == MEMBER_LOCAL && 
		    (iter->second == SCOPE_GLOBAL || iter->second == SCOPE_REMOTE))
		  hidden = true;
	    }
	  }
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	  typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.find(t[i]);
	  if (iter == node->children.end()) {
	    TrieNode<Sub_Registry> *cnd = new TrieNode<Sub_Registry> (t[i], node);
	    node->children[t[i]] = cnd;
	    node = cnd;
	  } 
	  else
	    node = iter->second;
	}
	//update subscriptions
	//if !wildcard, add src & st -> node.registry->subers, return
	if (!wildcard) {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->subers_ == NULL) {
	      reg->subers_ = new std::map<DestinationType *, PubSub_Scope>();
	      send2remote = true;
	    }
	    if (!send2remote && !hidden) {
	      send2remote = true;
	      for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->subers_->begin();
		  iter != reg->subers_->end(); iter++)
		if (iter->first->type() == MEMBER_LOCAL &&
		    (iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
		  send2remote = false;
	    }
	    (*reg->subers_)[dest] = c;
	  }
	  //broadcast t to remote
	  if (send2remote && !hidden && dest->type() == MEMBER_LOCAL && 
	      (c == SCOPE_REMOTE || c == SCOPE_GLOBAL)) {
	    propagate_change_to_neighbors(OPER_SUBSCRIBE, t);
	  }
	}
	/**
	 * if wildcard, add dest & st -> node.registry->w_subers, 
	 * if scope_state is active, deactivate children for dest, return;
	 */
	else {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_subers_ == NULL) {
	      reg->w_subers_ = new std::map<DestinationType *, PubSub_Scope>();
	      send2remote = true;
	    }
	    if (!send2remote && !hidden) {
	      send2remote = true;
	      for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
		  iter != reg->w_subers_->end(); iter++)
		if (iter->first->type() == MEMBER_LOCAL && 
		    (iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
		  send2remote = false;
	    }
	    (*reg->w_subers_)[dest] = c;
	  }
	  //broadcast t to remote
	  if (send2remote && !hidden && dest->type() == MEMBER_LOCAL && 
	      (c == SCOPE_REMOTE || c == SCOPE_GLOBAL)) {
	    //unsubscribe child registry
	    IdType id = t;
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	    for(typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.begin();
		iter != node->children.end(); iter++) {
	      id[sz-1] = iter->first;
	      propagate_child_sub_registry (id, iter->second, OPER_UNSUBSCRIBE);
	    }
	    propagate_change_to_neighbors(OPER_SUBSCRIBE, t);
	  }
	}
	return SUCCESS;
      }

    ///unsubscribe
    Status unsubscribe_msg(IdType t, DestinationType *dest)
      {
	bool send2remote = false;
	Sub_Registry *reg = NULL;
	TrieNode<Sub_Registry> *node = sub_trie_root_;
	bool wildcard = false;
	bool hidden = false;
	int sz = t.size();

	/**
	 * traverse to node designated by t
	 */
	for (int i=0; i<sz; i++) {
	  if (t[i] == IdTrait::WildcardName) {
	    if (i == (sz-1)) {
	      wildcard = true;
	      break;
	    } else {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unsubscribe_msg: Wildcard in middle [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	  }
	  if (!hidden) {
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_subers_ != NULL && !reg->w_subers_->empty()) {
	      for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
		  iter != reg->w_subers_->end() && !hidden; iter++) 
		if (iter->first->type() == MEMBER_LOCAL && 
		    (iter->second == SCOPE_GLOBAL || iter->second == SCOPE_REMOTE))
		  hidden = true;
	    }
	  }
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	  typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.find(t[i]);
	  if (iter == node->children.end()) {
	    ACE_DEBUG((LM_DEBUG, "TrieRouter::unsubscribe_msg: not found [%s]\n",ID2STR(t).c_str()));
	    return FAILURE;
	  }
	  node = iter->second;
	}
	//update subscriptions
	if (!wildcard) {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->subers_ == NULL) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unsubscribe_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->subers_->find(dest);
	    if (iter == reg->subers_->end()) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unsubscribe_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    if (iter->first->type() == MEMBER_LOCAL && 
		(iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
	      send2remote = true;
	    reg->subers_->erase(dest);
	    if (send2remote && !hidden && !reg->subers_->empty()) {
	      for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->subers_->begin();
		  iter != reg->subers_->end(); iter++)
		if (iter->first->type() == MEMBER_LOCAL && 
		    (iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
		  send2remote = false;
	    }
	  }
	  //broadcast t to remote
	  if (send2remote && !hidden)
	    propagate_change_to_neighbors(OPER_UNSUBSCRIBE, t);
	}
	/**
	 * if t[level] = *, add src & st -> node.registry->w_pubers, 
	 * if scope_state is active, deactivate children for src, return;
	 */
	else {
	  {
	    ACE_WRITE_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_subers_ == NULL) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unsubscribe_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->find(dest);
	    if (iter == reg->w_subers_->end()) {
	      ACE_DEBUG((LM_DEBUG, "TrieRouter::unsubscribe_msg: not found [%s]\n",ID2STR(t).c_str()));
	      return FAILURE;
	    }
	    if (iter->first->type() == MEMBER_LOCAL && 
		(iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
	      send2remote = true;
	    reg->w_subers_->erase(dest);
	    if (send2remote && !hidden && !reg->w_subers_->empty()) {
	      for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
		  iter != reg->w_subers_->end(); iter++)
		if (iter->first->type() == MEMBER_LOCAL && 
		    (iter->second == SCOPE_REMOTE || iter->second == SCOPE_GLOBAL))
		  send2remote = false;
	    }
	  }
	  //broadcast t to remote
	  if (send2remote && !hidden) {
	    propagate_change_to_neighbors(OPER_UNSUBSCRIBE, t);
	    //subscribe child registry
	    IdType id = t;
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	    for(typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.begin();
		iter != node->children.end(); iter++) {
	      id[sz-1] = iter->first;
	      propagate_child_sub_registry (id, iter->second, OPER_SUBSCRIBE);
	    }
	  }
	}
	return SUCCESS;
      }

    /**
     * 2.
     * route msgs (from src to dest) based on :
     * src_type(local/remote) & publish_scope AND
     * dest_type(local/remote) & subscribe_scope
     */
    Status route_msg(MsgT *msg, Member_Type src_type, PubSub_Scope pub_scope, ACE_Time_Value *timeout=0)
      {
	Sub_Registry *reg = NULL;
	TrieNode<Sub_Registry> *node = sub_trie_root_;
	int sz = msg->type.size();
	bool cont = true;

	///need to redo locking in the following code
	DispatchContainer subers;

	/**
	 * traverse to node designated by t
	 */
	for (int i=0; i<sz; i++) {
	  {
	    //check if any wildcard subscription
	    ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);
	    reg = &(node->registry);
	    if (reg->w_subers_ != NULL && !reg->w_subers_->empty()) {
	      for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
		  iter != reg->w_subers_->end(); iter++) {
		//dispatch to wildcard subscriber
		short src_row = src_type * SCOPE_NUMBER + pub_scope;
		short dst_col = iter->first->type() * SCOPE_NUMBER + iter->second;
		if(scope_checking_tbl_[src_row][dst_col]) {
		  subers.push_back(iter->first);
		}
	      }
	    }
	  }
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	  typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.find(msg->type[i]);
	  if (iter == node->children.end()) {
	    cont = false;
		break;
	  }
	  node = iter->second;
	}

	if (!cont) {
	  if (subers.size() == 0) {
	    ACE_DEBUG ((LM_DEBUG, "msg [%s] dropped, scope dont match\n", ID2STR(msg->type).c_str()));
	    delete msg;
	  } else if (subers.size() == 1) {
	    ACE_DEBUG ((LM_DEBUG, "msg [%s] delivered\n", ID2STR(msg->type).c_str()));
	    subers[0]->put_msg(msg, timeout);
	  } else 
	    internal_dispatch(subers.begin(), subers.end(), msg, timeout);		
	  return SUCCESS;
	}

	ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->registry.subers_lock_, FAILURE);

	//dispatch wildcard subscribers
	reg = &(node->registry);
	if (reg->w_subers_ != NULL && !reg->w_subers_->empty()) {
	  for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
	      iter != reg->w_subers_->end(); iter++) {
	    short src_row = src_type * SCOPE_NUMBER + pub_scope;
	    short dst_col = iter->first->type() * SCOPE_NUMBER + iter->second;
	    if(scope_checking_tbl_[src_row][dst_col]) {
	      subers.push_back(iter->first);
	    }
	  }
	}

	//dispatch normal subscribers
	reg = &(node->registry);
	if (reg->subers_ != NULL && !reg->subers_->empty()) {
	  for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->subers_->begin(); 
	      iter != reg->subers_->end(); iter++) {
	    short src_row = src_type * SCOPE_NUMBER + pub_scope;
	    short dst_col = iter->first->type() * SCOPE_NUMBER + iter->second;
	    if(scope_checking_tbl_[src_row][dst_col]) {
	      subers.push_back(iter->first);
	    }
	  }
	}

	if (subers.size() == 0) {
	  ACE_DEBUG ((LM_DEBUG, "msg [%s] dropped, scope dont match\n", ID2STR(msg->type).c_str()));
	  delete msg;
	} else if (subers.size() == 1) {
	  ACE_DEBUG ((LM_DEBUG, "msg [%s] delivered\n", ID2STR(msg->type).c_str()));
	  subers[0]->put_msg(msg, timeout);
	} else 
	  internal_dispatch(subers.begin(), subers.end(), msg, timeout);

	return SUCCESS;
      }

    /**
     * 3. query namespace content
     */

    ///exported namespace
    Status subscribed_global_msgs(std::vector<IdType> &global_msgs)
      {
	IdType id;
	return subscribed_global_msgs_recursive(global_msgs, sub_trie_root_, id);
      }
    Status subscribed_global_msgs_recursive(std::vector<IdType> &global_msgs, TrieNode<Sub_Registry> *node, IdType &id)
      {
	Sub_Registry *reg = &(node->registry);

	{
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_, FAILURE);

	  //check wildcard subscription
	  if (reg->w_subers_ != NULL && !reg->w_subers_->empty()) {
	    for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->w_subers_->begin();
		iter != reg->w_subers_->end(); iter++) 
	      if (iter->first->type() == MEMBER_LOCAL && 
		  (iter->second == SCOPE_GLOBAL || iter->second == SCOPE_REMOTE)) {
		id.push_back(IdTrait::WildcardName);
		global_msgs.push_back(id);
		id.pop_back();
		return SUCCESS; //wildcard stop going deeper
	      }
	  }

	  //check normal subscription
	  if (reg->subers_ != NULL && !reg->subers_->empty()) {
	    for(typename std::map<DestinationType *, PubSub_Scope>::iterator iter = reg->subers_->begin();
		iter != reg->subers_->end() ; iter++) 
	      if (iter->first->type() == MEMBER_LOCAL && 
		  (iter->second == SCOPE_GLOBAL || iter->second == SCOPE_REMOTE)) {
		global_msgs.push_back(id);
		break;
	      }
	  }
	}

	ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	for(typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.begin();
	    iter != node->children.end(); iter++)
	  if (iter->second != NULL) {
	    id.push_back(iter->first);
	    subscribed_global_msgs_recursive(global_msgs, iter->second, id);
	    id.pop_back();
	  }

	return SUCCESS;
      }

    Status published_global_msgs(std::vector<IdType> &global_msgs)
      {
	IdType id;
	return published_global_msgs_recursive(global_msgs, pub_trie_root_, id);
      }
    Status published_global_msgs_recursive(std::vector<IdType> &global_msgs, TrieNode<Pub_Registry> *node, IdType &id)
      {
	Pub_Registry *reg = &(node->registry);

	{
	  ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->pubers_lock_, FAILURE);
	  //check wildcard 
	  if (reg->w_pubers_ != NULL && !reg->w_pubers_->empty()) {
	    id.push_back(IdTrait::WildcardName);
	    global_msgs.push_back(id);
	    id.pop_back();
	    return SUCCESS; //wildcard stop going deeper
	  }
	  //check normal subscription
	  if (reg->pubers_ != NULL && !reg->pubers_->empty()) {
	    global_msgs.push_back(id);
	  }
	}

	ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
	for(typename std::map<NameType, TrieNode<Pub_Registry> *>::iterator iter = node->children.begin();
	    iter != node->children.end(); iter++)
	  if (iter->second != NULL) {
	    id.push_back(iter->first);
	    published_global_msgs_recursive(global_msgs, iter->second, id);
	    id.pop_back();
	  }

	return SUCCESS;
      }

    void dump_pub_ids_recursive (TrieNode<Pub_Registry> *node, IdType &id) {
      Pub_Registry *reg = &(node->registry);

      {
	ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->pubers_lock_, FAILURE);
	//check wildcard 
	if (reg->w_pubers_ != NULL && !reg->w_pubers_->empty()) {
	  id.push_back(IdTrait::WildcardName);
	  ACE_DEBUG((LM_DEBUG, "%s\n", ID2STR(id).c_str()));
	  id.pop_back();
	}
	//check normal subscription
	if (reg->pubers_ != NULL && !reg->pubers_->empty()) {
	  ACE_DEBUG((LM_DEBUG, "%s\n", ID2STR(id).c_str()));
	}
      }

      ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
      for(typename std::map<NameType, TrieNode<Pub_Registry> *>::iterator iter = node->children.begin();
	  iter != node->children.end(); iter++)
	if (iter->second != NULL) {
	  id.push_back(iter->first);
	  dump_pub_ids_recursive(iter->second, id);
	  id.pop_back();
	}
    }

    void dump_sub_ids_recursive (TrieNode<Sub_Registry> *node, IdType &id) {
      Sub_Registry *reg = &(node->registry);

      {
	ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, reg->subers_lock_, FAILURE);
	//check wildcard 
	if (reg->w_subers_ != NULL && !reg->w_subers_->empty()) {
	  id.push_back(IdTrait::WildcardName);
	  ACE_DEBUG((LM_DEBUG, "%s\n", ID2STR(id).c_str()));
	  id.pop_back();
	}
	//check normal subscription
	if (reg->subers_ != NULL && !reg->subers_->empty()) {
	  ACE_DEBUG((LM_DEBUG, "%s\n", ID2STR(id).c_str()));
	}
      }

      ACE_READ_GUARD_RETURN(typename SynchPolicy::RW_MUTEX, guard, node->children_lock_, FAILURE);
      for(typename std::map<NameType, TrieNode<Sub_Registry> *>::iterator iter = node->children.begin();
	  iter != node->children.end(); iter++)
	if (iter->second != NULL) {
	  id.push_back(iter->first);
	  dump_sub_ids_recursive(iter->second, id);
	  id.pop_back();
	}
    }

    void dump_routing_tables(void)
      {
	ACE_DEBUG((LM_DEBUG, "The following IdTypes subscribed: \n"));
	{
	  IdType id;
	  dump_sub_ids_recursive(sub_trie_root_,id);
	}

	ACE_DEBUG((LM_DEBUG, "The following IdTypes published: \n"));
	{
	  IdType id;
	  dump_pub_ids_recursive(pub_trie_root_,id);
	}
      }

  protected:
    /**
     * 4. propagate namespace changes to connected channels
     */
    Status propagate_change_to_neighbors(Oper_Type op, IdType t)
      {
	ACE_DEBUG((LM_DEBUG, "TrieRouter:::propagate_change_to_neighbors [%s]\n",ID2STR(t).c_str()));
	PubSub_Info_MsgT *sub = new PubSub_Info_MsgT();
	sub->num_msg_types = 1;
	sub->msg_types[0] = t;
	IdType mt;
	switch(op) {
	case OPER_PUBLISH:
	  mt = Channel::PUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "TrieRouter:::propagate_change_to_neighbors publish "));
	  break;
	case OPER_UNPUBLISH:
	  mt = Channel::UNPUBLICATION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "TrieRouter:::propagate_change_to_neighbors unpublish "));
	  break;
	case OPER_SUBSCRIBE:
	  mt = Channel::SUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "TrieRouter:::propagate_change_to_neighbors subscribe "));
	  break;
	case OPER_UNSUBSCRIBE:
	  mt = Channel::UNSUBSCRIPTION_INFO_MSG;
	  ACE_DEBUG((LM_DEBUG, "TrieRouter:::propagate_change_to_neighbors unsubscribe "));
	  break;
	default:
	  ACE_DEBUG((LM_DEBUG, "TrieRouter:::propagate_change_to_neighbors invalid IdType "));
	  delete sub;
	  return SUCCESS;
	}
	MsgT *m = new MsgT(mt, sub);
	route_msg(m, MEMBER_LOCAL, SCOPE_REMOTE);
	return SUCCESS;
      }

  /**
   * template code to statically dispatch correct methods
   */
  void internal_dispatch (
			  typename DispatchContainer::iterator begin, 
			  typename DispatchContainer::iterator end, 
			  MsgT *msg, 
			  ACE_Time_Value *timeout,
			  Int2Type<true>
			  ) 
  {
    //stateless dispatcher
    dispatcher_(begin,end,msg,timeout);
  }
  void internal_dispatch (
			  typename DispatchContainer::iterator begin, 
			  typename DispatchContainer::iterator end, 
			  MsgT *msg, 
			  ACE_Time_Value *timeout,
			  Int2Type<false>
			  ) 
  {
    //stateful dispatcher
    dispatcher_[msg->type](begin,end,msg,timeout);
  }
  void internal_dispatch (
			  typename DispatchContainer::iterator begin, 
			  typename DispatchContainer::iterator end, 
			  MsgT *msg, 
			  ACE_Time_Value *timeout
			  ) 
  {
    internal_dispatch (begin,end,msg,timeout,Int2Type<(int)DispatchPolicy::type==(int)STATELESS>());
  }

  };

};



#endif

