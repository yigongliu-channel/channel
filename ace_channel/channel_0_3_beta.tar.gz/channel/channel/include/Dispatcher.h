////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _DISPATCHER_H_
#define _DISPATCHER_H_

//ACE headers
#include "ace/Log_Msg.h"
//for ACE_GUARD macros, need the following 2 headers
#include "ace/Synch.h"
#include "ace/OS.h"

#include <map>
#include <BaseDef.h>

/**
 * There are 2 types of dispatchers: 
 * 1. stateless: algorithms don't save state; the whole router share the same
 *			dispatcher for all Ids
 * 2. stateful: algorithms need to save state; each Id will have a separate dispatcher
 *
 * To work with MS VC++ compiler to create DLLs, have to use member templates here
 */

namespace channel {

  struct BroadcastDispatcher {
    enum { type = STATELESS };
    template <class MsgT, class InputIterator>
      Status operator() (InputIterator begin, InputIterator end, MsgT *msg, ACE_Time_Value *timeout) {
      MsgT *dup=NULL;
      for(InputIterator iter = begin; iter != end; iter++) {
	dup=msg->clone();
	ACE_DEBUG ((LM_DEBUG, "msg delivered once\n"));
	(*iter)->put_msg(dup, timeout);
      }
      delete msg;
      return SUCCESS;
    }
  };

  class RoundRobinDispatcher {
  public:
    enum { type = STATEFUL };
    RoundRobinDispatcher() : last_(-1) {}
    template <class MsgT, class InputIterator>
      Status operator() (InputIterator begin, InputIterator end, MsgT *msg, ACE_Time_Value *timeout) {
      last_ = (last_+1) % (end-begin);
      InputIterator iter = begin+last_;
      //for(int i=0; i<last_; i++) iter++;
      (*iter)->put_msg(msg, timeout);
      return SUCCESS;
    }
  private:
    int last_;
  };

  class RandomDispatcher {
  public:
    enum { type = STATELESS };
    template <class MsgT, class InputIterator>
      Status operator() (InputIterator begin, InputIterator end, MsgT *msg, ACE_Time_Value *timeout) {
      //TODO
      return SUCCESS;
    }
  };

  class WeightedRoundRobinDispatcher {
  public:
    enum { type = STATEFUL };
    template <class MsgT, class InputIterator>
      Status operator() (InputIterator begin, InputIterator end, MsgT *msg, ACE_Time_Value *timeout) {
      //TODO
      return SUCCESS;
    }
  };
};


#endif
