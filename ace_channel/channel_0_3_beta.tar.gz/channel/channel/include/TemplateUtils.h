////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#ifndef _TEMPLATE_UTILS_H_
#define _TEMPLATE_UTILS_H_

namespace channel {

  ///utils from generative-programming book
  template<bool condition, class Then, class Else>
    struct IF
    { typedef Then RET;
    };

  //specialization for condition==false
  template<class Then, class Else>
    struct IF<false, Then, Else>
    { typedef Else RET;
    };

  ///some utils from Loki book
  template <int v>
    struct Int2Type
    {
      enum { value = v };
    };

  struct EmptyType {};

  ///OneMember
  template <class DispType>
    struct DispWrapper { DispType dispatcher_; };
};

#endif


