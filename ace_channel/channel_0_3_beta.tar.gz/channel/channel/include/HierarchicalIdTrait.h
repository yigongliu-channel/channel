////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _HIERARCHICAL_IDTRAITS_H_
#define _HIERARCHICAL_IDTRAITS_H_

#include <vector>
#include <string>
#include <sstream>
#include "ace/CDR_Stream.h"
#include <Channel_export.h>

namespace channel {

  /**
   * hierarchical id types:
   * each id in hierarchical namespace consist of a seriese of sub-ids
   * denoting the "branches" of tree you traverse thru before reaching
   * the tree-node which represents the id; these sub-ids called elements
   * 1. if Elem_Type is "char", HierarchicalId will be strings
   * 2. if Elem_Type is "string", HierarichalId is unix style pathnames
   *
   * vector<Elem_Type> is used as the base class for all hierarchical id
   * to store the elements of hierarchical ids
   * real applications' hierarchial ids should inherit vector class and
   * add :
   * 1. convenience constructors
   * 2. marshal/demarshal methods
   * 3. other convenience methods
   */

  ///no default definition for id trait; must explicitly define it for each id type
  template <class IdType> class IdTrait;

  /**
   * StringPathId - a hierarchical id type using unix path names
   * element_type = string
   * in channel, only absolute pathnames are used: ie. must start with "/"
   * add convenience constructors and methods for decoding the names
   */
  template <char separator = '/'>
  struct StringPathId : public std::vector<std::string> {
    enum { Separator = separator };
    bool valid_;
    StringPathId () {
      valid_ = true;
    }
    StringPathId (const char * pathname) {
      std::string name(pathname);
      valid_ = true;
      size_type pos1 = std::string::npos, pos2 = std::string::npos;
      pos1 = name.find(Separator);
      if (pos1 == std::string::npos) {
	valid_ = false;
      } else {
	while (true) {
	  pos2 = name.find(Separator,pos1+1);
	  if (pos2 != std::string::npos)
	    push_back(name.substr(pos1+1, pos2-pos1-1));
	  else {
	    std::string s = name.substr(pos1+1);
	    pos2 = s.find_last_not_of(' ');
	    if (pos2 != std::string::npos)
	      push_back(s.substr(0, pos2+1));
	    break;
	  }
	  pos1 = pos2;
	}
      }
    }
  };

  ///trait class for string pathname id type
  template <char separator>
    class IdTrait<StringPathId<separator> > {
    public:

    typedef StringPathId<separator> IdType;
    enum { Separator = IdType::Separator };

    typedef typename IdType::value_type NameType;
    
    ///define system msgs
    static IdType CHANNEL_CONN_MSG;
    static IdType CHANNEL_DISCONN_MSG;
    static IdType INIT_SUBSCRIPTION_INFO_MSG;
    static IdType INIT_PUBLICATION_INFO_MSG;
    static IdType SUBSCRIPTION_INFO_MSG;
    static IdType UNSUBSCRIPTION_INFO_MSG;
    static IdType PUBLICATION_INFO_MSG;
    static IdType UNPUBLICATION_INFO_MSG;

    static NameType RootName;     //just a name for root trie node, not in namespace
    static NameType WildcardName;

    ///need the comparisons for msg matching and map
    static bool eq(const IdType &id1, const IdType &id2)
      { return id1 == id2; }
    static bool lt(const IdType &id1, const IdType &id2)
      { return id1 < id2; }

    static std::string idToString(const IdType &id) {
      std::ostringstream os;
      for(size_t i=0; i<id.size(); i++)
	os << (char)Separator << id[i];
      return os.str();
    }

    static bool endWithWildcard(const IdType &id) {
      return (*id.rbegin()) == WildcardName;
    }

    static bool valid(const IdType &id) {
      if (!id.valid_) return false;
      size_t sz = id.size();
      for (size_t i=0; i<sz; i++)
	if (id[i] == IdTrait::WildcardName && i != (sz-1))
	  return false;
      return true;
    }

    enum ID_COMPARE_RESULT {
      ID_MATCH,
      ID_1_CONTAINS_2,
      ID_2_CONTAINS_1,
      ID_MISMATCH
    };

    static ID_COMPARE_RESULT compare(IdType &id1, IdType &id2)
      {
	int sz1 = id1.size();
	int sz2 = id2.size();
	int sz = (sz1 < sz2)?sz1:sz2;
	for(int i=0; i<sz; i++) {
	  if (id1[i] != id2[i]) {
	    if (id1[i] == IdTrait::WildcardName)
	      return ID_1_CONTAINS_2;
	    else if (id2[i] == IdTrait::WildcardName)
	      return ID_2_CONTAINS_1;
	    else return ID_MISMATCH;
	  }
	}
	if (sz1 == sz2)
	  return ID_MATCH;
	else if(sz1 < sz2 && id2[sz1] == IdTrait::WildcardName)
	  return ID_2_CONTAINS_1;
	else if(sz2 < sz1 && id1[sz2] == IdTrait::WildcardName)
	  return ID_1_CONTAINS_2;
	return ID_MISMATCH;
      }

    //compiler doesnt allow references here
    //static bool match(const IdType &id1, const IdType &id2)
    static bool match(IdType id1, IdType id2)
      {
	return compare(id1,id2) != ID_MISMATCH;
      }

    //compiler doesnt allow references here
    //static bool id1contains2(const IdType &id1, const IdType &id2)
    static bool id1contains2(IdType id1, IdType id2)
      {
	ID_COMPARE_RESULT res = compare(id1,id2);
	return res == ID_MATCH || res == ID_1_CONTAINS_2;
      }

    static int size(const IdType &id) {
      int sz = 4; //num of elements
      for(size_t i=0; i<id.size(); i++)
	sz += 4 /*len*/ + id[i].length();
      return sz;
    }

    ///Id marshalling code; CDR...
    static int marshal(ACE_OutputCDR &cdr, const IdType &id)
      {
	cdr << ACE_CDR::Long (id.size());
	for(size_t i=0; i<id.size(); i++) {
	  cdr << ACE_CDR::Long (id[i].length());
	  cdr.write_char_array (id[i].c_str(), id[i].length());
	}
	return cdr.good_bit();
      }
    static int demarshal(ACE_InputCDR &cdr, IdType &id)
      {
	ACE_CDR::Long d;
	char buffer[1024];
	cdr >> d;
	int sz = (int) d;
	for (int i=0; i<sz; i++) {
	  cdr >> d;
	  int len = (int) d;
	  buffer[0] = '\0';
	  cdr.read_char_array(buffer, len);
	  buffer[len] = '\0';
	  id.push_back(buffer);
	}
	return cdr.good_bit();
      }    
  };

	///specialization for VC++ export
	//template struct Channel_Export StringPathId<'/'>;
	template class Channel_Export IdTrait<StringPathId<'/'> >;

  /**
   * helper class for initialization of hierarchical ids
   * overriding "/" operator
   */
  /*
  template <typename HierIdType>
    class SlashInitializer {
    typedef HierIdType::ElementType ElementType;
    private:
    
    protected:
    
  };
  */
  /**
   * NumericPathId - a hierarchical id type using integers as elements
   * similar to ip address scheme (4 parts each of which is 0-255)
   * element_type = int
   * add convenience constructors and methods for decoding the names
   */
  /*
  struct NumericPathId : public std::vector<int> {
  };

  ///trait class for numeric path id type
  template <>
    class IdTrait<NumericPathId> {
    public:
    ///define system msgs

    static NumericPathId CHANNEL_CONN_MSG;
    static NumericPathId CHANNEL_DISCONN_MSG;
    static NumericPathId INIT_SUBSCRIPTION_INFO_MSG;
    static NumericPathId INIT_PUBLICATION_INFO_MSG;
    static NumericPathId SUBSCRIPTION_INFO_MSG;
    static NumericPathId UNSUBSCRIPTION_INFO_MSG;
    static NumericPathId PUBLICATION_INFO_MSG;
    static NumericPathId UNPUBLICATION_INFO_MSG;

    typedef NumericPathId IdType;

    //define root_name
    
    //define wildcard_name

    ///need the comparisons for msg matching and map
    static bool eq(const NumericPathId &id1, const NumericPathId &id2)
      { return id1 == id2; }
    static bool lt(const NumericPathId &id1, const NumericPathId &id2)
      { return id1 < id2; }

    static std::string idToString(const NumericPathId id) {
      std::ostringstream os;
      os << "[Family:" << id.family << ", Type:" << id.type <<"]";
      return os.str();
    }

    static int size(const NumericPathId &id2) {
      ACE_UNUSED_ARG(id2);
      return sizeof(NumericPathId);
    }

    ///Id marshalling code; CDR...
    static int marshal(ACE_OutputCDR &cdr, const NumericPathId &id)
      {
	cdr << ACE_CDR::Long (id.family);
	cdr << ACE_CDR::Long (id.type);
	return cdr.good_bit();
      }
    static int demarshal(ACE_InputCDR &cdr, NumericPathId &id)
      {
	ACE_CDR::Long d;
	cdr >> d;
	id.family = (MessageFamily) d;
	cdr >> d;
	id.type = (int) d;
	return cdr.good_bit();
      }    
  };
  */
};

#endif
