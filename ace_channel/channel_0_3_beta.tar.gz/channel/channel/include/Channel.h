////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

//--------------------------------------------------------------
//
// Channel.h
//
//-------------------------------------------------------------

#ifndef _CHANNEL_H_
#define _CHANNEL_H_

//ace headers
#include "ace/config.h"
#include "ace/Synch_Traits.h"

//Channel headers
#include <Clock.h>
#include <BaseDef.h>
#include <Msg.h>
#include <ConnInfo.h>
#include <LinearIdTrait.h>
#include <HierarchicalIdTrait.h>
#include <Marshaler.h>
#include <Binder.h>
#include <Member.h>
#include <ConnHandler.h>
#include <Interface.h>
#include <OutputMgr.h>
#include <Connector.h>
#include <LocalConnector.h>
#include <TcpSockConnector.h>
#if !defined (ACE_WIN32)
#include <UnixSockConnector.h>
#endif
#include <Port.h>
#include <Dispatcher.h>
#include <MapRouter.h>
#include <TrieRouter.h>


namespace channel {

  /**
   * main template to integrate various aspects (traits/policies) of channel together:
   * also holding all the major types involved with channel, make it easy to 
   * bring type info to various places in Channel internal implementation and
   * Channel clients code; following std:: containers and streams style
   */
  template 
    <
    class Id_Type, 
    class Id_Trait = IdTrait<Id_Type>,
    class Synch_Policy = ACE_MT_SYNCH, ///for single-threaded app, use ACE_NULL_SYNCH
    //class AllocPolicy,
    class Dispatch_Policy = BroadcastDispatcher,
    class RouterType = MapRouter<Id_Type, Id_Trait, Synch_Policy, /*AllocPolicy, */Dispatch_Policy>
    >
    class  Channel : public Id_Trait, public RouterType
    {
      public:

      ///The following are common channel related types
      typedef Id_Type IdType;
      typedef Id_Trait IdTrait;
      typedef Synch_Policy SynchPolicy;
      typedef RouterType Router;
      typedef Channel<IdType, Id_Trait, SynchPolicy, Dispatch_Policy, Router> ChannelType;
      typedef Source<ChannelType, Router::NamespaceType> Source;
      typedef Destination<ChannelType, Router::NamespaceType> Destination;
      //typedef Callback<ChannelType> Callback;
      typedef Destination Callback;
      typedef Port<ChannelType> Port;
      typedef Msg<Id_Type, SynchPolicy> Msg;
      ///Channel interanl/system messages
      typedef struct Channel_Info_Msg Channel_Info_Msg;
      typedef PubSub_Info_Msg<Id_Type> PubSub_Info_Msg;

      ///although channels can be used as local namespace without
      ///connectors; these connectors types are defined here as a shortcut
      typedef LocalConnector<ChannelType> LocalConnector;
      typedef Connector<ChannelType, TcpSockTransport<ChannelType> > TcpSockConnector;
#if !defined (ACE_WIN32)
	  typedef Connector<ChannelType, UnixSockTransport<ChannelType> > UnixSockConnector;
#endif
    };

};

#endif
