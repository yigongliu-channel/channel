////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef _LOCAL_CONNECTOR_H_
#define _LOCAL_CONNECTOR_H_

#include <BaseDef.h>

#include "ace/Log_Msg.h"
#include <vector>
#include <algorithm>

namespace channel {

  template <class> class Interface;
  template <class> class LocalInterface;
  template <class, class> class Binder;

  /**
   * A simple LocalConnector to connect channels within the same process
   * assuming no concerns about filtering and address translation
   */
  template <class Channel>
    class  LocalConnector {
    public:
    typedef LocalInterface<Channel> LocalInterface;
    typedef Interface<Channel> Interface;
    typedef Binder<typename Channel::IdType, typename Channel::IdTrait> Binder;

    typedef typename Channel::IdType IdType;
    typedef typename Channel::Msg Msg;
    typedef typename Channel::Channel_Info_Msg Channel_Info_Msg;

    static Status connect (Channel *ch1, Channel *ch2, Binder *binder1 = NULL, Binder *binder2 = NULL)
      {
	ACE_DEBUG((LM_DEBUG, "LocalConnector::connect enter\n"));
	//1. setup local interfaces
	LocalInterface *intf1 = new LocalInterface(ch1, binder1);
	LocalInterface *intf2 = new LocalInterface(ch2, binder2);
	intf1->peer_interface_ = intf2;
	intf2->peer_interface_ = intf1;

	//2. exchange channel_info msgs
	//so the members of channel can learn peer_local_channel connect
	Channel_Info_Msg *chInfo = new Channel_Info_Msg();
	chInfo->is_local = true;
	chInfo->intf = intf1;
	Msg *m = new Msg(Channel::CHANNEL_CONN_MSG, chInfo);
	intf1->send_msg (m);
	chInfo = new Channel_Info_Msg();
	chInfo->is_local = true;
	chInfo->intf = intf2;
	m = new Msg(Channel::CHANNEL_CONN_MSG, chInfo);
	intf2->send_msg (m);
  
	//3. exchange init_sub/pub_info msgs
	//3.1. msgs from ch1->ch2
	std::vector<IdType> ch1_pub_msgs;
	ch1->published_global_msgs (ch1_pub_msgs);
	std::vector<IdType> ch2_sub_msgs;
	ch2->subscribed_global_msgs(ch2_sub_msgs);
	for(typename std::vector<IdType>::iterator iter = ch1_pub_msgs.begin();
	    iter != ch1_pub_msgs.end(); iter++) {
	  if (intf1->filter_ != NULL && intf1->filter_->block_outward(*iter))
	    continue;
	  if (find (ch2_sub_msgs.begin(), ch2_sub_msgs.end(), (*iter)) !=
	      ch2_sub_msgs.end()) {
	    intf2->publish_msg((*iter), SCOPE_LOCAL);
	    intf1->subscribe_msg((*iter), SCOPE_LOCAL);
	  }
	}
	//3.2. msgs from ch2->ch1
	std::vector<IdType> ch2_pub_msgs;
	ch2->published_global_msgs (ch2_pub_msgs);
	std::vector<IdType> ch1_sub_msgs;
	ch1->subscribed_global_msgs(ch1_sub_msgs);
	for(typename std::vector<IdType>::iterator iter = ch2_pub_msgs.begin();
	    iter != ch2_pub_msgs.end(); iter++) {
	  if (intf2->filter_ != NULL && intf2->filter_->block_outward(*iter))
	    continue;
	  if (find (ch1_sub_msgs.begin(), ch1_sub_msgs.end(), (*iter)) !=
	      ch1_sub_msgs.end()) {
	    intf1->publish_msg((*iter), SCOPE_LOCAL);
	    intf2->subscribe_msg((*iter), SCOPE_LOCAL);
	  }
	}
	return SUCCESS;
      }
  };

};

#endif
 
