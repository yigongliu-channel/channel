////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2007 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef UNBOUNDED_QUEUE_HPP
#define UNBOUNDED_QUEUE_HPP

#include <deque>

namespace boost {
  namespace channel {

    /**
     * the simplest msg_que: unbounded size
     */
    template <typename elem_type, typename synch_policy, typename platform>
    class unbounded_que {
    public:
      std::deque<elem_type> data_;
      typename synch_policy::mutex lock_;
      bool empty() {
	typename synch_policy::scoped_lock lock(lock_);
	return data_.empty();
      }
      size_t size() {
	typename synch_policy::scoped_lock lock(lock_);
	return data_.size();
      }
      void put(elem_type & e) {
	typename synch_policy::scoped_lock lock(lock_);
	data_.push_back(e);
      }
      void get(elem_type & e) {
	typename synch_policy::scoped_lock lock(lock_);
	if (!data_.empty()) {
	  e = data_.front();
	  data_.pop_front();
	}
      }
    };

  }
}

#endif

 
