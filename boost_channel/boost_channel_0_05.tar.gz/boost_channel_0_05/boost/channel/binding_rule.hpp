////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef BINDING_RULE_HPP
#define BINDING_RULE_HPP

#include <boost/channel/name.hpp>
#include <boost/channel/config.hpp>

namespace boost {
  namespace channel {
    namespace detail {
      class BOOST_CHANNEL_DECL binding_rule {
      public:
	///binding scope checking table:
	///row: publish_member_type * scope_number + publish_scope
	///col: subscribe_member_type * scope_number + subscribe_scope
	///since "remote" members can only send_to/recv_from "local"
	///members, only the upper-left 4x4 sub-matrix have value
	///value "1" marks a valid combo of publisher(row) sending to subscriber(col)
	///value "0" marks invalid
	static short scope_checking_tbl_[][name_base::scope_number * name_base::member_number];
	static bool valid_binding(short src_scope, short src_type,
				  short dst_scope, short dst_type) {
	  short src_row = src_type * name_base::scope_number + src_scope;
	  short dst_col = dst_type * name_base::scope_number + dst_scope;
	  return scope_checking_tbl_[src_row][dst_col] ==  1;
	}
      };
    }
  }
}

#endif
