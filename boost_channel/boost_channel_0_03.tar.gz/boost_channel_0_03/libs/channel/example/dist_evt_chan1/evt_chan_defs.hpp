////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef EVT_CHAN_DEFS_HPP
#define EVT_CHAN_DEFS_HPP

#include <string>
#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/channel/channel.hpp>

using namespace std;
using namespace boost::channel;

//instantiate event channel type, using string as id_type
//and execute all async operations in asio executor
typedef channel<string, 
		boost_platform,
		mt_synch<boost_platform>,
		asio_executor> evt_chan;
typedef evt_chan::platform::timeout_type timeout_type;

//event ids in name_space
//sample events for a gui window
string down_id = "_window_button_down_";
string up_id = "_window_button_up_";
string close_id = "_window_close_";

//a simple struct for event data
struct evt_data {
  string data_;
  evt_data(const char *d) : data_(d) {}
  evt_data() {} //have to define this for marshaling to work
  //serialization function for evt_data
  template <typename Archive>
  void serialize(Archive & ar, const unsigned int version)
  {
    ar & data_;
  }
};

#endif
