////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef ASIO_CONNECTOR_HPP
#define ASIO_CONNECTOR_HPP

#include <string>
#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/asio.hpp>
#include <boost/channel/streams/asio_stream.hpp>

using boost::asio::ip::tcp;

namespace boost {
  namespace channel {
    namespace detail {
      class conn_handler_base {
      public:
	virtual void handle(boost::shared_ptr<tcp::socket> sock, bool active) = 0;
	virtual ~conn_handler_base() {}
      };
      template <typename conn_handler_type>
      class conn_handler : public conn_handler_base {
      public:
	conn_handler(conn_handler_type h) : handler_(h) {}
	void handle(boost::shared_ptr<tcp::socket> sock_conn, bool active) {
	  handler_(sock_conn, active);
	}
      private:
	conn_handler_type handler_;
      };
    }

    class asio_connector {
    public:
      asio_connector(boost::asio::io_service& io_service): io_service_(io_service) {}
      //define accept and connect
      template <typename sock_conn_handler>
      void async_accept(int port, sock_conn_handler hndl) {
	boost::shared_ptr<detail::conn_handler_base> handler(new detail::conn_handler<sock_conn_handler>(hndl));
	tcp::endpoint endpoint(tcp::v4(), port);
	boost::shared_ptr<tcp::acceptor> acceptor(new tcp::acceptor(io_service_, endpoint));
	boost::shared_ptr<tcp::socket> sock(new tcp::socket(io_service_));
	acceptor->async_accept(*sock, boost::bind(&asio_connector::handle_accept, this,
		acceptor, handler, sock, boost::asio::placeholders::error));
      }

						  
      void handle_accept(boost::shared_ptr<tcp::acceptor> acceptor,
			 boost::shared_ptr<detail::conn_handler_base> handler,
			 boost::shared_ptr<tcp::socket> sock,
			 const boost::asio::error& error)
      {
	if (!error)
	  {
	    handler->handle(sock, false);
	    sock.reset(new tcp::socket(io_service_));
	    acceptor->async_accept(*sock, boost::bind(&asio_connector::handle_accept, this,
		acceptor, handler, sock, boost::asio::placeholders::error));
	  }
      }

      template <typename sock_conn_handler>
      void sync_connect(std::string host, std::string port, sock_conn_handler hndl) {
	tcp::resolver resolver(io_service_);
	tcp::resolver::query query(host, port);
	tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
	tcp::resolver::iterator end;

	boost::shared_ptr<tcp::socket> sock(new tcp::socket(io_service_));
	boost::asio::error error = boost::asio::error::host_not_found;
	while (error && endpoint_iterator != end)
	  {
	    sock->close();
	    sock->connect(*endpoint_iterator++, boost::asio::assign_error(error));
	  }
	if (error)
	  throw error;

	hndl(sock, true);
      }

      template <typename sock_conn_handler>
      void async_connect(std::string host, std::string port, sock_conn_handler hndl) {
	tcp::resolver resolver(io_service_);
	tcp::resolver::query query(host, port);
	tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
	tcp::endpoint endpoint = *endpoint_iterator;

	boost::shared_ptr<tcp::socket> sock(new tcp::socket(io_service_));
	boost::shared_ptr<detail::conn_handler_base> handler(new detail::conn_handler<sock_conn_handler>(hndl));
	sock->async_connect(endpoint,
			   boost::bind(&asio_connector::handle_connect, this, sock, handler,
			      boost::asio::placeholders::error, ++endpoint_iterator));
      }

      void handle_connect(boost::shared_ptr<tcp::socket> sock, 
			  boost::shared_ptr<detail::conn_handler_base> handler,
			  const boost::asio::error& error,
			  tcp::resolver::iterator endpoint_iterator)
      {
	if (!error)
	  {
	    handler->handle(sock, true);
	  }
	else if (endpoint_iterator != tcp::resolver::iterator())
	  {
	    sock->close();
	    tcp::endpoint endpoint = *endpoint_iterator;
	    sock->async_connect(endpoint,
			   boost::bind(&asio_connector::handle_connect, this, sock, handler,
			      boost::asio::placeholders::error, ++endpoint_iterator));
	  }
      }

    private:
      boost::asio::io_service& io_service_;
    };
  
    template<typename channel, typename marshaler_registry>
    struct asio_bind_sock_chan {
      typedef void result_type;
      typename channel::binder_type *binder_;
      asio_bind_sock_chan(typename channel::binder_type * b = NULL):
	binder_(b) {}
      void operator()(channel &chan, 
		      marshaler_registry &reg,
		      boost::shared_ptr<tcp::socket> sock, bool active) {
	typedef typename channel::id_type id_type;
	typedef typename channel::platform::timeout_type timeout_type;
	typedef asio_stream<id_type, marshaler_registry, timeout_type> asio_stream;
	asio_stream *stream = new asio_stream(sock, reg);
	//should connect first, so that when stream starts(reading),
	//peer channel is already connected to forward msgs
	connect(chan, stream, active,binder_);
	stream->start(); //start reading from sock
      }
    };

  }
}

#endif

