////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#ifndef PULL_DISPATCHER_BASE_HPP
#define PULL_DISPATCHER_BASE_HPP

#include <map>
#include <vector>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>
#include <boost/channel/platforms/synch_policy.hpp>
#include <boost/channel/message.hpp>
#include <boost/channel/name.hpp>
#include <boost/channel/named_in_out.hpp>
#include <boost/channel/queues/dumb_queue.hpp>
#include <boost/channel/dispatchers/dispatcher_base.hpp>

namespace boost {
  namespace channel {

    namespace detail {

      //base pull_sender class, shared by most pull dispatchers
      template <typename name_space, typename platform,
		template <class,class> class msg_queue_type>
      struct pull_sender_base {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef msg_queue_type<boost::shared_ptr<msg_type>, timeout_type> que_type;

	name_type * name_;
	executor *exec_;
	typename synch_policy::mutex q_lock_;
	que_type que_;

	pull_sender_base(name_type *n, executor *e) : name_(n), exec_(e) { }
	virtual ~pull_sender_base() {}

	virtual void notify(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0)=0;

	//assuming msgs contained inside shared_ptr
	void store_data(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) 
	{
	  typename synch_policy::scoped_lock qlock(q_lock_);
	  que_.put(msg, timeout);
	}

	//recvers will call this to retrv/pull data
	int pull(boost::shared_ptr<msg_type> & msg, timeout_type *timeout=0) {
	  typename synch_policy::scoped_lock qlock(q_lock_);
	  if (!que_.empty()) {
	    que_.get(msg, timeout);
	    return msg->size_;
	  }
	  return 0;
	}

	//after sending, channel becomes owner
	template <typename user_msg_type>
	void send(user_msg_type *msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  notify (m, timeout);
	}

	//after sending: 1> channel becomes owner, if deleter does real deletion
	// 2> sender still owns msg, if deleter does nothing
	template <typename user_msg_type, typename deleter>
	void send(user_msg_type *msg, deleter deler, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg, deler);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  notify (m, timeout);
	}

	//user_msg is already smarter pointer, channel becomes owner
	template <typename user_msg_type>
	void send(boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  notify (m, timeout);
	}

      };

    }

  }
}

#endif
