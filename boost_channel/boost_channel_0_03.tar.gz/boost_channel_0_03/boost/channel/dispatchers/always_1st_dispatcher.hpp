////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef ALWAYS_1ST_DISPATCHER_HPP
#define ALWAYS_1ST_DISPATCHER_HPP

////imitate plan9/inferno's "union" name_space:
////later bound names will overlap older names, ie. latest mounted server will
////take over and serve all msgs on the covered names
////so always the latest bound name get dispatched

#include <map>
#include <vector>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/channel/platforms/synch_policy.hpp>
#include <boost/channel/message.hpp>
#include <boost/channel/name.hpp>
#include <boost/channel/named_in_out.hpp>
#include <boost/channel/queues/dumb_queue.hpp>
#include <boost/channel/dispatchers/dispatcher_base.hpp>
#include <boost/channel/dispatchers/push_dispatcher_base.hpp>

namespace boost {
  namespace channel {

    namespace detail {

      template <typename name_space,typename platform>
      struct always_1st_algo {
	typedef typename name_space::id_type id_type;
	typedef message<id_type> msg_type;
	typedef typename platform::timeout_type timeout_type;
	typedef push_recver_base<name_space,platform> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	template<typename bindings_type>
	void operator() (bindings_type &bindings, 
			 boost::shared_ptr<msg_type> msg, timeout_type *timeout) {
	  if (!bindings.empty()) {
	    typename bindings_type::iterator iter = bindings.begin();
	    named_in_type *named_in = (named_in_type *)(*iter);
	    recver_type *recver = (recver_type *)named_in;
	    recver->push(msg,timeout);
	  }
	}
      };

    }

    template <typename name_space, typename platform>
    struct always_1st_dispatcher {
      typedef detail::push_sender_base<name_space,platform,detail::always_1st_algo> sender;
      typedef detail::push_recver_base<name_space,platform> recver;
    };

  }
}

#endif
