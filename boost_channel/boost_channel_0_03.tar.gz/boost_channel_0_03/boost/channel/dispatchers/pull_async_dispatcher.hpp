////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#ifndef PULL_ASYNC_DISPATCHER_HPP
#define PULL_ASYNC_DISPATCHER_HPP

#include <map>
#include <vector>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>
#include <boost/channel/platforms/synch_policy.hpp>
#include <boost/channel/message.hpp>
#include <boost/channel/name.hpp>
#include <boost/channel/named_in_out.hpp>
#include <boost/channel/queues/dumb_queue.hpp>
#include <boost/channel/dispatchers/dispatcher_base.hpp>
#include <boost/channel/dispatchers/pull_dispatcher_base.hpp>

namespace boost {
  namespace channel {

    namespace detail {

      template<class,class,template<class,class>class> class pull_recver_async;

      template <typename name_space, typename platform, template <class,class> class msg_queue_type>
      struct pull_sender_async : public pull_sender_base<name_space,platform,msg_queue_type> {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef msg_queue_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_recver_async<name_space, platform,msg_queue_type> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	pull_sender_async(name_type *n, executor *e) : 
	  pull_sender_base<name_space,platform,msg_queue_type>(n,e), num_claimed_(0) { }
	~pull_sender_async() {}

	//assuming msgs contained inside shared_ptr
	void notify(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) {
	  store_data(msg, timeout);
	  typename synch_policy::scoped_lock lock(this->name_->bind_lock_);
	  binding_set_type &bindings = this->name_->bindings_;
	  if (!bindings.empty()) {
	    ///let all interested recvers know that a message is available
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end(); iter++) {
	      named_in_type *named_in = (named_in_type *)(*iter);
	      recver_type *recver = (recver_type *)named_in;
	      recver->notify(msg->id_);
	    }
	  }
	}

	//specific for pull_sender_async:
        int num_claimed_; //protected by q_lock_
	
	//to support 2-phase protocol at recver side
	bool claim_one(void) {
	  typename synch_policy::scoped_lock lock(this->q_lock_);
	  if ((int)this->que_.size() > num_claimed_) {
	    num_claimed_++;
	    return true;
	  }
	  return false;
	}

	void unclaim_one(void) {
	  typename synch_policy::scoped_lock lock(this->q_lock_);
	  num_claimed_--;
	  if (num_claimed_ < 0) num_claimed_ = 0;
	}
      };

      //pull_recver_async class, base for join/choice pattern
      template <typename name_space, typename platform, template <class,class> class msg_que_type>
      struct pull_recver_async {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef msg_que_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_sender_async<name_space, platform, msg_que_type> sender_type;
	typedef named_out<name_space, sender_type> named_out_type;

	name_type * name_;
	msg_handler_base2<id_type> * recver_;
	executor *exec_;
	sender_type *claimed_sender_;
      
	template<typename recver_type>
	pull_recver_async(name_type *n, recver_type rc, executor *e) : 
	  name_(n), exec_(e), claimed_sender_(NULL) 
	{
	  recver_ = new msg_handler2<id_type, recver_type>(rc);
	}

	~pull_recver_async() { 
	  if (recver_ != NULL)
	    recver_->destroy();
	  if (claimed_sender_ != NULL)
	    claimed_sender_->unclaim_one();
	}

	//senders call this to notify about some data coming
	//put this recver into activation list
	bool notify(id_type id) {
	  if (exec_ != NULL) //run recv_handler in executor
	    exec_->execute(boost::bind(&msg_handler_base2<id_type>::invoke, recver_,id));
	  else //run recv_handler in place
	    recver_->invoke(id);

	  return true; //always return true to force sender to notify others
	}

	//claim data at sender
	bool claim(void) {
	  if (claimed_sender_ != NULL) { //should not happen
	    claimed_sender_->unclaim_one();
	    claimed_sender_ = NULL;
	  }
	  //go-thru binding_set to claim
	  typename synch_policy::scoped_lock lock(name_->bind_lock_);
	  binding_set_type &bindings = name_->bindings_;
	  if (!bindings.empty()) {
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end() && claimed_sender_ == NULL; iter++) {
	      named_out_type *named_out = (named_out_type *)(*iter);
	      sender_type *sender = (sender_type *)(named_out);
	      if(sender->claim_one()) claimed_sender_ = sender;
	    }
	  }
	  if (claimed_sender_ != NULL) return true;
	  else return false;
	}

	//
	void unclaim(void) {
	  if (claimed_sender_ != NULL) {
	    claimed_sender_->unclaim_one();
	    claimed_sender_ = NULL;
	  }
	}

	//pull data from sender
	int pull(boost::shared_ptr<msg_type> & msg) {
	  int sz = 0;
	  if (claimed_sender_ != NULL) {
	      sz = claimed_sender_->pull(msg);
	      claimed_sender_->unclaim_one();
	      claimed_sender_ = NULL;
	  }
	  return sz;
	}
      };

    }

    template <typename name_space, typename platform, 
	      template <class,class> class queue_type> class choice_arbiter;
    template <typename name_space, typename platform, 
	      template <class,class> class queue_type> class join_arbiter;

    template <typename name_space, typename platform, 
	      template <class,class> class queue_type = dumb_que>
    struct buffered_async_dispatcher {
      typedef detail::pull_sender_async<name_space,platform,queue_type> sender;
      typedef detail::pull_recver_async<name_space,platform,queue_type> recver;
      typedef choice_arbiter<name_space,platform,queue_type> choice_arbiter;
      typedef join_arbiter<name_space,platform,queue_type> join_arbiter;
    };


  }
}

#endif
