////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#ifndef PULL_SYNC_DISPATCHER_HPP
#define PULL_SYNC_DISPATCHER_HPP

#include <map>
#include <vector>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>
#include <boost/channel/platforms/synch_policy.hpp>
#include <boost/channel/message.hpp>
#include <boost/channel/name.hpp>
#include <boost/channel/named_in_out.hpp>
#include <boost/channel/queues/dumb_queue.hpp>
#include <boost/channel/dispatchers/dispatcher_base.hpp>
#include <boost/channel/dispatchers/pull_dispatcher_base.hpp>

namespace boost {
  namespace channel {

    namespace detail {

      template<class,class,template<class,class>class> class pull_recver_sync;

      template <typename name_space, typename platform, template <class,class> class msg_queue_type>
      struct pull_sender_sync : public pull_sender_base<name_space,platform,msg_queue_type> {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef msg_queue_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_recver_sync<name_space, platform,msg_queue_type> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	pull_sender_sync(name_type *n, executor *e) : pull_sender_base<name_space,platform,msg_queue_type>(n,e) { }
	~pull_sender_sync() {}

	//assuming msgs contained inside shared_ptr
	void notify(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) {
	  store_data(msg, timeout);
	  typename synch_policy::scoped_lock lock(this->name_->bind_lock_);
	  binding_set_type &bindings = this->name_->bindings_;
	  if (!bindings.empty()) {
	    bool cont = true;
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end() && cont; iter++) {
	      named_in_type *named_in = (named_in_type *)(*iter);
	      recver_type *recver = (recver_type *)named_in;
	      cont = recver->notify(msg->id_);
	    }
	  }
	}
      };

      //synchronous/blocking pull_recver
      template <typename name_space, typename platform, template <class,class> class msg_que_type>
      struct pull_recver_sync {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef msg_que_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_sender_sync<name_space, platform, msg_que_type> sender_type;
	typedef named_out<name_space, sender_type> named_out_type;
	typedef typename name_type::binding_set_type binding_set_type;

	name_type * name_;
	typename synch_policy::mutex mutex_;
	typename synch_policy::condition cond_;
	int num_waiting_;

	pull_recver_sync(name_type *n) : 
	  name_(n), num_waiting_(0) {}

	~pull_recver_sync() {}

	//recving thread will block here and wait for notify from senders
	void recv(id_type & id, boost::shared_ptr<void> & msg, int & sz, timeout_type *t=0) {
	  boost::shared_ptr<msg_type> mesg;
	  typename synch_policy::scoped_lock lock(mutex_);
	  while(1) {
	    sz = pull(mesg);
	    if (sz != 0) {
	      id = mesg->id_;
	      msg = mesg->data_;
	      return;
	    }
	    num_waiting_++;
	    cond_.wait(lock);
	    num_waiting_--;
	  }	      
	}

	//if any thread block waiting here
	bool notify(id_type id) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  if (num_waiting_ > 0) {
	    cond_.notify_one();
	    return false;
	  } 
	  else
	    return true;
	}

	//pull data from sender
	int pull(boost::shared_ptr<msg_type> & msg) {
	  int sz = 0;
	  //go-thru binding_set to pull from senders
	  typename synch_policy::scoped_lock lock(name_->bind_lock_);
	  binding_set_type &bindings = name_->bindings_;
	  if (!bindings.empty()) {
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end() && sz == 0; iter++) {
	      named_out_type *named_out = (named_out_type *)(*iter);
	      sender_type *sender = (sender_type *)(named_out);
	      sz = sender->pull(msg);
	    }
	  }
	  return sz;
	}
      };
    
    }

    template <typename name_space, typename platform, template <class,class> class queue_type = dumb_que>
    struct buffered_sync_dispatcher {
      typedef detail::pull_sender_sync<name_space,platform,queue_type> sender;
      typedef detail::pull_recver_sync<name_space,platform,queue_type> recver;
    };

  }
}

#endif
