////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#ifndef INTERFACE_HPP
#define INTERFACE_HPP

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/bind.hpp>
#include <boost/channel/binder.hpp>
#include <boost/channel/named_in_out.hpp>
#include <boost/channel/dispatchers/broadcast_dispatcher.hpp>
#include <boost/channel/message.hpp>
#include <boost/channel/peer.hpp>
#include <boost/channel/name.hpp>

namespace boost {
  namespace channel {

    //interface to other channels or streams
    template <typename channel>
    class interface : 
      public peer_type<typename channel::id_type, typename channel::platform::timeout_type> {
    public:
      enum state_type {
	intf_init=0,
	intf_active
      };

      typedef typename channel::platform platform;
      typedef typename channel::name_space_type name_space;
      typedef typename name_space::synch_policy synch_policy;
      typedef typename channel::id_type id_type;
      typedef typename channel::id_trait id_trait;
      typedef typename name_space::name name;
      typedef typename channel::out named_out;
      typedef typename channel::in named_in;
      typedef typename platform::timeout_type timeout_type;
      typedef peer_type<id_type,timeout_type> peer_type;
      typedef message<id_type> message_type;
      typedef interface<channel> interface_type;
      typedef connection<id_type,timeout_type> connection_type;
      typedef typename channel::executor executor;
      typedef named_out_bundle<name_space, typename broadcast_dispatcher<name_space,platform>::sender > named_out_bundle;
      typedef named_in_bundle<name_space, typename broadcast_dispatcher<name_space,platform>::recver > named_in_bundle;
      typedef binder_type<id_type, id_trait> binder_type;
      typedef translator_type<id_type, id_trait> translator_type;
      typedef filter_type<id_type, id_trait> filter_type;
      typedef pubsub_info_msg_t<id_type> pubsub_info_msg_t;

    private:
      ///
      channel &ch_;
      state_type state_;

      //ids bound at local channel
      named_in_bundle named_ins_;
      named_out_bundle named_outs_;

      ///outgoing-msg buffering when connection to remote peer is not ready yet
      std::vector<boost::shared_ptr<message_type> > pending_msgs_;
      typename synch_policy::mutex lock_;///lock to maintain interface internal state

      ///filter & translators: policies for remote connections
      filter_type *filter_;
      translator_type *translator_;

    public:
      interface (channel &chan, binder_type *binder)  : 
	ch_(chan),
	named_ins_(chan, boost::bind(&interface::recv,this, _1,_2,_3,_4), 
		   name_base::member_remote), 
	named_outs_(chan, name_base::member_remote)
      {
	state_ = intf_init;
	ch_.add_intf(this);
	if (binder == NULL) {
	  filter_ = NULL;
	  translator_ = NULL;
	} else {
	  filter_ = binder->filter;
	  translator_ = binder->translator;
	}
	//subscribe to system msgs from local channel on behalf of the remote side
	//since channel_(DIS)CONN_msg and init_SUB/PUB_info_msg
	//are generated inside interface, no need to subscribe to them in channels
	named_ins_.bind(channel::subscription_info_msg, name_base::scope_local);
	named_ins_.bind(channel::unsubscription_info_msg, name_base::scope_local);
	named_ins_.bind(channel::publication_info_msg, name_base::scope_local);
	named_ins_.bind(channel::unpublication_info_msg, name_base::scope_local);
	//publish system msgs at local channel on behalf of the remote side
	named_outs_.bind(channel::channel_conn_msg, name_base::scope_local);
	named_outs_.bind(channel::channel_disconn_msg, name_base::scope_local);
	named_outs_.bind(channel::init_subscription_info_msg, name_base::scope_local);
	named_outs_.bind(channel::connection_ready_msg, name_base::scope_local);
	named_outs_.bind(channel::subscription_info_msg, name_base::scope_local);
	named_outs_.bind(channel::unsubscription_info_msg, name_base::scope_local);
	named_outs_.bind(channel::publication_info_msg, name_base::scope_local);
	named_outs_.bind(channel::unpublication_info_msg, name_base::scope_local);
      }

      ~interface () 
      {
	ch_.del_intf(this);
      }

      ///called from inside channel, forward msgs from inside channel to peers
      void recv(id_type id, boost::shared_ptr<void> msg, int sz, timeout_type *timeout=0)
      {
	platform::log("recv ["+id_trait::id_to_string(id)+"]");
	if(state_ != intf_active) {
	  boost::shared_ptr<message_type> m(new message_type(id,msg,sz));
	  add_pending_msg(m);
	  platform::log("... msgs["+id_trait::id_to_string(id)+"] buffered \n");
	} else {
	  //translate application msgs if set
	  if (translator_ != NULL &&
	      id != channel::channel_conn_msg &&
	      id != channel::channel_disconn_msg &&
	      id != channel::init_subscription_info_msg &&
	      id != channel::connection_ready_msg &&
	      id != channel::subscription_info_msg &&
	      id != channel::unsubscription_info_msg &&
	      id != channel::publication_info_msg &&
	      id != channel::unpublication_info_msg 
	      ) {
	    translator_->translate_outward(id);
	  }
	  //check pub/unpub, sub/unsub msgs
	  pubsub_info_msg_t *info = (pubsub_info_msg_t *)msg.get();
	  bool need_send = false;
	  if (id == channel::subscription_info_msg) {
	    for(size_t i=0; i<info->msg_types.size() && !need_send; i++) {
	      if (filter_ != NULL && filter_->block_inward(info->msg_types[i]))
		continue;
	      if (named_outs_.find(info->msg_types[i]) == NULL) {
		need_send = true;
	      }
	    }
	  } 
	  else if (id == channel::unsubscription_info_msg) {
	    for(size_t i=0; i<info->msg_types.size() && !need_send; i++) {
	      named_out *no;
	      if ((no = named_outs_.find(info->msg_types[i])) != NULL) {
		if (no->num_bindings() == 0)
		  need_send = true;
	      }
	    }
	  }
	  else if (id == channel::publication_info_msg) {
	    for(size_t i=0; i<info->msg_types.size() && !need_send; i++) {
	      if (filter_ != NULL && filter_->block_outward(info->msg_types[i]))
		continue;
	      if (named_ins_.find(info->msg_types[i]) == NULL) {
		need_send = true;
	      }
	    }
	  }
	  else if (id == channel::unpublication_info_msg) {
	    for(size_t i=0; i<info->msg_types.size() && !need_send; i++) {
	      named_in *ni;
	      if ((ni = named_ins_.find(info->msg_types[i])) != NULL) {
		if (ni->num_bindings() == 0)
		  need_send = true;
	      }
	    }
	  } else { //applicaion msgs
	    need_send = true;
	  }
	  
	  if(need_send)
	    peer_send(id, msg, sz, timeout);
	}
      }

      ///called by peers, forward msgs from outside peer to channel
      void send(id_type id, boost::shared_ptr<void> msg, int sz, timeout_type *timeout=0)
      {
	platform::log("interface::send_msg: recv MSG ["+id_trait::id_to_string(id)+"]...\n");
	pubsub_info_msg_t *subinfo;
      
	/// --- connection setup hand-shaking ----
	if (id == channel::channel_conn_msg) {
	  //connector or stream should already intercept this msg for its own internal
	  //processing, such as connection management; here we forward it to subscribed
	  //user code
	  switch(this->role_) {
	  case peer_type::active_role: 
	    platform::log("active end recv channel_info_msg ...\n");
	    send2remote_init_subscribe_msg();
	    break;
	  case peer_type::passive_role:
	    platform::log("passive end recv channel_info_msg ...\n");
	    ///send my chan info
	    send2remote_channel_info_msg();
	    break;
	  default:
	    break;
	  }
	}
	else if(id == channel::channel_disconn_msg) {
	  //connector or stream should already intercept this msg for its own internal
	  //processing, such as connection management; here we forward it to subscribed
	  //user code
	}
	else if (id == channel::init_subscription_info_msg) {
	  platform::log("recv init_subscription_info_msg...\n");
	  subinfo = (pubsub_info_msg_t *)msg.get();
	  std::vector<id_type> pub_msgs;
	  ch_.bound_ids_for_out(name::exported_name, pub_msgs);
	  for(size_t i=0; i<subinfo->msg_types.size(); i++) {
	    if (filter_ != NULL && filter_->block_outward(subinfo->msg_types[i]))
	      continue;
	    if(std::find_if(pub_msgs.begin(), pub_msgs.end(), 
			    boost::bind(&id_trait::match, _1, subinfo->msg_types[i])) != 
	       pub_msgs.end()) {
	      platform::log("remote subsc to ["+id_trait::id_to_string(subinfo->msg_types[i])+"]\n");
	      named_ins_.bind(subinfo->msg_types[i], name_base::scope_local);
	      send2remote_pubsub_msg (name_base::bind_out_ev, subinfo->msg_types[i]);
	    }
	  }
	  if(this->role_ == peer_type::passive_role) {     
	    ///send my subscription info
	    send2remote_init_subscribe_msg();	
	  } else if(this->role_ == peer_type::active_role) {
	    send2remote_conn_ready_msg();
	  }
	} else if (id == channel::connection_ready_msg) {
	  platform::log("recv conn_ready...");
	  platform::log((this->role_ == peer_type::active_role)?"i am active\n":"i am passive\n");
	  state_ = intf_active;
	  platform::log("conn active now...");
	  resend_pending_msgs();
	  if (this->role_ == peer_type::passive_role) {
	    send2remote_conn_ready_msg();
	  }
	}
	/// --- name_space change msgs during normal operations ---
	///init_sub_msgs
	else if (id == channel::subscription_info_msg) {
	  platform::log("recv subscription_info_msg ...\n");
	  subinfo = (pubsub_info_msg_t *)msg.get();
	  std::vector<id_type> global_msgs;
	  ch_.bound_ids_for_out(name::exported_name, global_msgs);
	  for(size_t i=0; i<subinfo->msg_types.size(); i++) {
	    if (filter_ != NULL && filter_->block_outward(subinfo->msg_types[i]))
	      continue;
	    if (named_ins_.find(subinfo->msg_types[i]) == NULL) {
	      if(std::find_if(global_msgs.begin(), global_msgs.end(), 
			      boost::bind(&id_trait::match, _1, subinfo->msg_types[i])) != 
		 global_msgs.end()) {
		platform::log("remote subsc to ["+id_trait::id_to_string(subinfo->msg_types[i])+"]\n");
		if(named_ins_.bind(subinfo->msg_types[i], name_base::scope_local))
		  send2remote_pubsub_msg (name_base::bind_out_ev, subinfo->msg_types[i]);
	      }
	    }
	  }
	}
	else if (id == channel::unsubscription_info_msg) {
	  platform::log("recv unsubscription_info_msg...\n");
	  subinfo = (pubsub_info_msg_t *)msg.get();
	  for(size_t i=0; i<subinfo->msg_types.size(); i++) {
	    if(named_ins_.unbind(subinfo->msg_types[i]))
	      send2remote_pubsub_msg (name_base::unbind_out_ev, subinfo->msg_types[i]);
	  }
	}
	else if (id == channel::publication_info_msg) {
	  platform::log("recv publication_info_msg...\n");
	  pubsub_info_msg_t *pubinfo = (pubsub_info_msg_t *)msg.get();
	  std::vector<id_type> mtypes;
	  ch_.bound_ids_for_in(name::exported_name, mtypes);
	  for(size_t i=0; i<pubinfo->msg_types.size(); i++) {
	    if (filter_ != NULL && filter_->block_inward(pubinfo->msg_types[i]))
	      continue;
	    if (named_outs_.find (pubinfo->msg_types[i]) == NULL) {
	      if(std::find_if(mtypes.begin(), mtypes.end(), 
			      boost::bind(&id_trait::match, _1, pubinfo->msg_types[i])) != 
		 mtypes.end()) {
		platform::log("remote pub msg ["+id_trait::id_to_string(pubinfo->msg_types[i])+"]\n");
		///remote msgs only for local destinations
		if(named_outs_.bind (pubinfo->msg_types[i], name_base::scope_local))
		  send2remote_pubsub_msg(name_base::bind_in_ev, pubinfo->msg_types[i]);
	      }
	    }
	  }
	}
	else if (id == channel::unpublication_info_msg) {
	  platform::log("recv unpublication_info_msg...\n");
	  subinfo = (pubsub_info_msg_t *)msg.get();
	  for(size_t i=0; i<subinfo->msg_types.size(); i++) {
	    if(named_outs_.unbind(subinfo->msg_types[i]))
	      send2remote_pubsub_msg (name_base::unbind_in_ev, subinfo->msg_types[i]);
	  }
	} 
	/// --- application msgs ----
	else {
	  //application msgs go to channel
	  //translate it if set
	  if (translator_ != NULL) {
	    translator_->translate_inward(id);
	  }
	  platform::log("recv an application msg ["+id_trait::id_to_string(id)+"]\n");
	}

	///forward all msgs to local channel
	typename channel::out *no = named_outs_.find(id);
	if (no != NULL) { //exact match found
	    no->send (msg,sz,timeout);
	} else {
	  no = named_outs_.find_match(id);
	  if (id_trait::wildcard_name(no->id_))
	    no->send (id,msg,sz,timeout);
	  else
	    no->send (msg,sz,timeout);
	}
      }

      ///send owner channel info to remote
      void send2remote_channel_info_msg(void)
      {
	platform::log("send_chan_info_to_remote...\n");
	std::pair<typename peer_type::type, std::string> info = this->peer_get_info();
	boost::shared_ptr<channel_info_msg_t> msg(new channel_info_msg_t());
	msg->intf = this;
	msg->is_local = true;
	if (info.first == peer_type::remote_peer)
	  {
	    msg->is_local = false;
	    msg->host_addr = info.second;
	  }
	peer_send(channel::channel_conn_msg,msg,sizeof(channel_info_msg_t),0);
      }

    private:

      /**
       * methods handling msg buffering before remote connection is ready
       */
      void add_pending_msg(boost::shared_ptr<message_type> m) { 
	typename synch_policy::scoped_lock lock(lock_);
	pending_msgs_.push_back(m);
      }
      void resend_pending_msgs(void)
      {
	if(this->peer_ != NULL) {
	  typename synch_policy::scoped_lock lock(lock_);
	  for(size_t i=0; i<pending_msgs_.size();i++) {
	    boost::shared_ptr<message_type> m = pending_msgs_[i];
	    peer_send(m->id_,m->data_,m->size_,0);
	    platform::log("...resend 1 msg\n");
	  }
	  pending_msgs_.clear();
	}
      }

      /* ----- */

      ///send channel conn ready msg to remote
      void send2remote_conn_ready_msg(void)
      {
	platform::log("send_conn_ready_to_remote...\n");
	std::pair<typename peer_type::type, std::string> info = this->peer_get_info();
	boost::shared_ptr<channel_info_msg_t> msg(new channel_info_msg_t());
	msg->intf = this;
	msg->is_local = true;
	if (info.first == peer_type::remote_peer)
	  {
	    msg->is_local = false;
	    msg->host_addr = info.second;
	  }
	peer_send(channel::connection_ready_msg,msg,sizeof(channel_info_msg_t),0);
      }

      ///when 2 channels just connected, send all current sub info
      ///to remote
      void send2remote_init_subscribe_msg(void)
      {
	///send subscription msg
	boost::shared_ptr<pubsub_info_msg_t> sub(new pubsub_info_msg_t());
	std::vector<id_type> mtypes;
	ch_.bound_ids_for_in(name::exported_name, mtypes);
	for(size_t i=0; i<mtypes.size(); i++) {
	  if (filter_ != NULL && filter_->block_inward(mtypes[i]))
	    continue;
	  sub->msg_types.push_back(mtypes[i]);
	}
	platform::log("send init_subscription info...\n"); 
	peer_send(channel::init_subscription_info_msg, sub, sizeof(pubsub_info_msg_t), 0);
      }

      ///forward local/owner channel memebers' pub/sub operations to remote
      void send2remote_pubsub_msg(typename name_base::binding_event op, id_type t)
      {
	boost::shared_ptr<pubsub_info_msg_t> sub(new pubsub_info_msg_t());
	sub->msg_types.push_back(t);
	id_type mt;
	switch(op) {
	case name_base::bind_out_ev:
	  if (filter_ != NULL && filter_->block_outward(t)) {
	    return;
	  }
	  mt = channel::publication_info_msg;
	  platform::log("interface::send2remote_pubsub_msg publish ");
	  break;
	case name_base::unbind_out_ev:
	  mt = channel::unpublication_info_msg;
	  platform::log("interface::send2remote_pubsub_msg unpublish ");
	  break;
	case name_base::bind_in_ev:
	  if (filter_ != NULL && filter_->block_inward(t)) {
	    return;
	  }
	  mt = channel::subscription_info_msg;
	  platform::log("interface::send2remote_pubsub_msg subscribe ");
	  break;
	case name_base::unbind_in_ev:
	  mt = channel::unsubscription_info_msg;
	  platform::log("interface::send2remote_pubsub_msg unsubscribe ");
	  break;
	default:
	  platform::log("interface::send2remote_pubsub_msg invalid id_type ");
	  return ;
	}
	peer_send(mt, sub, sizeof(pubsub_info_msg_t), 0);
      }
    };

  }
}

#endif
