////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef FLOW_CONTROLLED_QUEUE_HPP
#define FLOW_CONTROLLED_QUEUE_HPP

#include <deque>

namespace boost {
  namespace channel {

    /**
     * flow controled queue: follow the design of ACE Message_Queue:
     * 1. flow is controlled thru high/low water marks
     * 2. support priorities of enque and deque
     */
    template <typename elem_type, typename synch_policy, typename timeout_type>
    class flow_controlled_que {
    public:
    };
  }
}

#endif

 
