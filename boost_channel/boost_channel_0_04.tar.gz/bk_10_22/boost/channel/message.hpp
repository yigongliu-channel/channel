////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef MESSAGE_HPP
#define MESSAGE_HPP

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/vector.hpp>

namespace boost {
  namespace channel {

    template<typename id_type>
    struct message {
      id_type id_;
      int size_;
      boost::shared_ptr<void> data_;
      message(id_type id, boost::shared_ptr<void> d, int s):
	id_(id), size_(s), data_(d)  {}
      message() {}
    };

    /**
     * Channel Management Msg types
     */
    ///when 2 channels connects, channel_info_msg is sent to tell
    ///peers about the channel info
    struct channel_info_msg_t {
      std::string host_addr;
      void *intf;  ///the interface connect to peer
      bool is_local;
      channel_info_msg_t() {
	intf = NULL;
	is_local = false;
      }
      
      template <class Archive>
      void serialize(Archive & ar, const unsigned int version)
      {
	ar & host_addr;
      }
     
    };

    ///pubsub_info_msg is used to notify peer channels about
    ///publish/subscribe events
    template <class id_type>
    struct pubsub_info_msg_t {
      std::vector<id_type> msg_types;
      pubsub_info_msg_t() {
      }
     
      template <class Archive>
      void serialize(Archive & ar, const unsigned int version)
      {
	ar & msg_types;
      }
   
    };
  }
}

#endif
