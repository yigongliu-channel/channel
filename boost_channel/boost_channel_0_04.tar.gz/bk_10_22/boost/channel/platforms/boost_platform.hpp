////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_PLATFORM_HPP
#define BOOST_PLATFORM_HPP

#include <iostream>
#include <string>
#include <boost/thread.hpp>
#include <boost/channel/platforms/null_mutex.hpp>
#include <boost/channel/platforms/null_condition.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

namespace boost {
  namespace channel {

    class boost_platform {
    public:
      //synch primitive
      typedef detail::null_mutex null_mutex;
      typedef detail::null_condition null_condition;    
      //typedef boost::mutex mutex;
      typedef boost::recursive_mutex mutex;
      typedef boost::condition condition;       
      //timeout
      typedef boost::posix_time::time_duration timeout_type;
      //log
      static void log(std::string info) {
	std::cout << "log << " << info << " >>" << std::endl;
      }
    };

  }
}

#endif
