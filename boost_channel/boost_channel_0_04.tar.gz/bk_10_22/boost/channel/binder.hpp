////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef BINDER_HPP
#define BINDER_HPP

namespace boost {
  namespace channel {
    /**
     * The name_space filters/translators defined here only manipulte ids/msg-types
     * and affect name_space management
     * message content is UNTOUCHED!
     */

    /**
     * filter_types: 
     * 1. provision the permissions which messages/ids can flow in/out 
     *    channel thru interfaces
     * 2. ONLY works on sub/pub msgs, not other(application) msgs
     *    affect how sub/pub msgs are exchanged between local channel and
     *    remote channel - how remote and local name_spaces "merge"
     *    not affect the normal message passing process
     * 3. Default filter_types are "transparent" - all Ids allowed in/out:
     *    
     */
    template <class id_type, class id_trait>
    class filter_type {
    public:
      virtual bool block_inward (id_type&) {
	return false;
      }
      virtual bool block_outward (id_type&) {
	return false;
      }
      virtual ~filter_type() {}
    };

    /**
     * translator_type:
     * 1. translate inward/outward msg ids, help integration of name_spaces
     * 2. ONLY works on application msgs
     *    affect (potentially change) each msgs passed in/out interfaces - 
     *    must be highly efficient
     * 3. Default translator_type is non-op
     */
    template <class id_type, class id_trait>
    class translator_type {
    public:
      virtual void translate_inward (id_type&) { 
      }
      virtual void translate_outward (id_type &id) { 
      }
      virtual ~translator_type() {}
    };

    /**
     * binder_type:
     * 1. affect ONLY the interface - the "binding" point between local
     *    channel and remote connections
     * 2. contains both filter and transltor
     * 3. if filters/translators are NULL, they are no-op
     */
    template <class id_type, class id_trait>
    class binder_type {
    public:
      typedef filter_type<id_type, id_trait> filter_type;
      typedef translator_type<id_type, id_trait> translator_type;
      filter_type *filter;
      translator_type *translator;
      binder_type (filter_type *f = NULL, translator_type *t = NULL) {
	filter = f;
	translator = t;
      }
    };

  }
}

#endif

