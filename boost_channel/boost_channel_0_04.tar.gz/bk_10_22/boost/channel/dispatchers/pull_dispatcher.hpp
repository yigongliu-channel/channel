////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#ifndef PULL_DISPATCHER_HPP
#define PULL_DISPATCHER_HPP

#include <boost/channel/queues/unbounded_queue.hpp>
#include <boost/channel/dispatchers/pull_dispatcher_base.hpp>
#include <boost/channel/dispatchers/arbiters_async.hpp>
#include <boost/channel/dispatchers/arbiters_sync.hpp>

namespace boost {
  namespace channel {

    template <typename name_space, typename platform, 
	      template <class,class,class> class queue_type = unbounded_que>
    struct pull_dispatcher {
      typedef detail::pull_sender_base<name_space,platform,queue_type> sender;
      typedef detail::pull_recver_base<name_space,platform,queue_type> recver;
      typedef detail::choice_arbiter_async<name_space,platform,queue_type> choice_async;
      typedef detail::join_arbiter_async<name_space,platform,queue_type> join_async;
      typedef detail::choice_arbiter_sync<name_space,platform,queue_type> choice_sync;
      typedef detail::join_arbiter_sync<name_space,platform,queue_type> join_sync;
    };

  }
}

#endif
