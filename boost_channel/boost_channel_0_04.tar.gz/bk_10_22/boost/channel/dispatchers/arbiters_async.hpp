////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


#ifndef ARBITERS_ASYNC_HPP
#define ARBITERS_ASYNC_HPP

#include <deque>
#include <map>
#include <vector>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>
#include <boost/channel/queues/unbounded_queue.hpp>
#include <boost/channel/dispatchers/pull_dispatcher_base.hpp>

namespace boost {
  namespace channel {
    namespace detail {

      /**
       * Async arbiters:
       * asynch message passing synchronization patterns (choice, join)
       * part of pull_dispatcher
       * see CCR and Comega document
       */
      /**
       * choice
       */
      template <typename name_space, typename platform, 
		template <class,class,class> class queue_type = unbounded_que>
      class choice_arbiter_async {
      public:
	typedef pull_recver_base<name_space,platform,queue_type> recver_type;
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef named_in<name_space, recver_type> named_in_type;
	typedef choice_arbiter_async<name_space,platform,queue_type> my_type;

	typedef boost::function1<void, boost::shared_ptr<void> > call_back_t;
      
	name_space &ch_;
	executor *exec_;
	struct entry {
	  named_in_type *in_;
	  call_back_t handler_;
	};
	std::map<id_type, entry> bind_map_;
	typename synch_policy::mutex mutex_;

	choice_arbiter_async(name_space &ch, executor *e = NULL) :
	  ch_(ch),
	  exec_(e!=NULL?e:ch.get_exec()) {}

	~choice_arbiter_async() {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::map<id_type, entry>::iterator iter;
	  for (iter = bind_map_.begin(); iter != bind_map_.end(); iter++)
	    if (iter->second.in_ != NULL) {
	      delete iter->second.in_;
	    }
	}

	//called from inside dispatcher
	void invoke(id_type id) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::map<id_type, entry>::iterator iter = bind_map_.find(id);
	  if (iter != bind_map_.end()) {
	    named_in_type *in = iter->second.in_;
	    if(in->claim()) {
	      boost::shared_ptr<msg_type> msg;
	      if (in->pull(msg) > 0) {
		//successfully get a msg here, should we use executor to run callback?
		//since invoke already run in executor, so dont delay again
		iter->second.handler_(msg->data_);
	      }
	    }
	  }
	}

	bool bind(id_type & id, 
		  call_back_t cb,
		  typename named_in_type::scope_type scope = named_in_type::scope_global) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  if (bind_map_.find(id) == bind_map_.end()) {
	    entry ent;
	    ent.in_ = new named_in_type(ch_,id,
					boost::bind(&my_type::invoke, this, _1),
					scope,named_in_type::member_local,exec_);
	    ent.handler_ = cb;
	    bind_map_[id] = ent;
	    return true;
	  }
	  return false;
	}

	bool unbind(id_type & id) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::map<id_type, entry>::iterator iter = bind_map_.find(id);
	  if (iter != bind_map_.end()) {
	    delete iter->second.in_;
	    bind_map_.erase(iter);
	    return true;
	  }
	  return false;
	}
      
      };

      /**
       * join
       */
      template <typename name_space, typename platform, 
		template <class,class,class> class queue_type = unbounded_que>
      class join_arbiter_async {
      public:
      public:
	typedef pull_recver_base<name_space,platform,queue_type> recver_type;
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef named_in<name_space, recver_type> named_in_type;
	typedef join_arbiter_async<name_space,platform,queue_type> my_type;
      
	typedef boost::function1<void, std::vector<boost::shared_ptr<void> >& > call_back_t;
      
	name_space &ch_;
	executor *exec_;
	call_back_t handler_;
	std::deque<named_in_type*> ins_;
	std::map<id_type, named_in_type*> ins_map_; //keep locking order
	typename synch_policy::mutex mutex_;

	join_arbiter_async(name_space &ch, 
		     std::vector<std::pair<id_type, typename named_in_type::scope_type> > & ids,
		     call_back_t cb,
		     executor *e = NULL) :
	  ch_(ch),
	  exec_(e!=NULL?e:ch.get_exec()),
	  handler_(cb) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::vector<std::pair<id_type, 
			typename named_in_type::scope_type> >::iterator iter;
	  for(iter = ids.begin(); iter != ids.end(); iter++) {
	    named_in_type * ni = new named_in_type(ch_,iter->first,
						   boost::bind(&my_type::invoke, this, _1),
						   iter->second,
						   named_in_type::member_local,exec_);
	    ins_.push_back(ni); //keep order to avoid deadlock
	    ins_map_[iter->first] = ni;
	  }
	}

	join_arbiter_async(name_space &ch, 
		     call_back_t cb,
		     executor *e = NULL) :
	  ch_(ch),
	  exec_(e!=NULL?e:ch.get_exec()),
	  handler_(cb) {
	}

	~join_arbiter_async() {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::deque<named_in_type*>::iterator iter;
	  for (iter = ins_.begin(); iter != ins_.end(); iter++)
	    delete (*iter);
	}

	//called from inside dispatcher
	//2 phase protocol
	void invoke(id_type) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::deque<named_in_type*>::iterator iter;
	  //first claim the messages in proper order based on ids to avoid deadlock
	  for (typename std::map<id_type,named_in_type*>::iterator iter1 = ins_map_.begin(); iter1 != ins_map_.end(); iter1++) {
	    named_in_type *in = iter1->second;
	    if(!in->claim()) {
	      //roll back
	      for (typename std::map<id_type,named_in_type*>::iterator iter2 = ins_map_.begin(); 
		   iter2 != iter1; iter2++) 
		iter2->second->unclaim();
	      return;
	    }
	  }
	  //reaching here, we have claimed all the member messages, 
	  //commit (pull msgs and run callback)
	  boost::shared_ptr<msg_type> msg;
	  std::vector<boost::shared_ptr<void> > result;
	  for (iter = ins_.begin(); iter != ins_.end(); iter++) {
	    named_in_type *in = (*iter);
	    msg.reset();
	    in->pull(msg);
	    result.push_back(msg->data_);
	  }
	  handler_(result);
	}

	bool bind(id_type & id, 
		  typename named_in_type::scope_type scope = named_in_type::scope_global) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::deque<named_in_type*>::iterator iter;
	  for(iter = ins_.begin(); iter != ins_.end(); iter++) 
	    if ((*iter)->id_ == id) 
	      return false;
	  named_in_type * ni = new named_in_type(ch_,id,
						 boost::bind(&my_type::invoke, this, _1),
						 scope,
						 named_in_type::member_local,exec_);
	  ins_.push_back(ni); //keep order to avoid deadlock
	  ins_map_[id] = ni;
	  return true;
	}

	bool unbind(id_type & id) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  typename std::deque<named_in_type*>::iterator iter;
	  for(iter = ins_.begin(); iter != ins_.end(); iter++) 
	    if ((*iter)->id_ == id) {
	      ins_map_.erase(id);
	      delete (*iter);
	      ins_.erase(iter);
	      return true;
	    }
	  return false;
	}
      };

    }
  }
}

#endif
