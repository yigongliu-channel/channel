////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef EXECUTOR_HPP
#define EXECUTOR_HPP

#include <boost/thread.hpp>
#include <boost/asio.hpp>

namespace boost {
  namespace channel {

    //async tasks: to be later executed in executor:
    //1. although in same thread, not in orginal calling context
    //2. in diff thread
    class async_task_base
    {
    public:
      enum state {
	waiting,
	running,
	completed
      };

      // Perform the task.
      void execute()
      {
	st_ = running;
	exec_func_(this);
	st_ = completed;
      }

      // Destroy the task.
      void destroy()
      {
	destroy_func_(this);
      }

    protected:
      typedef void (*exec_func_type)(async_task_base*);
      typedef void (*destroy_func_type)(async_task_base*);

      // Construct an task 
      async_task_base(exec_func_type exec_func,
		      destroy_func_type destroy_func)
	: exec_func_(exec_func),
	  destroy_func_(destroy_func),
	  st_(waiting)
      {
      }

      // Prevent deletion through this type.
      ~async_task_base()
      {
      }

    private:
      exec_func_type exec_func_;
      destroy_func_type destroy_func_;
      state st_;
    };

    // 
    template <typename task_type>
    class async_task
      : public async_task_base
    {
    public:
      // Constructor.
      async_task(task_type task)
	: async_task_base(&async_task<task_type>::exec_task,
			  &async_task<task_type>::destroy_task),
	  task_(task)
      {
      }

      // Invoke the task.
      static void exec_task(async_task_base* base)
      {
	static_cast<async_task<task_type>*>(base)->task_();
      }

      // Delete the task.
      static void destroy_task(async_task_base* base)
      {
	delete static_cast<async_task<task_type>*>(base);
      }

    private:
      task_type task_;
    };

    //define an abstract class, so that it cannt be
    //instantiated and execution must be in-line;
    //or it can provide a base class for dynamic
    //polymorphism of executors;
    class abstract_executor {
    public:
      template <typename task_type>
      async_task_base * execute(task_type task) { return NULL; }
      virtual bool cancel(async_task_base *task) = 0;
      virtual ~abstract_executor() {}
    };

    //the simplest: execute async_task in place: ie. in current thread & calling context
    class in_place_executor {
    public:
      template <typename task_type>
      void execute(task_type task) {
	task();
      }
    };

    //in single-thread async app: operations can be delayed:
    //executed later by the same (single) thread, the original calling context is gone
    class delayed_executor {
    public:
      template <typename task_type>
      void execute(task_type task) {
      }
    };

    //submit async tasks to asio's completion_event queue to be executed by main thread
    class asio_executor {
    public:
      boost::asio::io_service& io_service_;
      asio_executor(boost::asio::io_service& io_service): io_service_(io_service) {}
      template <typename task_type>
      void execute(task_type task) {
	io_service_.post(task);	
      }
    };

    //a dedicated pool of threads to exec async tasks
    class thread_pool_executor {
    public:
      enum state {
	init,
	running,
	shutting_down,
	terminated
      };

      ///executor life cycle
      state get_state(void) {
	return st_;
      }

      //gracefully shut down
      void shut_down_wait() {
      }

      //abruptively shut down
      void shut_down_now() {
      }

      ///submit and cancel a task
      template <typename task_type>
      async_task_base * execute(task_type task) {
	return NULL;
      }
      
      bool cancel(async_task_base *task) {
	return true;
      }

    private:
      state st_;
    };

  }
}

#endif

