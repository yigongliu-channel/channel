////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef PEER_HPP
#define PEER_HPP

#include <string>
#include <boost/shared_ptr.hpp>

namespace boost {
  namespace channel {

    template <typename,typename> class connection;

    template <typename id_type, typename timeout_type>
    class peer_type {
    public:
      typedef connection<id_type, timeout_type> connection;
      enum type {
	local_peer = 0,
	remote_peer
      };
      enum role {
	undefined_role,
	active_role,  //i start connection setup process
	passive_role, //i wait for others to connect
      };

      void bind_peer(peer_type *p, role r, connection *c)
      {
	peer_ = p;
	role_ = r;
	conn_ = c;
      }
      void unbind() {
	peer_ = 0;
	role_ = undefined_role;
	conn_ = 0;
      }
      //channel or stream should call release to disconn and cleanup
      void release(void) {
	delete conn_; //connection destructor responsible for deleting all 
      }

      peer_type() : peer_(0), role_(undefined_role), conn_(0) {}
      virtual ~peer_type() {}

      std::pair<type,std::string> peer_get_info(void) {
	return peer_->get_info();
      }
      void peer_send(id_type id, shared_ptr<void> msg, int sz, timeout_type *timeout=0)
      {
	peer_->send(id,msg,sz,timeout);
      }

      //stream should override get_info to provide transport info (e.g. host/port..)
      virtual std::pair<type,std::string> get_info(void) {
	std::pair<type,std::string> info;
	info.first = local_peer;
	info.second = "";
	return info;
      }

      //concrete peer types (streams, interface) should override this
      virtual void send(id_type id, shared_ptr<void> msg, int sz, timeout_type *timeout=0) = 0;

    protected:
      peer_type *peer_;
      role role_;
      connection *conn_;
    };

  }
}

#endif
