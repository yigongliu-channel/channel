
#ifndef BOOST_CHANNEL_DETAIL_NULL_EVENT_HPP
#define BOOST_CHANNEL_DETAIL_NULL_EVENT_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)

#include <boost/utility.hpp>

namespace boost {
  namespace channel {
    namespace detail {

      class null_event
	: private boost::noncopyable
      {
      public:
	// Constructor.
	null_event()
	{
	}

	// Destructor.
	~null_event()
	{
	}

	// Signal the event.
	void signal()
	{
	}

	// Reset the event.
	void clear()
	{
	}

	// Wait for the event to become signalled.
	void wait()
	{
	}
      };

    } // namespace detail
  } // namespace channel
} // namespace boost

#endif 
