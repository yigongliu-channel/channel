
#ifndef BOOST_CHANNEL_DETAIL_NULL_MUTEX_HPP
#define BOOST_CHANNEL_DETAIL_NULL_MUTEX_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)

#include <boost/utility.hpp>
#include <boost/asio/detail/scoped_lock.hpp>

namespace boost {
  namespace channel {
    namespace detail {

      class null_mutex
	: private boost::noncopyable
      {
      public:
	typedef boost::asio::detail::scoped_lock<null_mutex> scoped_lock;

	// Constructor.
	null_mutex()
	{
	}

	// Destructor.
	~null_mutex()
	{
	}

	// Lock the mutex.
	void lock()
	{
	}

	// Unlock the mutex.
	void unlock()
	{
	}
      };

    } // namespace detail
  } // namespace channel
} // namespace boost

#endif
