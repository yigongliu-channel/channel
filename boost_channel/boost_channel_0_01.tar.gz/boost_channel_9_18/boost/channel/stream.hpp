////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef STREAM_H
#define STREAM_H

namespace boost {
  namespace channel {

    //a stream interface to wrap an asio sock
    template <typename id_type, typename timeout_type>
    class asio_sock_stream : public peer_type<id_type, timeout_type>
    {
      typedef peer_type<id_type, timeout_type> peer_type;
      //stream override get_info to provide transport info (e.g. host/port..)
      std::pair<typename peer_type::type,std::string> get_info(void) {
	std::pair<typename peer_type::type,std::string> info;
	info.first = peer_type::remote_peer;
	info.second = "";
	return info;
      }

      //send data to transport
      void send(id_type id, shared_ptr<void> msg, int sz, timeout_type *timeout=0) {
      }

    };

  }
}


#endif





