////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


//// dispatchers:
//// define the whole message passing process:
//// including:
////   . sending, buffering, recving
////   . provide both sender/recver sides

#ifndef DISPATCHER_HPP
#define DISPATCHER_HPP

#include <map>
#include <vector>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/channel/synch_policy.hpp>
#include <boost/channel/message.hpp>
#include <boost/channel/name.hpp>
#include <boost/channel/named_in_out.hpp>

namespace boost {
  namespace channel {

    namespace detail {

      //message handlers
      template <typename id_type, typename timeout_type>
      class msg_handler_base
      {
      public:
	// Perform the operation.
	void invoke(id_type id, boost::shared_ptr<void> msg, int sz,
		    timeout_type *t)
	{
	  invoke_func_(this, id, msg, sz, t);
	}

	// Destroy the operation.
	void destroy()
	{
	  destroy_func_(this);
	}

      protected:
	typedef void (*invoke_func_type)(msg_handler_base*, id_type id, boost::shared_ptr<void> msg, int sz, timeout_type *t);
	typedef void (*destroy_func_type)(msg_handler_base*);

	// Construct an operation for the given descriptor.
	msg_handler_base(invoke_func_type invoke_func,
			 destroy_func_type destroy_func)
	  : invoke_func_(invoke_func),
	    destroy_func_(destroy_func)
	{
	}

	// Prevent deletion through this type.
	~msg_handler_base()
	{
	}

      private:
	// The function to be called to dispatch the handler.
	invoke_func_type invoke_func_;

	// The function to be called to delete the handler.
	destroy_func_type destroy_func_;
      };

      // Adaptor class template for using handlers in operations.
      template <typename id_type, typename timeout_type, typename handler_type>
      class msg_handler
	: public msg_handler_base<id_type, timeout_type>
      {
	typedef msg_handler_base<id_type, timeout_type> msg_handler_base;
      public:
	// Constructor.
	msg_handler(handler_type handler)
	  : msg_handler_base(&msg_handler<id_type, timeout_type, handler_type>::invoke_handler,
			     &msg_handler<id_type, timeout_type, handler_type>::destroy_handler),
	    handler_(handler)
	{
	}

	// Invoke the handler.
	static void invoke_handler(msg_handler_base* base, id_type id, 
				   boost::shared_ptr<void> msg, 
				   int sz, timeout_type *t)
	{
	  static_cast<msg_handler<id_type, timeout_type, handler_type>*>(base)->handler_(id, msg, sz, t);
	}

	// Delete the handler.
	static void destroy_handler(msg_handler_base* base)
	{
	  delete static_cast<msg_handler<id_type, timeout_type ,handler_type>*>(base);
	}

      private:
	handler_type handler_;
      };


      //base sender class, shared by most push dispatchers
      template <typename name_space, typename platform, template<typename,typename> class sending_algo>
      struct push_sender_base {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;

	name_type * name_;
	executor *exec_;
	sending_algo<name_space, platform> algo;

	push_sender_base(name_type * n, executor *e) : name_(n), exec_(e) { }

	//assuming msgs contained inside shared_ptr
	void push(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) {
	  typename synch_policy::scoped_lock lock(name_->bind_lock_);
	  typename name_type::binding_set_type &bindings = name_->bindings_;
	  algo(bindings, msg, timeout);
	}

	//after sending, channel becomes owner
	template <typename user_msg_type>
	void send(user_msg_type *msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  push (m, timeout);
	}

	//after sending: 1> channel becomes owner, if deleter does real deletion
	// 2> sender still owns msg, if deleter does nothing
	template <typename user_msg_type, typename deleter>
	void send(user_msg_type *msg, deleter deler, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg, deler);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  push (m, timeout);
	}

	//user_msg is already smarter pointer, channel becomes owner
	template <typename user_msg_type>
	void send(boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  push (m, timeout);
	}

	//for channel internal use on wildcard named_out
	template <typename user_msg_type>
	void send(id_type id, boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(id, m0, sz));
	  push (m, timeout);
	}

      };

      //base recver class, shared by most push dispatchers
      template <typename name_space, typename platform>
      struct push_recver_base {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef name<id_type,executor,synch_policy> name_type;

	name_type * name_;
	executor *exec_;
	msg_handler_base<id_type, timeout_type> *recver_;
      
	template<typename recver_type>
	push_recver_base(name_type * n, recver_type rc, executor *e) : 
	  name_(n), exec_(e)
	{
	  recver_ = new msg_handler<id_type, timeout_type, recver_type>(rc);
	}

	~push_recver_base() { 
	  if (recver_ != NULL)
	    recver_->destroy(); 
	}

	template<typename recver_type>
	void set_recver(recver_type rc) { 
	  if (recver_ != NULL) recver_->destroy(); 
	  recver_ =  new msg_handler<id_type, timeout_type, recver_type>(rc);
	}

	//senders call this to push into here
	void push(boost::shared_ptr<msg_type> msg, timeout_type *timeout)
	{
	  if (exec_ != NULL) //run recv_handler in executor
	    exec_->execute(boost::bind(&msg_handler_base<id_type, timeout_type>::invoke,
					recver_,msg->id_, msg->data_, msg->size_, timeout));
	  else //run recv_handler in place
	    recver_->invoke(msg->id_, msg->data_, msg->size_, timeout);
	}

      };

      //the following is for 3 simple "push" dispatchers: broadcast, roundrobin, union
      template <typename name_space, typename platform>
      struct broadcast_algo {
	typedef typename name_space::id_type id_type;
	typedef message<id_type> msg_type;
	typedef typename platform::timeout_type timeout_type;
	typedef push_recver_base<name_space,platform> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	template<typename bindings_type>
	void operator() (bindings_type &bindings, 
			 boost::shared_ptr<msg_type> msg, timeout_type *timeout) {
	  if (!bindings.empty()) {
	    for(typename bindings_type::iterator iter = bindings.begin();
		iter != bindings.end(); iter++) {
	      named_in_type *named_in = (named_in_type *)(*iter);
	      recver_type *recver = (recver_type *)named_in;
	      recver->push(msg,timeout);
	    }
	  }
	}
      };

      //we need random-access iterator for roundrobin? 
      //here a temp fix: convert set<name*> to vector<name*>
      //for a namespace targeted for round_robin dispatching app,
      //we should change namespace container type to vector instead of set
      //or make namespace container type configurable?
      template <typename name_space, typename platform>
      class round_robin_algo {
      public:
	typedef typename name_space::id_type id_type;
	typedef message<id_type> msg_type;
	typedef typename platform::timeout_type timeout_type;
	typedef push_recver_base<name_space,platform> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	round_robin_algo(): last_(-1) {}
	template<typename bindings_type>
	void operator() (bindings_type &bindings, 
			 boost::shared_ptr<msg_type> msg, timeout_type *timeout) {
	  if (!bindings.empty()) {
	    std::vector<typename bindings_type::value_type> v(bindings.begin(), bindings.end());
	    int sz = v.size();
	    last_ = (last_+1) % sz;
	    named_in_type *named_in = (named_in_type *)(v[last_]);
	    recver_type *recver = (recver_type *)named_in;
	    recver->push(msg, timeout);
	  }
	}
      private:
	int last_;
      };

      //imitate plan9/inferno's "union" namespace:
      //later bound names will overlap older names, ie. latest mounted server will
      //take over and serve all msgs on the covered names
      //so always the latest bound name get dispatched
      template <typename name_space,typename platform>
      struct always_1st_algo {
	typedef typename name_space::id_type id_type;
	typedef message<id_type> msg_type;
	typedef typename platform::timeout_type timeout_type;
	typedef push_recver_base<name_space,platform> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	template<typename bindings_type>
	void operator() (bindings_type &bindings, 
			 boost::shared_ptr<msg_type> msg, timeout_type *timeout) {
	  if (!bindings.empty()) {
	    typename bindings_type::iterator iter = bindings.begin();
	    named_in_type *named_in = (named_in_type *)(*iter);
	    recver_type *recver = (recver_type *)named_in;
	    recver->push(msg,timeout);
	  }
	}
      };

      /**
       * some pull dispatchers: buffering/linda, join
       */
      /*
      //base sender class, shared by most dispatchers
      template <typename name_space, typename platform, typename msg_queue_type>
      struct pull_sender_base {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef typename pull_recver_base<name_space, platform> recver_type;

	name_type * name_;
	sending_algo algo;
	synch_policy::mutex q_lock_;
	msg_queue_type<boost::shared_ptr<msg_type> > que_;

	pull_sender_base(name_type *n) : name_(n) { }

	//assuming msgs contained inside shared_ptr
	void notify(boost::shared_ptr<msg_type> msg, timeout_type timeout=0) {
	  {
	    typename synch_policy::scoped_lock qlock(q_lock_);
	    que_.put(msg);
	  }
	  typename synch_policy::scoped_lock lock(name_->bind_lock_);
	  binding_set_type &bindings = name_->bindings_;
	  if (!bindings.empty()) {
	    for(typename bindings_type::iterator iter = bindings.begin();
		iter != bindings.end(); iter++) {
	      recver_type *recver = static_cast<recver_type *>(*iter);
	      recver->notify();
	    }
	  }
	}

	//recvers will call this to retrv/pull data
	int pull(boost::shared_ptr<msg_type> & msg, timeout_type timeout=0) {
	  typename synch_policy::scoped_lock qlock(q_lock_);
	  if (!que_.empty()) {
	    msg = que_.get();
	    return msg->size_;
	  }
	  return 0;
	}

	//after sending, channel becomes owner
	template <typename user_msg_type>
	void send(user_msg_type *msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(t, m0, sz));
	  notify (m, timeout);
	}

	//after sending: 1> channel becomes owner, if deleter does real deletion
	// 2> sender still owns msg, if deleter does nothing
	template <typename user_msg_type, typename deleter>
	void send(user_msg_type *msg, deleter deler, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg, deler);
	  boost::shared_ptr<msg_type> m(new msg_type(t, m0, sz));
	  notify (m, timeout);
	}

	//user_msg is already smarter pointer, channel becomes owner
	template <typename user_msg_type>
	void send(boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(t, m0, sz));
	  notify (m, timeout);
	}

      };

      //base recver class, shared by most dispatchers
      template <typename name_space, typename platform>
      struct pull_recver_base {
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef typename pull_sender_base<name_space, platform> sender_type;

	msg_handler_base<msg_type, timeout_type> *recver_;
	name_type * name_;
      
	template<typename recver_type>
	pull_recver_base(name_type *n, recver_type rc) : name_(n) {
	  recver_ = new msg_handler<msg_type, timeout_type, recver_type>(rc);
	}

	~pull_recver_base() { 
	  if (recver_ != NULL)
	    delete recver_; 
	}

	template<typename recver_type>
	void recver(recver_type rc) { 
	  if (recver_ != NULL) delete recver_; 
	  recver_ =  new msg_handler<recver_type>(rc);
	}

	//senders call this to notify about some data coming
	//put this recver into activation list
	void notify(void) {
	}

	//poll all senders in binding_set to see if data avail
	bool poll(void) {
	  boost::shared_ptr<msg_type> msg;
	  //go-thru binding_set to poll senders
	  return true; //ready
	  return false; //not ready
	}

	//pull data from sender
	int pull(void) {
	  boost::shared_ptr<msg_type> msg;
	  //go-thru binding_set to pull from senders

	  //invoke recver with pulled data
	  recver_->invoke(msg->id_, msg->data_, msg->size_, timeout);
	}
      };
      */
    }

    template <typename name_space, typename platform>
    struct broadcast_dispatcher {
      typedef detail::push_sender_base<name_space,platform,detail::broadcast_algo> sender;
      typedef detail::push_recver_base<name_space,platform> recver;
    };

    template <typename name_space, typename platform>
    struct round_robin_dispatcher {
      typedef detail::push_sender_base<name_space,platform,detail::round_robin_algo> sender;
      typedef detail::push_recver_base<name_space,platform> recver;
    };

    template <typename name_space, typename platform>
    struct always_1st_dispatcher {
      typedef detail::push_sender_base<name_space,platform,detail::always_1st_algo> sender;
      typedef detail::push_recver_base<name_space,platform> recver;
    };

    //the following are "pull" dispatchers: buffering/linda, join

  }
}

#endif
