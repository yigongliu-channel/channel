////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <boost/channel/linear_id_trait.hpp>
#include <string>

using namespace std;
using namespace boost::channel;

/// definitions of system messages for string ids
string id_trait<string>::channel_conn_msg = "_channel_conn_msg_";
string id_trait<string>::channel_disconn_msg = "_channel_disconn_msg_";
string id_trait<string>::init_subscription_info_msg = "_init_subscription_info_msg_";
string id_trait<string>::connection_ready_msg = "_connection_ready_msg_";
string id_trait<string>::subscription_info_msg = "_subscription_info_msg_";
string id_trait<string>::unsubscription_info_msg = "_unsubscription_info_msg_";
string id_trait<string>::publication_info_msg = "_publication_info_msg_";
string id_trait<string>::unpublication_info_msg = "_unpublication_info_msg_";

/// definitions of system messages for struct ids
struct_id id_trait<struct_id>::channel_conn_msg = {system_message, 1};
struct_id id_trait<struct_id>::channel_disconn_msg = {system_message, 2};
struct_id id_trait<struct_id>::init_subscription_info_msg = {system_message, 3};
struct_id id_trait<struct_id>::connection_ready_msg = {system_message, 4};
struct_id id_trait<struct_id>::subscription_info_msg = {system_message, 5};
struct_id id_trait<struct_id>::unsubscription_info_msg = {system_message, 6};
struct_id id_trait<struct_id>::publication_info_msg = {system_message, 7};
struct_id id_trait<struct_id>::unpublication_info_msg = {system_message, 8};
