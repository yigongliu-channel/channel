////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2007 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef IN_PLACE_EXECUTOR_HPP
#define IN_PLACE_EXECUTOR_HPP

#include <boost/channel/executors/executor_base.hpp>

namespace boost {
  namespace channel {

    //the simplest: execute async_task in place: ie. in current thread & calling context
    class in_place_executor {
    public:
      template <typename task_type>
      void execute(task_type task) {
	task();
      }
    };

  }
}

#endif

