////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2007 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef ASIO_EXECUTOR_HPP
#define ASIO_EXECUTOR_HPP

#include <boost/asio.hpp>

namespace boost {
  namespace channel {

    //integration with Boost.Asio
    //submit async tasks to asio's completion_event queue to be executed by main thread
    class asio_executor {
    public:
      boost::asio::io_service& io_service_;
      asio_executor(boost::asio::io_service& io_service): io_service_(io_service) {}
      template <typename task_type>
      void execute(task_type task) {
	io_service_.post(task);	
      }
    };

  }
}

#endif

