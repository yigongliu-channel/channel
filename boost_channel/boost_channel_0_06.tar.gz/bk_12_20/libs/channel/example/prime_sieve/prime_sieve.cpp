////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/channel/channel.hpp>

using namespace std;
using namespace boost::channel;

#include <boost/channel/executors/thread_pool_executor.hpp>
typedef thread_pool_executor<mt_synch<boost_platform> > exec_type;
//use Philipp Henkel's threadpool library
//#include <boost/channel/executors/threadpool_executor.hpp>
//typedef threadpool_executor<> exec_type;

//instantiate channel type, using integer as id_type
typedef channel<
  int,
  boost_platform,
  mt_synch<boost_platform>,
  exec_type
  > chan;

//prime_task: one task to calc prime
class prime_task {
public:
  chan &ch_;
  int id_;
  int my_prime_;
  prime_task *next_;
  chan::out out_;
  chan::in in_;

  prime_task(chan &ch, int id) :
    ch_(ch), id_(id), my_prime_(-1), next_(NULL),
    out_(ch, id),
    in_(ch, id, boost::bind(&prime_task::run, this, _1, _2))
  {}
  ~prime_task() {
    cout << "prime_task [" << id_ << "] destroy " << endl;
  }

  void run(int id, boost::shared_ptr<void> p)
  {
    int val = *(int *)p.get();
    if (my_prime_ == -1) { //first time
      if (val == -1) {
	//clean up and return
	delete this;
	return;
      }
      my_prime_ = val;
      cout << "------ prime_task [" << id << "] found prime = " << val << endl;
      next_ = new prime_task(ch_, id_+1);
    } 
    else {
      if ((val % my_prime_) || val == -1) { //not my multiples
	next_->out_.send(p);
      } else { //my multiples
	cout << "prime_task [" << id << "] drop " << val << endl;
      }
      if (val == -1) {
	//clean up and return
	delete this;
      }
    }
  }
};

int main(int argc, char **argv) {
  //create executor with two threads
  exec_type exec(2);

  //create channel
  chan ch(&exec);
  int max_num;

  if (argc > 1)
    max_num = atoi(argv[1]);
  else
    max_num = 100;

  cout << "find primes in range [2-" << max_num << "]" << endl;

  //create prime_task0
  prime_task out0(ch, 0);

  for(int i=2; i<=max_num; i++) {
    int *data = new int;
    *data = i;
    cout << "[" << i << "] is being sent..." << endl;
    out0.out_.send(data);
  }

  exec.wait(); //wait async tasks finish
  exec.shut_down_wait(); //wait threads exit

  int *data = new int;
  *data = -1;
  out0.out_.send(data);

  return 0;
}
