////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#define BOOST_CHANNEL_SOURCE

#include <boost/channel/name_spaces/hierarchical_id_trait.hpp>
#include <string>

using namespace std;
using namespace boost::channel;

/// definitions of system messages for str_path_id<'/'> ids
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::channel_conn_msg = "/sys/channel_conn_msg";
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::channel_disconn_msg = "/sys/channel_disconn_msg";
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::init_subscription_info_msg = "/sys/init_subscription_info_msg";
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::connection_ready_msg = "/sys/connection_ready_msg";
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::subscription_info_msg = "/sys/subscription_info_msg";
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::unsubscription_info_msg = "/sys/unsubscription_info_msg";
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::publication_info_msg = "/sys/publication_info_msg";
template <> str_path_id<'/'> id_trait<str_path_id<'/'> >::unpublication_info_msg = "/sys/unpublication_info_msg";
template <> str_path_id<'/'>::value_type id_trait<str_path_id<'/'> >::root_token = "//";
template <> str_path_id<'/'>::value_type id_trait<str_path_id<'/'> >::wildcard_token = "*";
 
/// definitions of system messages for str_path_id<'|'> ids
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::channel_conn_msg = "|sys|channel_conn_msg";
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::channel_disconn_msg = "|sys|channel_disconn_msg";
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::init_subscription_info_msg = "|sys|init_subscription_info_msg";
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::connection_ready_msg = "|sys|connection_ready_msg";
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::subscription_info_msg = "|sys|subscription_info_msg";
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::unsubscription_info_msg = "|sys|unsubscription_info_msg";
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::publication_info_msg = "|sys|publication_info_msg";
template <> str_path_id<'|'> id_trait<str_path_id<'|'> >::unpublication_info_msg = "|sys|unpublication_info_msg";
template <> str_path_id<'|'>::value_type id_trait<str_path_id<'|'> >::root_token = "||";
template <> str_path_id<'|'>::value_type id_trait<str_path_id<'|'> >::wildcard_token = "*";

/// definitions of system messages for str_path_id<'\'> ids
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::channel_conn_msg = "\\sys\\channel_conn_msg";
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::channel_disconn_msg = "\\sys\\channel_disconn_msg";
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::init_subscription_info_msg = "\\sys\\init_subscription_info_msg";
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::connection_ready_msg = "\\sys\\connection_ready_msg";
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::subscription_info_msg = "\\sys\\subscription_info_msg";
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::unsubscription_info_msg = "\\sys\\unsubscription_info_msg";
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::publication_info_msg = "\\sys\\publication_info_msg";
template <> str_path_id<'\\'> id_trait<str_path_id<'\\'> >::unpublication_info_msg = "\\sys\\unpublication_info_msg";
template <> str_path_id<'\\'>::value_type id_trait<str_path_id<'\\'> >::root_token = "\\\\";
template <> str_path_id<'\\'>::value_type id_trait<str_path_id<'\\'> >::wildcard_token = "*";



