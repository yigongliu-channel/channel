////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef DROPPING_QUEUE_HPP
#define DROPPING_QUEUE_HPP

#include <deque>

namespace boost {
  namespace channel {

    /**
     * droppined queue: after reaching que size limit, old msgs will be dropped to give
     * space to new msgs
     */
    template <typename elem_type, typename synch_policy, typename platform>
    class dropping_que {
    public:
      typename synch_policy::mutex lock_;
      std::deque<elem_type> data_;
      size_t max_sz_;
      enum def_sz_type { def_sz = 100 };
      dropping_que(int s = def_sz): max_sz_(s) {}
      bool empty() {
	typename synch_policy::scoped_lock lock(lock_);
	return data_.empty();
      }
      size_t size() {
	typename synch_policy::scoped_lock lock(lock_);
	return data_.size();
      }
      void set_max_que_sz(size_t ms) { max_sz_ = ms; }
      size_t get_max_que_sz(void) { return max_sz_; }
      void put(elem_type & e) {
	typename synch_policy::scoped_lock lock(lock_);
	if (data_.size() >= max_sz_) 
	  data_.pop_front(); //remove old data
	data_.push_back(e);
      }
      void get(elem_type & e) {
	typename synch_policy::scoped_lock lock(lock_);
	if (!data_.empty()) {
	  e = data_.front();
	  data_.pop_front();
	}
      }
    };

  }
}

#endif

 
