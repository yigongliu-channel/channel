////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef ARBITERS_HPP
#define ARBITERS_HPP

#include <deque>
#include <vector>
#include <map>
#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/channel/dispatcher.hpp>
#include <boost/channel/queue.hpp>

/**
 * message passing synchronization patterns (choice, join)
 * part of buffered_async_dispatcher
 * see CCR and Comega document
 */
namespace boost {
  namespace channel {

    /**
     * choice
     */
    template <typename name_space, typename platform, 
	      template <class,class> class queue_type = dumb_que>
    class choice_arbiter {
    public:
      typedef buffered_async_dispatcher<name_space,platform,queue_type> dispatcher_type;
      typedef typename name_space::id_type id_type;
      typedef typename name_space::synch_policy synch_policy;
      typedef typename name_space::executor executor;
      typedef typename platform::timeout_type timeout_type;
      typedef message<id_type> msg_type;
      typedef named_in<name_space, typename dispatcher_type::recver> named_in_type;
      typedef choice_arbiter<name_space,platform,queue_type> my_type;

      typedef boost::function1<void, boost::shared_ptr<void> > call_back_t;
      
      name_space &ch_;
      executor *exec_;
      struct entry {
	named_in_type *in_;
	call_back_t handler_;
      };
      std::map<id_type, entry> bind_map_;
      typename synch_policy::mutex mutex_;

      choice_arbiter(name_space &ch, executor *e = NULL) :
	ch_(ch),
        exec_(e!=NULL?e:ch.get_exec()) {}

      ~choice_arbiter() {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::map<id_type, entry>::iterator iter;
	for (iter = bind_map_.begin(); iter != bind_map_.end(); iter++)
	  if (iter->second.in_ != NULL) {
	    delete iter->second.in_;
	  }
      }

      //called from inside dispatcher
      void invoke(id_type id) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::map<id_type, entry>::iterator iter = bind_map_.find(id);
	if (iter != bind_map_.end()) {
	  named_in_type *in = iter->second.in_;
	  if(in->claim()) {
	    boost::shared_ptr<msg_type> msg;
	    if (in->pull(msg) > 0) {
	      //successfully get a msg here, should we use executor to run callback?
	      //since invoke already run in executor, so dont delay again
	      iter->second.handler_(msg->data_);
	    }
	  }
	}
      }

      bool bind(id_type & id, 
		call_back_t cb,
		typename named_in_type::scope_type scope = named_in_type::scope_global) {
	typename synch_policy::scoped_lock lock(mutex_);
	if (bind_map_.find(id) == bind_map_.end()) {
	  entry ent;
	  ent.in_ = new named_in_type(ch_,id,
				      boost::bind(&my_type::invoke, this, _1),
				      scope,named_in_type::member_local,exec_);
	  ent.handler_ = cb;
	  bind_map_[id] = ent;
	  return true;
	}
	return false;
      }

      bool unbind(id_type & id) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::map<id_type, entry>::iterator iter = bind_map_.find(id);
	if (iter != bind_map_.end()) {
	  delete iter->second.in_;
	  bind_map_.erase(iter);
	  return true;
	}
	return false;
      }
      
    };

    /**
     * join
     */
    template <typename name_space, typename platform, 
	      template <class,class> class queue_type = dumb_que>
    class join_arbiter {
    public:
    public:
      typedef buffered_async_dispatcher<name_space,platform,queue_type> dispatcher_type;
      typedef typename name_space::id_type id_type;
      typedef typename name_space::synch_policy synch_policy;
      typedef typename name_space::executor executor;
      typedef typename platform::timeout_type timeout_type;
      typedef message<id_type> msg_type;
      typedef named_in<name_space, typename dispatcher_type::recver> named_in_type;
      typedef join_arbiter<name_space,platform,queue_type> my_type;
      
      typedef boost::function1<void, std::vector<boost::shared_ptr<void> > > call_back_t;
      
      name_space &ch_;
      executor *exec_;
      call_back_t handler_;
      std::deque<named_in_type*> ins_;
      typename synch_policy::mutex mutex_;

      join_arbiter(name_space &ch, 
		   std::vector<std::pair<id_type, typename named_in_type::scope_type> > & ids,
		   call_back_t cb,
		   executor *e = NULL) :
	ch_(ch),
	exec_(e!=NULL?e:ch.get_exec()),
        handler_(cb) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::vector<std::pair<id_type, 
		      typename named_in_type::scope_type> >::iterator iter;
	for(iter = ids.begin(); iter != ids.end(); iter++) {
	  named_in_type * ni = new named_in_type(ch_,iter->first,
						 boost::bind(&my_type::invoke, this, _1),
				      iter->second,
				      named_in_type::member_local,exec_);
	  ins_.push_front(ni); //keep order to avoid deadlock
	}
      }

      join_arbiter(name_space &ch, 
		   call_back_t cb,
		   executor *e = NULL) :
	ch_(ch),
	exec_(e!=NULL?e:ch.get_exec()),
        handler_(cb) {
      }

      ~join_arbiter() {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<named_in_type*>::iterator iter;
	for (iter = ins_.begin(); iter != ins_.end(); iter++)
	  delete (*iter);
      }

      //called from inside dispatcher
      //2 phase protocol
      void invoke(id_type id) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<named_in_type*>::iterator iter;
	//first claim the messages
	for (iter = ins_.begin(); iter != ins_.end(); iter++) {
	  named_in_type *in = (*iter);
	  if(!in->claim()) {
	    //roll back
	    for (typename std::deque<named_in_type*>::iterator iter2 = ins_.begin(); 
		 iter2 != iter; iter2++) 
	      (*iter2)->unclaim();
	    return;
	  }
	}
	//reaching here, we have claimed all the member messages, 
	//commit (pull msgs and run callback)
	boost::shared_ptr<msg_type> msg;
	std::vector<boost::shared_ptr<void> > result;
	for (iter = ins_.begin(); iter != ins_.end(); iter++) {
	  named_in_type *in = (*iter);
	  msg.reset();
	  in->pull(msg);
	  result.push_back(msg->data_);
	}
	handler_(result);
      }

      bool bind(id_type & id, 
		typename named_in_type::scope_type scope = named_in_type::scope_global) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<named_in_type*>::iterator iter;
	for(iter = ins_.begin(); iter != ins_.end(); iter++) 
	  if ((*iter)->id_ == id) 
	    return false;
	named_in_type * ni = new named_in_type(ch_,id,
					       boost::bind(&my_type::invoke, this, _1),
					       scope,
					       named_in_type::member_local,exec_);
	ins_.push_front(ni); //keep order to avoid deadlock
	return true;
      }

      bool unbind(id_type & id) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<named_in_type*>::iterator iter;
	for(iter = ins_.begin(); iter != ins_.end(); iter++) 
	  if ((*iter)->id_ == id) {
	    delete (*iter);
	    ins_.erase(iter);
	    return true;
	  }
	return false;
      }
    };

  }
}

#endif
