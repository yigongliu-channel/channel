////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef SYNCH_POLICY_HPP
#define SYNCH_POLICY_HPP

#include <boost/channel/platform.hpp>

namespace boost {
  namespace channel {

    template <typename platform_t>
    class null_synch {
    public:
      typedef platform_t platform;
      typedef typename platform_t::null_mutex mutex;
      typedef typename platform_t::null_condition condition;    
      typedef typename mutex::scoped_lock scoped_lock;
    };

    template <typename platform_t>
    class mt_synch {
    public:
      typedef platform_t platform;
      typedef typename platform_t::mutex mutex;
      typedef typename platform_t::condition condition;    
      typedef typename mutex::scoped_lock scoped_lock;
    };

  }
}

#endif

