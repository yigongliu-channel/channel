#ifndef QUEUE_HPP
#define QUEUE_HPP

#include <deque>

/**
 * the simplest msg_que for demo; just for defining the interface
 * for real applications, we need to add more:
 * . flow control: low water mark & high water mark
 * . or lease time for each messages in queue, how long they can stay buffered
 */

namespace boost {
  namespace channel {

    template <typename elem_type, typename timeout_type>
    class dumb_que {
    public:
      std::deque<elem_type> data_;
      bool empty() {
	return data_.empty();
      }
      size_t size() {
	return data_.size();
      }
      void put(elem_type & e, timeout_type *) {
	data_.push_back(e);
      }
      void get(elem_type & e, timeout_type *) {
	if (!data_.empty()) {
	  e = data_.front();
	  data_.pop_front();
	}
      }
    };

  }
}

#endif

 
