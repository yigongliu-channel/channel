////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef PUB_SUB_HPP
#define PUB_SUB_HPP

#include <vector>

namespace boost {
  namespace channel { 

    /**
     * the following 2 classes are convenience high level API classes
     * for end uers to use
     */
    template <
      typename name_space,
      typename dispatcher_sender_type
      >
    class publisher : public named_out_bundle<name_space,dispatcher_sender_type> {
      typedef named_out_bundle<name_space,dispatcher_sender_type> named_out_bundle;
      typedef typename name_space::id_type id_type; 
      typedef named_out<name_space,dispatcher_sender_type> named_out;
      typedef typename name_space::synch_policy::platform::timeout_type timeout_type;
    public:
      publisher(name_space & ch,  
		       typename named_out::member_type type = named_out::member_local) : 
	named_out_bundle(ch, type) {
      }
      void publish(std::vector<std::pair<id_type,typename named_out::scope_type> > & ids) {
	bind(ids);
      }
      bool publish(id_type & id, typename named_out::scope_type scope = named_out::scope_global) {
	return bind(id, scope);
      }
      bool unpublish(id_type & id) {
	return unbind(id);
      }

      //-- the following are API borrowed from dispatcher --
      template <typename user_msg_type>
      void send(id_type & id, user_msg_type *msg, int sz = sizeof(user_msg_type), 
		timeout_type *timeout=0) {
	named_out *no = find(id);
	if (no != NULL)
	  no->send(msg,sz,timeout);
      }
      template <typename user_msg_type, typename deleter>
      void send(id_type & id, user_msg_type *msg, deleter deler, int sz = sizeof(user_msg_type), 
		timeout_type *timeout=0) {
	named_out *no = find(id);
	if (no != NULL)
	  no->send(msg,deler,sz,timeout);
      }
      template <typename user_msg_type>
      void send(id_type & id, boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		timeout_type *timeout=0) {
	named_out *no = find(id);
	if (no != NULL)
	  no->send(msg,sz,timeout);
      }
    };

    template <
      typename name_space,
      typename dispatcher_recver_type
      >
    class subscriber: public named_in_bundle<name_space,dispatcher_recver_type> {
      typedef typename name_space::id_type id_type; 
      typedef named_in_bundle<name_space,dispatcher_recver_type> named_in_bundle;
      typedef typename name_space::synch_policy::platform::timeout_type timeout_type;
      typedef named_in<name_space,dispatcher_recver_type> named_in;
    public:
      template <typename recver_type>
      subscriber(name_space & ch, recver_type rc,
		      typename named_in::member_type type = named_in::member_local) : 
	named_in_bundle(ch, rc, type) {
      }
      void subscribe(std::vector<std::pair<id_type,typename named_in::scope_type> > & ids) {
	bind(ids);
      }
      bool subscribe(id_type & id, typename named_in::scope_type scope = named_in::scope_global) {
	return bind(id,scope);
      }
      bool unsubscribe(id_type & id) {
	return unbind(id);
      }
    };
  }
}

#endif

