////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef EXECUTOR_HPP
#define EXECUTOR_HPP

#include <deque>
#include <algorithm>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/asio.hpp>

namespace boost {
  namespace channel {

    //async tasks: to be later executed in executor:
    //1. although in same thread, not in orginal calling context
    //2. in diff thread
    class async_task_base
    {
    public:
      enum state {
	waiting,
	running,
	completed
      };

      // Perform the task.
      void execute()
      {
	st_ = running;
	exec_func_(this);
	st_ = completed;
      }

      // Destroy the task.
      void destroy()
      {
	destroy_func_(this);
      }

    protected:
      typedef void (*exec_func_type)(async_task_base*);
      typedef void (*destroy_func_type)(async_task_base*);

      // Construct an task 
      async_task_base(exec_func_type exec_func,
		      destroy_func_type destroy_func)
	: exec_func_(exec_func),
	  destroy_func_(destroy_func),
	  st_(waiting)
      {
      }

      // Prevent deletion through this type.
      ~async_task_base()
      {
      }

    private:
      exec_func_type exec_func_;
      destroy_func_type destroy_func_;
      state st_;
    };

    // 
    template <typename task_type>
    class async_task
      : public async_task_base
    {
    public:
      // Constructor.
      async_task(task_type task)
	: async_task_base(&async_task<task_type>::exec_task,
			  &async_task<task_type>::destroy_task),
	  task_(task)
      {
      }

      // Invoke the task.
      static void exec_task(async_task_base* base)
      {
	static_cast<async_task<task_type>*>(base)->task_();
      }

      // Delete the task.
      static void destroy_task(async_task_base* base)
      {
	delete static_cast<async_task<task_type>*>(base);
      }

    private:
      task_type task_;
    };

    //define an abstract class, so that it cannt be
    //instantiated and execution must be in-line;
    //or it can provide a base class for dynamic
    //polymorphism of executors;
    class abstract_executor {
    public:
      template <typename task_type>
      async_task_base * execute(task_type task) { return NULL; }
      virtual bool cancel(async_task_base *task) = 0;
      virtual ~abstract_executor() {}
    };

    //the simplest: execute async_task in place: ie. in current thread & calling context
    class in_place_executor {
    public:
      template <typename task_type>
      void execute(task_type task) {
	task();
      }
    };

    //in single-thread async app: operations can be delayed:
    //executed later by the same (single) thread, the original calling context is gone
    template <typename synch_policy>
    class delayed_executor {
    public:
      std::deque<async_task_base *> tasks_;
      typename synch_policy::mutex mutex_;

      delayed_executor() {}
      ~delayed_executor() {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<async_task_base *>::iterator iter;
	for(iter = tasks_.begin(); iter != tasks_.end(); iter++)
	  (*iter)->destroy();
      }
      template <typename task_type>
      async_task_base * execute(task_type task) { 
	async_task_base *t = new async_task<task_type>(task);
	typename synch_policy::scoped_lock lock(mutex_);
	tasks_.push_back(t);
	return t; 
      }
      bool cancel(async_task_base *task) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<async_task_base *>::iterator iter;
	iter = std::find(tasks_.begin(), tasks_.end(), task);
	if (iter != tasks_.end()) {
	  (*iter)->destroy();
	  tasks_.erase(iter);
	  return true;
	}
	return false;
      }
      //complete scheduled tasks
      void run(void) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<async_task_base *>::iterator iter;
	for(iter = tasks_.begin(); iter != tasks_.end(); iter++) {
	  (*iter)->execute();
	  (*iter)->destroy();
	}
	tasks_.clear();
      }
    };

    //integration with Boost.Asio
    //submit async tasks to asio's completion_event queue to be executed by main thread
    class asio_executor {
    public:
      boost::asio::io_service& io_service_;
      asio_executor(boost::asio::io_service& io_service): io_service_(io_service) {}
      template <typename task_type>
      void execute(task_type task) {
	io_service_.post(task);	
      }
    };

    //a dedicated pool of threads to exec async tasks
    //a simple thread pool executor with unlimited buffering
    template <typename synch_policy>
    class thread_pool_executor {
    public:
      enum state {
	running,
	stop
      };

      thread_pool_executor(int num_thr) : num_thr_(num_thr) {
	for(int i=0; i<num_thr; i++)
	  threads_.create_thread(boost::bind(&thread_pool_executor::run, this));
	st_ = running;
      }

      ~thread_pool_executor() {
	threads_.join_all();
      }

      ///executor life cycle
      state get_state(void) {
	return st_;
      }

      //gracefully shut down
      void shut_down_wait() {
	st_ = stop;
	//waiting for the threads to exit
	threads_.join_all();
      }

      //abruptively shut down
      void shut_down_now() {
	st_ = stop;
	//kill threads
      }

      ///submit a task
      template <typename task_type>
      async_task_base * execute(task_type task) {
	async_task_base * t = new async_task<task_type>(task);
	typename synch_policy::scoped_lock lock(mutex_);
	tasks_.push_back(t);
	cond_.notify_one();
	return t;
      }
      
      ///scancel a task
      bool cancel(async_task_base *task) {
	typename synch_policy::scoped_lock lock(mutex_);
	typename std::deque<async_task_base *>::iterator iter;
	iter = std::find(tasks_.begin(), tasks_.end(), task);
	if (iter != tasks_.end()) {
	  (*iter)->destroy();
	  tasks_.erase(iter);
	  return true;
	}
	return false;
      }

    private:
      async_task_base * next_task(void) {
	async_task_base * t = NULL;
	typename synch_policy::scoped_lock lock(mutex_);
	while(tasks_.empty()) 
	  cond_.wait(lock);
	t = tasks_.front();
	tasks_.pop_front();
	return t;
      }

      void run(void) {
	while (st_ != stop) {
	  async_task_base * t = next_task();
	  t->execute();
	}
      }

    private:
      std::deque<async_task_base *> tasks_;
      boost::thread_group threads_;
      typename synch_policy::mutex mutex_;
      typename synch_policy::condition cond_;
      state st_;
      int num_thr_;
    };

  }
}

#endif

