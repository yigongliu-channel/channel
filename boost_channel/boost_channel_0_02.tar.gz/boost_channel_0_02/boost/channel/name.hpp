////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////

#ifndef NAME_HPP
#define NAME_HPP

#include <list>
#include <map>
#include <boost/utility.hpp>
#include <boost/bind.hpp>
#include <boost/channel/synch_policy.hpp>
#include <boost/channel/executor.hpp>

namespace boost {
  namespace channel {

    namespace detail {

      //name binding callback
      template<typename name>
      class binding_callback_base
      {
      public:
	// Perform the operation.
	void invoke(name *n, typename name::binding_event e)
	{
	  invoke_func_(this, n, e);
	}

	// Destroy the operation.
	void destroy()
	{
	  destroy_func_(this);
	}

      protected:
	typedef void (*invoke_func_type)(binding_callback_base*, name *n, typename name::binding_event e);
	typedef void (*destroy_func_type)(binding_callback_base*);

	// Construct an operation for the given descriptor.
	binding_callback_base(invoke_func_type invoke_func,
			      destroy_func_type destroy_func)
	  : invoke_func_(invoke_func),
	    destroy_func_(destroy_func)
	{
	}

	// Prevent deletion through this type.
	~binding_callback_base()
	{
	}

      private:
	// The function to be called to dispatch the handler.
	invoke_func_type invoke_func_;

	// The function to be called to delete the handler.
	destroy_func_type destroy_func_;
      };

      // Adaptor class template for using handlers in operations.
      template <typename name, typename handler_type>
      class binding_callback
	: public binding_callback_base<name>
      {
      public:
	// Constructor.
	binding_callback(handler_type handler)
	  : binding_callback_base<name>(&binding_callback<name,handler_type>::invoke_handler,
					&binding_callback<name,handler_type>::destroy_handler),
	    handler_(handler)
	{
	}

	// Invoke the handler.
	static void invoke_handler(binding_callback_base<name>* base, name *n, 
				   typename name::binding_event e)
	{
	  static_cast<binding_callback<name,handler_type>*>(base)->handler_(n,e);
	}

	// Delete the handler.
	static void destroy_handler(binding_callback_base<name>* base)
	{
	  delete static_cast<binding_callback<name,handler_type>*>(base);
	}

      private:
	handler_type handler_;
      };

    }

    class name_base {
    public:
      enum scope_type {
	scope_local = 0,
	scope_remote,
	scope_global,
	scope_number
      };

      enum member_type {
	member_all = -1,
	member_local = 0,//local queues and callbacks
	member_remote,   //interfaces to remote/local name_spaces
	member_number
      };

      enum binding_event {
	bind_out_ev=0,
	unbind_out_ev,
	bind_in_ev,
	unbind_in_ev,
	bind_ev,
	unbind_ev
      };
    };

    /// "name" should be noncopyable; otherwise the connection between
    /// named_in and named_out will be messed up
    template <typename id_type, typename executor, typename synch_policy>
    class name : public name_base, private boost::noncopyable {
    public:

      typedef std::list<name *> binding_set_type;
      enum state {
	init,
	active,
	deactivated
      };

      id_type id_;
      typename name_base::scope_type scope_;
      typename name_base::member_type type_;
      executor *exec_;
      state st_;

      // rw_lock to protect bindings?
      typename synch_policy::mutex bind_lock_;
      std::list<name *> bindings_;
      detail::binding_callback_base<name> *binding_cb_;

      /*
	template <typename id_type, typename synch_policy> 
	friend bool operator< (const name<id_type,synch_policy> &left, 
	const name<id_type,synch_policy> &right);
      */
    protected:
      //make constructor protected, so only children can be created
      template <typename binding_cb_type>
      name(id_type id, 
	   binding_cb_type cb,
	   executor *e,
	   scope_type scope, 
	   member_type type
	   ) :
	id_(id),scope_(scope),type_(type), exec_(e),
	binding_cb_(new detail::binding_callback<name,binding_cb_type>(cb))
      {
      }

      name(id_type id, 
	   executor *e,
	   scope_type scope, 
	   member_type type
	   ) :
	id_(id),scope_(scope),type_(type), exec_(e),
	binding_cb_(NULL)
      {
      }

      ~name () {
	if (binding_cb_ != NULL)
	  binding_cb_->destroy();
      }

      void binding_callback(name *n, binding_event e) {
	if (binding_cb_ != NULL) {
	  if(exec_ != NULL) //execute binding callback in executor
	    exec_->execute(boost::bind(
		 &detail::binding_callback_base<name>::invoke,
		 binding_cb_,n, e));
	  else //execute in place
	    binding_cb_->invoke(n, e);
	}
      }

    public:
      int num_bindings(void) {
	return bindings_.size();
      }
      std::list<name *> & bindings(void) {
	return bindings_;
      }

      //the following 2 callbacks invoked by namespace to notify binding changes
      void bind(name *n) {
	typename synch_policy::scoped_lock lock(bind_lock_);
	//add n to bindings_
	bindings_.push_front(n);
	//callback
	binding_callback(n, bind_ev);
      }
      void unbind(name *n) {
	typename synch_policy::scoped_lock lock(bind_lock_);
	//remove n from bindings_
	bindings_.remove(n);
	//callback
	binding_callback(n, unbind_ev);
      }

      //during name-destruction, disconn all
      void unbind_all(void) {
	typename synch_policy::scoped_lock lock(bind_lock_);
	//unbind_all
	for(typename std::list<name *>::iterator iter=bindings_.begin();
	    iter != bindings_.end(); ) {
	  //remove n from bindings_
	  typename std::list<name *>::iterator cur = iter;
	  name *n = *cur;
	  n->unbind(this); //remove reference to me at remote
	  iter++;
	  bindings_.erase(cur);
	}
      }

      //unbind all external bindings; this must be a member_local
      void unbind_all_external(void) {
	typename synch_policy::scoped_lock lock(bind_lock_);
	//unbind_all_external
	for(typename std::list<name *>::iterator iter=bindings_.begin();
	    iter != bindings_.end(); ) 
	  if ((*iter)->type_ == member_remote) {
	    //remove n from bindings_
	    typename std::list<name *>::iterator cur = iter;
	    name *n = *cur;
	    n->unbind(this); //remove reference to me at remote
	    iter++;
	    bindings_.erase(cur);
	  }
      }

      //queries
      ///names from internal and visible at interfaces to external channels
      static bool exported_name(name *n) {
	if (n->type_ == member_local && 
	    (n->scope_ == scope_remote || n->scope_ == scope_global))
	  return true;
	return false;
      }

      ///names from internal and visible to internal peers
      static bool internal_name(name *n) {
	if (n->type_ == member_local && 
	    (n->scope_ == scope_local || n->scope_ == scope_global))
	  return true;
	return false;
      }

      ///all/any names in namespace
      static bool any_name(name *n) {
	return true;
      }
      
    };

    /*
      template <typename id_type, typename synch_policy> 
      friend bool operator< (const name<id_type,synch_policy> &left, 
      const name<id_type,synch_policy> &right) {
      return left.id_ < right.id_;
      }
    */
  }
}

#endif

