////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2005, 2006 Yigong Liu
// Permission to use, copy, modify, distribute and sell this software for any 
//     purpose is hereby granted without fee, provided that the above copyright 
//     notice appear in all copies and that both that copyright notice and this 
//     permission notice appear in supporting documentation.
// The author makes no representations about the 
//     suitability of this software for any purpose. It is provided "as is" 
//     without express or implied warranty.
////////////////////////////////////////////////////////////////////////////////


//// dispatchers:
//// define the whole message passing process:
//// including:
////   . sending, buffering, recving
////   . provide both sender/recver sides

#ifndef DISPATCHER_HPP
#define DISPATCHER_HPP

#include <map>
#include <vector>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>
#include <boost/channel/synch_policy.hpp>
#include <boost/channel/message.hpp>
#include <boost/channel/name.hpp>
#include <boost/channel/named_in_out.hpp>
#include <boost/channel/queue.hpp>

namespace boost {
  namespace channel {

    namespace detail {

      //message handlers
      template <typename id_type, typename timeout_type>
      class msg_handler_base
      {
      public:
	// Perform the operation.
	void invoke(id_type id, boost::shared_ptr<void> msg, int sz,
		    timeout_type *t)
	{
	  invoke_func_(this, id, msg, sz, t);
	}

	// Destroy the operation.
	void destroy()
	{
	  destroy_func_(this);
	}

      protected:
	typedef void (*invoke_func_type)(msg_handler_base*, id_type id, boost::shared_ptr<void> msg, int sz, timeout_type *t);
	typedef void (*destroy_func_type)(msg_handler_base*);

	// Construct an operation for the given descriptor.
	msg_handler_base(invoke_func_type invoke_func,
			 destroy_func_type destroy_func)
	  : invoke_func_(invoke_func),
	    destroy_func_(destroy_func)
	{
	}

	// Prevent deletion through this type.
	~msg_handler_base()
	{
	}

      private:
	// The function to be called to dispatch the handler.
	invoke_func_type invoke_func_;

	// The function to be called to delete the handler.
	destroy_func_type destroy_func_;
      };

      // Adaptor class template for using handlers in operations.
      template <typename id_type, typename timeout_type, typename handler_type>
      class msg_handler
	: public msg_handler_base<id_type, timeout_type>
      {
	typedef msg_handler_base<id_type, timeout_type> msg_handler_base;
      public:
	// Constructor.
	msg_handler(handler_type handler)
	  : msg_handler_base(&msg_handler<id_type, timeout_type, handler_type>::invoke_handler,
			     &msg_handler<id_type, timeout_type, handler_type>::destroy_handler),
	    handler_(handler)
	{
	}

	// Invoke the handler.
	static void invoke_handler(msg_handler_base* base, id_type id, 
				   boost::shared_ptr<void> msg, 
				   int sz, timeout_type *t)
	{
	  static_cast<msg_handler<id_type, timeout_type, handler_type>*>(base)->handler_(id, msg, sz, t);
	}

	// Delete the handler.
	static void destroy_handler(msg_handler_base* base)
	{
	  delete static_cast<msg_handler<id_type, timeout_type ,handler_type>*>(base);
	}

      private:
	handler_type handler_;
      };

      template <typename id_type>
      class msg_handler_base2
      {
      public:
	// Perform the operation.
	void invoke(id_type id)
	{
	  invoke_func_(this, id);
	}

	// Destroy the operation.
	void destroy()
	{
	  destroy_func_(this);
	}

      protected:
	typedef void (*invoke_func_type)(msg_handler_base2*, id_type id);
	typedef void (*destroy_func_type)(msg_handler_base2*);

	// Construct an operation for the given descriptor.
	msg_handler_base2(invoke_func_type invoke_func,
			 destroy_func_type destroy_func)
	  : invoke_func_(invoke_func),
	    destroy_func_(destroy_func)
	{
	}

	// Prevent deletion through this type.
	~msg_handler_base2()
	{
	}

      private:
	// The function to be called to dispatch the handler.
	invoke_func_type invoke_func_;

	// The function to be called to delete the handler.
	destroy_func_type destroy_func_;
      };

      // Adaptor class template for using handlers in operations.
      template <typename id_type, typename handler_type>
      class msg_handler2
	: public msg_handler_base2<id_type>
      {
	typedef msg_handler_base2<id_type> msg_handler_base2;
      public:
	// Constructor.
	msg_handler2(handler_type handler)
	  : msg_handler_base2(&msg_handler2<id_type, handler_type>::invoke_handler,
			     &msg_handler2<id_type, handler_type>::destroy_handler),
	    handler_(handler)
	{
	}

	// Invoke the handler.
	static void invoke_handler(msg_handler_base2* base, id_type id)
	{
	  static_cast<msg_handler2<id_type, handler_type>*>(base)->handler_(id);
	}

	// Delete the handler.
	static void destroy_handler(msg_handler_base2* base)
	{
	  delete static_cast<msg_handler2<id_type, handler_type>*>(base);
	}

      private:
	handler_type handler_;
      };


      //base sender class, shared by most push dispatchers
      template <typename name_space, typename platform, template<typename,typename> class sending_algo>
      struct push_sender_base {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;

	name_type * name_;
	executor *exec_;
	sending_algo<name_space, platform> algo;

	push_sender_base(name_type * n, executor *e) : name_(n), exec_(e) { }

	//assuming msgs contained inside shared_ptr
	void push(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) {
	  typename synch_policy::scoped_lock lock(name_->bind_lock_);
	  typename name_type::binding_set_type &bindings = name_->bindings_;
	  algo(bindings, msg, timeout);
	}

	//after sending, channel becomes owner
	template <typename user_msg_type>
	void send(user_msg_type *msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  push (m, timeout);
	}

	//after sending: 1> channel becomes owner, if deleter does real deletion
	// 2> sender still owns msg, if deleter does nothing
	template <typename user_msg_type, typename deleter>
	void send(user_msg_type *msg, deleter deler, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg, deler);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  push (m, timeout);
	}

	//user_msg is already smarter pointer, channel becomes owner
	template <typename user_msg_type>
	void send(boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  push (m, timeout);
	}

	//for channel internal use on wildcard named_out
	template <typename user_msg_type>
	void send(id_type id, boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(id, m0, sz));
	  push (m, timeout);
	}

      };

      //base recver class, shared by most push dispatchers
      template <typename name_space, typename platform>
      struct push_recver_base {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef name<id_type,executor,synch_policy> name_type;

	name_type * name_;
	executor *exec_;
	msg_handler_base<id_type, timeout_type> *recver_;
      
	template<typename recver_type>
	push_recver_base(name_type * n, recver_type rc, executor *e) : 
	  name_(n), exec_(e)
	{
	  recver_ = new msg_handler<id_type, timeout_type, recver_type>(rc);
	}

	~push_recver_base() { 
	  if (recver_ != NULL)
	    recver_->destroy(); 
	}

	template<typename recver_type>
	void set_recver(recver_type rc) { 
	  if (recver_ != NULL) recver_->destroy(); 
	  recver_ =  new msg_handler<id_type, timeout_type, recver_type>(rc);
	}

	//senders call this to push into here
	void push(boost::shared_ptr<msg_type> msg, timeout_type *timeout)
	{
	  if (exec_ != NULL) //run recv_handler in executor
	    exec_->execute(boost::bind(&msg_handler_base<id_type, timeout_type>::invoke,
					recver_,msg->id_, msg->data_, msg->size_, timeout));
	  else //run recv_handler in place
	    recver_->invoke(msg->id_, msg->data_, msg->size_, timeout);
	}

      };

      //the following is for 3 simple "push" dispatchers: broadcast, roundrobin, union
      template <typename name_space, typename platform>
      struct broadcast_algo {
	typedef typename name_space::id_type id_type;
	typedef message<id_type> msg_type;
	typedef typename platform::timeout_type timeout_type;
	typedef push_recver_base<name_space,platform> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	template<typename bindings_type>
	void operator() (bindings_type &bindings, 
			 boost::shared_ptr<msg_type> msg, timeout_type *timeout) {
	  if (!bindings.empty()) {
	    for(typename bindings_type::iterator iter = bindings.begin();
		iter != bindings.end(); iter++) {
	      named_in_type *named_in = (named_in_type *)(*iter);
	      recver_type *recver = (recver_type *)named_in;
	      recver->push(msg,timeout);
	    }
	  }
	}
      };

      //we need random-access iterator for roundrobin? 
      //here a temp fix: convert set<name*> to vector<name*>
      //for a namespace targeted for round_robin dispatching app,
      //we should change namespace container type to vector instead of set
      //or make namespace container type configurable?
      template <typename name_space, typename platform>
      class round_robin_algo {
      public:
	typedef typename name_space::id_type id_type;
	typedef message<id_type> msg_type;
	typedef typename platform::timeout_type timeout_type;
	typedef push_recver_base<name_space,platform> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	round_robin_algo(): last_(-1) {}
	template<typename bindings_type>
	void operator() (bindings_type &bindings, 
			 boost::shared_ptr<msg_type> msg, timeout_type *timeout) {
	  if (!bindings.empty()) {
	    std::vector<typename bindings_type::value_type> v(bindings.begin(), bindings.end());
	    int sz = v.size();
	    last_ = (last_+1) % sz;
	    named_in_type *named_in = (named_in_type *)(v[last_]);
	    recver_type *recver = (recver_type *)named_in;
	    recver->push(msg, timeout);
	  }
	}
      private:
	int last_;
      };

      //imitate plan9/inferno's "union" namespace:
      //later bound names will overlap older names, ie. latest mounted server will
      //take over and serve all msgs on the covered names
      //so always the latest bound name get dispatched
      template <typename name_space,typename platform>
      struct always_1st_algo {
	typedef typename name_space::id_type id_type;
	typedef message<id_type> msg_type;
	typedef typename platform::timeout_type timeout_type;
	typedef push_recver_base<name_space,platform> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	template<typename bindings_type>
	void operator() (bindings_type &bindings, 
			 boost::shared_ptr<msg_type> msg, timeout_type *timeout) {
	  if (!bindings.empty()) {
	    typename bindings_type::iterator iter = bindings.begin();
	    named_in_type *named_in = (named_in_type *)(*iter);
	    recver_type *recver = (recver_type *)named_in;
	    recver->push(msg,timeout);
	  }
	}
      };

      /**
       * some pull dispatchers: buffering (linda, join)
       */

      //base pull_sender class, shared by most pull dispatchers
      template <typename name_space, typename platform,
		template <class,class> class msg_queue_type>
      struct pull_sender_base {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef msg_queue_type<boost::shared_ptr<msg_type>, timeout_type> que_type;

	name_type * name_;
	executor *exec_;
	typename synch_policy::mutex q_lock_;
	que_type que_;

	pull_sender_base(name_type *n, executor *e) : name_(n), exec_(e) { }
	virtual ~pull_sender_base() {}

	virtual void notify(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0)=0;

	//assuming msgs contained inside shared_ptr
	void store_data(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) 
	{
	  typename synch_policy::scoped_lock qlock(q_lock_);
	  que_.put(msg, timeout);
	}

	//recvers will call this to retrv/pull data
	int pull(boost::shared_ptr<msg_type> & msg, timeout_type *timeout=0) {
	  typename synch_policy::scoped_lock qlock(q_lock_);
	  if (!que_.empty()) {
	    que_.get(msg, timeout);
	    return msg->size_;
	  }
	  return 0;
	}

	//after sending, channel becomes owner
	template <typename user_msg_type>
	void send(user_msg_type *msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  notify (m, timeout);
	}

	//after sending: 1> channel becomes owner, if deleter does real deletion
	// 2> sender still owns msg, if deleter does nothing
	template <typename user_msg_type, typename deleter>
	void send(user_msg_type *msg, deleter deler, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg, deler);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  notify (m, timeout);
	}

	//user_msg is already smarter pointer, channel becomes owner
	template <typename user_msg_type>
	void send(boost::shared_ptr<user_msg_type> msg, int sz = sizeof(user_msg_type), 
		  timeout_type *timeout=0) {
	  boost::shared_ptr<void> m0(msg);
	  boost::shared_ptr<msg_type> m(new msg_type(name_->id_, m0, sz));
	  notify (m, timeout);
	}

      };

      template<class,class,template<class,class>class> class pull_recver_sync;

      template <typename name_space, typename platform, template <class,class> class msg_queue_type>
      struct pull_sender_sync : public pull_sender_base<name_space,platform,msg_queue_type> {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef msg_queue_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_recver_sync<name_space, platform,msg_queue_type> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	pull_sender_sync(name_type *n, executor *e) : pull_sender_base<name_space,platform,msg_queue_type>(n,e) { }
	~pull_sender_sync() {}

	//assuming msgs contained inside shared_ptr
	void notify(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) {
	  store_data(msg, timeout);
	  typename synch_policy::scoped_lock lock(this->name_->bind_lock_);
	  binding_set_type &bindings = this->name_->bindings_;
	  if (!bindings.empty()) {
	    bool cont = true;
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end() && cont; iter++) {
	      named_in_type *named_in = (named_in_type *)(*iter);
	      recver_type *recver = (recver_type *)named_in;
	      cont = recver->notify(msg->id_);
	    }
	  }
	}
      };

      template<class,class,template<class,class>class> class pull_recver_async;

      template <typename name_space, typename platform, template <class,class> class msg_queue_type>
      struct pull_sender_async : public pull_sender_base<name_space,platform,msg_queue_type> {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef msg_queue_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_recver_async<name_space, platform,msg_queue_type> recver_type;
	typedef named_in<name_space, recver_type> named_in_type;

	pull_sender_async(name_type *n, executor *e) : 
	  pull_sender_base<name_space,platform,msg_queue_type>(n,e), num_claimed_(0) { }
	~pull_sender_async() {}

	//assuming msgs contained inside shared_ptr
	void notify(boost::shared_ptr<msg_type> msg, timeout_type *timeout=0) {
	  store_data(msg, timeout);
	  typename synch_policy::scoped_lock lock(this->name_->bind_lock_);
	  binding_set_type &bindings = this->name_->bindings_;
	  if (!bindings.empty()) {
	    ///let all interested recvers know that a message is available
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end(); iter++) {
	      named_in_type *named_in = (named_in_type *)(*iter);
	      recver_type *recver = (recver_type *)named_in;
	      recver->notify(msg->id_);
	    }
	  }
	}

	//specific for pull_sender_async:
        int num_claimed_; //protected by q_lock_
	
	//to support 2-phase protocol at recver side
	bool claim_one(void) {
	  typename synch_policy::scoped_lock lock(this->q_lock_);
	  if ((int)this->que_.size() > num_claimed_) {
	    num_claimed_++;
	    return true;
	  }
	  return false;
	}

	void unclaim_one(void) {
	  typename synch_policy::scoped_lock lock(this->q_lock_);
	  num_claimed_--;
	  if (num_claimed_ < 0) num_claimed_ = 0;
	}
      };

      //pull_recver_async class, base for join/choice pattern
      template <typename name_space, typename platform, template <class,class> class msg_que_type>
      struct pull_recver_async {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef typename name_type::binding_set_type binding_set_type;
	typedef msg_que_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_sender_async<name_space, platform, msg_que_type> sender_type;
	typedef named_out<name_space, sender_type> named_out_type;

	name_type * name_;
	msg_handler_base2<id_type> * recver_;
	executor *exec_;
	sender_type *claimed_sender_;
      
	template<typename recver_type>
	pull_recver_async(name_type *n, recver_type rc, executor *e) : 
	  name_(n), exec_(e), claimed_sender_(NULL) 
	{
	  recver_ = new msg_handler2<id_type, recver_type>(rc);
	}

	~pull_recver_async() { 
	  if (recver_ != NULL)
	    recver_->destroy();
	  if (claimed_sender_ != NULL)
	    claimed_sender_->unclaim_one();
	}

	//senders call this to notify about some data coming
	//put this recver into activation list
	bool notify(id_type id) {
	  if (exec_ != NULL) //run recv_handler in executor
	    exec_->execute(boost::bind(&msg_handler_base2<id_type>::invoke, recver_,id));
	  else //run recv_handler in place
	    recver_->invoke(id);

	  return true; //always return true to force sender to notify others
	}

	//claim data at sender
	bool claim(void) {
	  if (claimed_sender_ != NULL) { //should not happen
	    claimed_sender_->unclaim_one();
	    claimed_sender_ = NULL;
	  }
	  //go-thru binding_set to claim
	  typename synch_policy::scoped_lock lock(name_->bind_lock_);
	  binding_set_type &bindings = name_->bindings_;
	  if (!bindings.empty()) {
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end() && claimed_sender_ == NULL; iter++) {
	      named_out_type *named_out = (named_out_type *)(*iter);
	      sender_type *sender = (sender_type *)(named_out);
	      if(sender->claim_one()) claimed_sender_ = sender;
	    }
	  }
	  if (claimed_sender_ != NULL) return true;
	  else return false;
	}

	//
	void unclaim(void) {
	  if (claimed_sender_ != NULL) {
	    claimed_sender_->unclaim_one();
	    claimed_sender_ = NULL;
	  }
	}

	//pull data from sender
	int pull(boost::shared_ptr<msg_type> & msg) {
	  int sz = 0;
	  if (claimed_sender_ != NULL) {
	      sz = claimed_sender_->pull(msg);
	      claimed_sender_->unclaim_one();
	      claimed_sender_ = NULL;
	  }
	  return sz;
	}
      };

      //synchronous/blocking pull_recver
      template <typename name_space, typename platform, template <class,class> class msg_que_type>
      struct pull_recver_sync {
	typedef typename name_space::id_type id_type;
	typedef typename name_space::synch_policy synch_policy;
	typedef typename name_space::executor executor;
	typedef name<id_type,executor,synch_policy> name_type;
	typedef typename platform::timeout_type timeout_type;
	typedef message<id_type> msg_type;
	typedef msg_que_type<boost::shared_ptr<msg_type>, timeout_type> que_type;
	typedef pull_sender_sync<name_space, platform, msg_que_type> sender_type;
	typedef named_out<name_space, sender_type> named_out_type;
	typedef typename name_type::binding_set_type binding_set_type;

	name_type * name_;
	typename synch_policy::mutex mutex_;
	typename synch_policy::condition cond_;
	int num_waiting_;

	pull_recver_sync(name_type *n) : 
	  name_(n), num_waiting_(0) {}

	~pull_recver_sync() {}

	//recving thread will block here and wait for notify from senders
	void recv(id_type & id, boost::shared_ptr<void> & msg, int & sz, timeout_type *t=0) {
	  boost::shared_ptr<msg_type> mesg;
	  typename synch_policy::scoped_lock lock(mutex_);
	  while(1) {
	    sz = pull(mesg);
	    if (sz != 0) {
	      id = mesg->id_;
	      msg = mesg->data_;
	      return;
	    }
	    num_waiting_++;
	    cond_.wait(lock);
	    num_waiting_--;
	  }	      
	}

	//if any thread block waiting here
	bool notify(id_type id) {
	  typename synch_policy::scoped_lock lock(mutex_);
	  if (num_waiting_ > 0) {
	    cond_.notify_one();
	    return false;
	  } 
	  else
	    return true;
	}

	//pull data from sender
	int pull(boost::shared_ptr<msg_type> & msg) {
	  int sz = 0;
	  //go-thru binding_set to pull from senders
	  typename synch_policy::scoped_lock lock(name_->bind_lock_);
	  binding_set_type &bindings = name_->bindings_;
	  if (!bindings.empty()) {
	    for(typename binding_set_type::iterator iter = bindings.begin();
		iter != bindings.end() && sz == 0; iter++) {
	      named_out_type *named_out = (named_out_type *)(*iter);
	      sender_type *sender = (sender_type *)(named_out);
	      sz = sender->pull(msg);
	    }
	  }
	  return sz;
	}
      };
    
    }

    template <typename name_space, typename platform>
    struct broadcast_dispatcher {
      typedef detail::push_sender_base<name_space,platform,detail::broadcast_algo> sender;
      typedef detail::push_recver_base<name_space,platform> recver;
    };

    template <typename name_space, typename platform>
    struct round_robin_dispatcher {
      typedef detail::push_sender_base<name_space,platform,detail::round_robin_algo> sender;
      typedef detail::push_recver_base<name_space,platform> recver;
    };

    template <typename name_space, typename platform>
    struct always_1st_dispatcher {
      typedef detail::push_sender_base<name_space,platform,detail::always_1st_algo> sender;
      typedef detail::push_recver_base<name_space,platform> recver;
    };

    //the following are "pull" dispatchers: buffering
    template <typename name_space, typename platform, template <class,class> class queue_type = dumb_que>
    struct buffered_sync_dispatcher {
      typedef detail::pull_sender_sync<name_space,platform,queue_type> sender;
      typedef detail::pull_recver_sync<name_space,platform,queue_type> recver;
    };

    template <typename name_space, typename platform, 
	      template <class,class> class queue_type> class choice_arbiter;
    template <typename name_space, typename platform, 
	      template <class,class> class queue_type> class join_arbiter;

    template <typename name_space, typename platform, 
	      template <class,class> class queue_type = dumb_que>
    struct buffered_async_dispatcher {
      typedef detail::pull_sender_async<name_space,platform,queue_type> sender;
      typedef detail::pull_recver_async<name_space,platform,queue_type> recver;
      typedef choice_arbiter<name_space,platform,queue_type> choice_arbiter;
      typedef join_arbiter<name_space,platform,queue_type> join_arbiter;
    };


  }
}

#endif
